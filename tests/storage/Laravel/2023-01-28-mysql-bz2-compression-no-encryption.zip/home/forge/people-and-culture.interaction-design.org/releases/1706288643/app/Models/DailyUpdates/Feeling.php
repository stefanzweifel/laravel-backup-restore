<?php declare(strict_types=1); // phpcs:ignoreFile @todo: Remove after support for enums

namespace App\Models\DailyUpdates;

enum Feeling: int
{
    case Awful = 1;
    case Bad = 2;
    case NotWell = 3;
    case Good = 4;
    case Awesome = 5;

    public function toEmoji(): string
    {
        return match ($this) {
          self::Awful => '💔',
          self::Bad => '💚💚',
          self::NotWell => '💚💚💚',
          self::Good => '💚💚💚💚',
          self::Awesome => '💚💚💚💚💚',
        };
    }
}
