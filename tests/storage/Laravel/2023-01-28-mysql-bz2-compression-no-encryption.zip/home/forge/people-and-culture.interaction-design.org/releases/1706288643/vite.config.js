import {defineConfig} from 'vite';
import laravel from 'laravel-vite-plugin';
import vue from '@vitejs/plugin-vue';
import i18n from 'laravel-vue-i18n/vite';
import path from 'path';

export default defineConfig({
  plugins: [
    laravel(['resources/js/app.ts']),
    vue({
      template: {
        transformAssetUrls: {
          base: null,
          includeAbsolute: false,
        },
      },
    }),
    i18n(),
  ],
  resolve: {
    alias: {
      '@img': '/resources/img',
    },
  },
  optimizeDeps: {
    include: ['ziggy'],
  },
});
