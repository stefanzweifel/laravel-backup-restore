<?php declare(strict_types=1);

return [
    'blockers' => 'Blockers',
    'highlights' => 'Highlights',
    'leave' => 'Leave registered on Spock 🏖️',
    'chart' => [
        'memberLabel' => 'Number of Work Days per Team Member for :date',
        'monthLabel' => 'Number of Work days for the Month',
        'weekLabel' => 'Number of Work days for the Week',
    ],
    'delete' => 'Delete the daily update?',
    'filter' => 'Please select a filter!',
    'form' => [
        'blockers' => [
            'helpText' => 'Share your blockers so they may be resolved',
            'label' => '<b>Is there anything blocking your progress?</b>',
            'placeholder' => 'Example:
            - I need feedback from John on task B.',
        ],
        'highlights' => [
            'helpText' => 'Share something positive about your day with the team 💚',
            'label' => '<b>Is there anything you would like to highlight about your day?</b>',
            'placeholder' => 'Example:
            - John was super helpful with task B. I’m so grateful for his help!',
        ],
        'createTitle' => 'Add Your Daily Update',
        'editTitle' => 'Edit Your Daily Update',
        'feeling' => [
            'label' => '<b>How are you feeling today?</b>',
            'placeholder' => 'How do you feel? 💚',
        ],
        'holiday' => [
            'helpText' => 'If so, don\'t forget to log your leave in Spock.',
            'label' => '<b>Did you have any leave (holiday, sick days, etc.) since your last update?</b>',
            'reminder' => 'Don\'t forget to register
            your holiday 🙂',
        ],
        'hoursWorked' => [
            'helpText' => 'Required for half days.',
            'label' => '<b>Hours worked</b>',
        ],
        'plans' => [
            'helpText' => "Please keep John Wooden's famous words in mind: “Don't mistake activity for achievement”. As much as possible, make plans that will achieve something substantial, get closure on existing tasks and make you reach audacious goals. This will help you avoid the classic trap of 'keeping busy' versus 'getting important stuff done'",
            'label' => '<b>What are your plans for your next workday?</b>',
            'placeholder' => 'Example:
            - Finish task B I started today. I need to receive a final approval from John.
            - Review mailbox and answer to at least 20 emails.',
        ],
        'submit' => 'Submit your update',
        'submissionDate' => [
            'label' => '<b>Date you are posting this update for (default is today)</b>',
            'helpText' => 'Please choose the date that you\'re posting the update for. If possible, please post your update at the *end* of your workday - in order to maximize the benefits of your update - both for yourself and your colleagues',
        ],
        'update' => [
            'autoFill' => 'Auto-fill with previous plans',
            'helpText' => 'Focus on results: please make your update as concrete and result-oriented as possible, i.e. report *concrete* results whenever possible. Please do not include negligible tasks unless they are important for your colleagues to be aware of.',
            'label' => '<b>What did you complete today?</b>',
            'placeholder' => 'Example:
            - Completed task A. It’s ready to implement now!
            - Discussed task B with John. Now I have c lear overview and ready to work on it.',
        ],
        'workDay' => [
            'halfDay' => 'Less than a full day 🌓',
            'helpText' => 'If half day, please register a half day in Spock or add a note about which day you will work in your plans.',
            'full' => 'Full day',
            'label' => '<b>Did you work a full day or half a day?</b>',
            'placeholder' => 'Select one',
        ],
    ],
    'fullDayReport' => '<b>:name</b> felt :feeling and did work full day',
    'halfDayReport' => '<b>:name</b> felt :feeling and worked half day (:hours hours)',
    'individualTeam' => ':teamMemberName belongs to the <b>:teamName</b> team.',
    'individualUpdateReport' => '<b>:staffName</b> has submitted:<ul class="list-disc list-inside"><li>:fullDayUpdates full day updates</li><li>:halfDayUpdates half-day updates</li><li>:fullDayHolidays full day holidays</li><li>:halfDayHolidays half day holidays</li></ul>',
    'teamUpdateReport' => 'The <b>:teamName</b> team has submitted:<ul class="list-disc list-inside"><li>:fullDayUpdates full day updates</li><li>:halfDayUpdates half-day updates</li><li>:fullDayHolidays full day holidays</li><li>:halfDayHolidays half day holidays</li></ul>',
    'individualUpdates' => 'Daily updates for :staffName for :date',
    'individualUpdateSpockLink' => 'This means there should be :fullDayHolidays (full-day)/ :halfDayHolidays (half-day) holidays holidays/sick-days',
    'teamUpdateSpockLink' => 'This means there should be :fullDayHolidays (full-day)/ :halfDayHolidays (half-day) holidays holidays/sick-days',
    'info' => 'Why are Daily Updates so important? Please read!',
    'lastUpdated' => 'Last updated: :date',
    'noUpdates' => '<b>:name</b> has no updates',
    'pageTitle' => 'Daily Updates',
    'plans' => 'Plans:',
    'postUpdate' => 'Post your update:',
    'teamUpdates' => 'Daily updates for the :teamName team for :date',
    'teamMembers' => 'Team members',
];
