<?php declare(strict_types=1);

namespace App\Console\Commands\Release;

use Illuminate\Console\Command;

final class SetAppRevision extends Command
{
    /**
     * The name and signature of the console command.
     * @var string
     */
    protected $signature = 'app:set-revision
        {revision : new version/revision of the application}
        {branch : git branch}';

    /**
     * The console command description.
     * @var string
     */
    protected $description = 'Update application revision';

    public function handle(): int
    {
        $this->info(now().' Updating app revision in progress...', 'v');

        $envFilePath = base_path('.env');

        /** @var string $envFileContent Get content of the .env file */
        $envFileContent = file_get_contents($envFilePath);

        $envFileContent = $this->updateDotEnvVar($envFileContent, 'APP_VERSION', $this->argument('revision'));
        $envFileContent = $this->updateDotEnvVar($envFileContent, 'APP_BRANCH', $this->argument('branch'));

        // And overwrite the .env with the new data
        $writeResult = file_put_contents($envFilePath, $envFileContent);
        if ($writeResult === false) {
            $this->error("\tCan’t write to {$envFilePath} file, aborting...", 'quiet');

            return 1;
        }

        $this->info(now()." New app revision is {$this->argument('revision')}@{$this->argument('branch')}");
        $this->info(now()." Don’t forget to update config cache if you use it ('php artisan config:cache').", 'v');

        return 0;
    }

    private function updateDotEnvVar(string $envFileContent, string $varName, string $varValue): string
    {
        if (! str_contains($envFileContent, $varName)) {
            $this->warn("\t{$varName} variable not found in .env file, adding it...");
            $envFileContent .= "\n$varName=NEW\n";
        }

        /**
         * Find old application revision if content of .env file and
         * replace it by a new one.
         */
        $updatedFileContent = preg_replace("/(.*)({$varName}=).*($|\z)(.*)/Um", '${1}${2}'."{$varValue}$3", $envFileContent);
        if ($updatedFileContent === null) {
            throw new \RuntimeException('Can not change app revision in .env a file.');
        }

        return $updatedFileContent;
    }
}
