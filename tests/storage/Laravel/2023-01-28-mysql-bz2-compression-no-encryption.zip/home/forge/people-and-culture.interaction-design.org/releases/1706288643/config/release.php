<?php declare(strict_types=1);

return [
    'app_version' => env('APP_VERSION', 'NEW'),
    'branch' => env('APP_BRANCH', 'unknown'),
    'github' => [
        'repository' => env('GITHUB_REPOSITORY'),
        'organisation' => env('GITHUB_ORGANISATION'),
    ],
    'slack' => [
        'webhook' => env('SLACK_RELEASE_NOTIFICATION_WEBHOOK'),
        'channel' => env('SLACK_CHANNEL_TO_REDIRECT_ALL_NOTIFICATIONS', env('SLACK_RELEASE_NOTIFICATION_CHANNEL', '#releases')),
    ],
];
