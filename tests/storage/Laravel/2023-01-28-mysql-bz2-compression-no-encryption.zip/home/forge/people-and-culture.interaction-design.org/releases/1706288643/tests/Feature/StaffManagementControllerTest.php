<?php declare(strict_types=1);

use App\Models\Staff;
use Database\Factories\StaffFactory;
use Database\Factories\TeamFactory;
use Inertia\Testing\AssertableInertia as Assert;
use function Pest\Faker\fake;

it('should redirect unauthorized staff', function () {
    $staff = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('admin.staff.index'))
        ->assertStatus(403);
});

it('should render the staff index page', function () {
    $staff = StaffFactory::new()->admin()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('admin.staff.index'))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('Admin/Staff/Index')
            ->has('staff'));
});

it('should render the staff create page', function () {
    $staff = StaffFactory::new()->admin()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('admin.staff.create'))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('Admin/Staff/Create')
            ->has('teams'));
});

it('should create a new staff member', function () {
    $adminStaff = StaffFactory::new()->admin()->createOne();
    $team = TeamFactory::new()->createOne();

    $newStaffData = [
        'name' => fake()->name,
        'email' => fake()->email,
        'team' => $team->id,
        'slack_user_id' => 'USOMETHING',
    ];

    $this
        ->actingAs($adminStaff)
        ->post(route('admin.staff.store'), $newStaffData)
        ->assertSessionDoesntHaveErrors()
        ->assertStatus(302);

    $this->assertDatabaseHas(Staff::class, [
        'name' => $newStaffData['name'],
        'email' => $newStaffData['email'],
        'team_id' => $newStaffData['team'],
        'slack_user_id' => $newStaffData['slack_user_id'],
    ]);
});

it('should render the staff edit page', function () {
    $staff = StaffFactory::new()->admin()->createOne();
    $staffToEdit = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('admin.staff.edit', $staffToEdit))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('Admin/Staff/Edit')
            ->has('staff')
            ->has('teams'));
});

it('should update a staff member', function () {
    $staff = StaffFactory::new()->admin()->createOne();
    $staffToEdit = StaffFactory::new()->createOne();
    $team = TeamFactory::new()->createOne();

    $staffData = [
        'name' => fake()->name,
        'email' => fake()->email,
        'team' => $team->id,
        'slack_user_id' => 'USOMETHING',
    ];

    $this
        ->actingAs($staff)
        ->put(route('admin.staff.update', $staffToEdit), $staffData)
        ->assertSessionDoesntHaveErrors()
        ->assertStatus(302);

    $this->assertDatabaseHas(Staff::class, [
        'name' => $staffData['name'],
        'email' => $staffData['email'],
        'team_id' => $staffData['team'],
        'slack_user_id' => $staffData['slack_user_id'],
    ]);
});

it('should delete a staff member', function () {
    $staff = StaffFactory::new()->admin()->createOne();
    $staffToDelete = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->delete(route('admin.staff.destroy', $staffToDelete))
        ->assertSessionDoesntHaveErrors()
        ->assertStatus(303);

    $this->assertSoftDeleted(Staff::class, [
        'id' => $staffToDelete->id,
    ]);
});
