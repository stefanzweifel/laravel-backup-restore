<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Presenters;

use App\Models\DailyUpdates\Report\IndividualReport;
use App\Models\DailyUpdates\Report\Report;
use App\Utility\Chart\Chart;
use App\Utility\Chart\DataPoint;
use App\Utility\Chart\DataSet;
use App\Utility\Color;
use Inertia\Inertia;
use Inertia\Response;

/** @extends \App\Http\Controllers\DailyUpdates\Presenters\DailyUpdatePresenter<\App\Models\DailyUpdates\Report\IndividualReport> */
final class IndividualDailyUpdatePresenter extends DailyUpdatePresenter
{
    /** @inheritDoc */
    public function present(Report $report): Response
    {
        assert($report instanceof IndividualReport);

        $viewModel = [
            // Presentation
            'lastUpdatedAgo' => $report->lastUpdatedAt?->diffForHumans() ?? 'never',
            'analytics' => [
                'teamChartData' => new Chart(),
                'teamMembers' => [],
                'numberOfReports' => $this->getTotalNumberOfUpdates($report),
                'teamMemberChartData' => [
                    'weekly' => $this->formatChart($this->generateCharts($report->weeklyStats)),
                    'monthly' => $this->formatChart($this->generateCharts($report->monthlyStats)),
                ],
            ],
            'reports' => $report->updates,
            'leaves' => $report->leaves,
            'showReports' => true,
            'filters' => $this->getFilters(),
            'date' => $this->date(),
            'teamName' => $report->teamName,
            'staffName' => $report->staffName,
        ];

        return Inertia::render('DailyUpdates/Index', $viewModel);
    }

    /** @param array<string, array{updates: int, leaves: int, days: int}> $workingDaysData */
    private function generateCharts(array $workingDaysData): Chart
    {
        $chart = new Chart();
        $memberUpdatesDataSet = new DataSet();
        $leaveDaysDataSet = new DataSet();
        $numberOfWorkingDaysDataSet = new DataSet();
        $daysWorkedLessThanExpectedDataSet = new DataSet();
        $additionalWorkingDaysDataSet = new DataSet();
        $labels = [];

        foreach ($workingDaysData as $dateRange => $count) {
            $memberUpdatesDataSet->addDataPoint(new DataPoint(min($count['updates'], $count['days'])));
            $leaveDaysDataSet->addDataPoint(new DataPoint(min($count['leaves'], $count['days'])));
            $numberOfWorkingDaysDataSet->addDataPoint(new DataPoint($count['days'] / 100));
            $diffInDays = ($count['updates'] + $count['leaves']) - $count['days'];
            if ($diffInDays > 0) {
                $daysWorkedLessThanExpectedDataSet->addDataPoint(new DataPoint(0));
                $additionalWorkingDaysDataSet->addDataPoint(new DataPoint(abs($diffInDays)));
            } else {
                $daysWorkedLessThanExpectedDataSet->addDataPoint(new DataPoint(abs($diffInDays)));
                $additionalWorkingDaysDataSet->addDataPoint(new DataPoint(0));
            }

            $labels[] = $dateRange;
        }

        $memberUpdatesDataSet->setLegend('Number of daily updates');
        $memberUpdatesDataSet->setColor(Color::FULL->value);
        $leaveDaysDataSet->setLegend('Number of days with registered leave and no daily update');
        $leaveDaysDataSet->setColor(Color::LEAVE->value);
        $numberOfWorkingDaysDataSet->setLegend('Number of working days boundary');
        $numberOfWorkingDaysDataSet->setColor(Color::BOUNDARY->value);
        $daysWorkedLessThanExpectedDataSet->setLegend('Number of days without updates');
        $daysWorkedLessThanExpectedDataSet->setColor(Color::EXPECTED->value);
        $additionalWorkingDaysDataSet->setLegend('Additional days worked');
        $additionalWorkingDaysDataSet->setColor(Color::ADDITIONAL->value);
        $chart->addDataSet($memberUpdatesDataSet);
        $chart->addDataSet($leaveDaysDataSet);
        $chart->addDataSet($daysWorkedLessThanExpectedDataSet);
        $chart->addDataSet($numberOfWorkingDaysDataSet);
        $chart->addDataSet($additionalWorkingDaysDataSet);
        $chart->setDataPointsLabels($labels);

        return $chart;
    }

    /** @return array{members: int, fullDayUpdates: int, days: int, halfDayUpdates: int, numberOfFullDayHolidays: int, numberOfHalfDayHolidays: int} */
    private function getTotalNumberOfUpdates(IndividualReport $report): array
    {
        return [
            'members' => 1,
            'days' => $report->workingDays,
            'fullDayUpdates' => $report->numberOfFullDayReports,
            'halfDayUpdates' => $report->numberOfHalfDayReports,
            'numberOfFullDayHolidays' => $report->numberOfFullDayHolidays,
            'numberOfHalfDayHolidays' => $report->numberOfHalfDayHolidays,
        ];
    }
}
