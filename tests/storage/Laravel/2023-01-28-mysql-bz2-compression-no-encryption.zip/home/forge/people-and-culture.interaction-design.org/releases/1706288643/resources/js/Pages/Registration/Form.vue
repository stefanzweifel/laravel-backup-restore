<script setup lang="ts">
import {useForm} from '@inertiajs/inertia-vue3';

import {Team} from '@/types';

import GuestLayout from '@/Shared/GuestLayout.vue';

import FormSelect from '@/Components/Form/FormSelect.vue';
import FormInput from '@/Components/Form/FormInput.vue';
import BaseButton from '@/Components/BaseButton.vue';
import route from 'ziggy-js';
import {trans} from 'laravel-vue-i18n';

const props = defineProps<{
  staff: {
    avatar: {
      small: string;
      medium: string;
    };
    email: string;
    first_name: string;
    is: {
      admin: boolean;
    };
    slack_user_id: string | null;
  };
  teams: {
    int: Team
  };
}>();

const form = useForm('RegisterStaff', {
  avatar: props.staff.avatar.medium,
  email: props.staff.email,
  first_name: props.staff.first_name,
  team_id: null,
  slack_user_id: props.staff.slack_user_id || '',
});

const formSubmit = () => {
  form.post(route('registration.store'));
};
</script>

<template>
  <GuestLayout>
    <section class="md:w-3/4 mx-auto py-12">
      <h1 class="text-4xl font-bold mb-3">{{ trans('registration.title') }}</h1>
      <h2>{{ trans('registration.description') }}</h2>
      <form @submit.prevent="formSubmit">
        <div class="mt-8">
          <img
            class="rounded-full"
            :src="staff.avatar.medium"
            :alt="trans('registration.form.avatar.alt')"
          />
          <FormInput id="avatar" hidden label="Avatar" v-model="form.avatar" />
        </div>
        <div class="mt-8">
          <FormInput
            id="first_name"
            :label="trans('registration.form.name.label')"
            :value="staff.first_name"
            class="read-only:bg-gray-100"
            v-model="form.first_name"
            required
            readonly
            :error="form.errors.first_name"
          />
        </div>
        <div class="mt-8">
          <FormInput
            id="email"
            :label="trans('registration.form.email.label')"
            type="email"
            :value="staff.email"
            class="read-only:bg-gray-100"
            v-model="form.email"
            required
            readonly
            :error="form.errors.email"
          />
        </div>
        <div class="mt-8">
          <FormSelect
            id="team"
            :label="trans('staff.form.team.label')"
            v-model="form.team_id"
            required
            :error="form.errors.team_id"
            :placeholder="trans('registration.form.team.placeholder')"
          >
            <option disabled>Choose your team</option>
            <option v-for="(name, id) in teams" :key="id" :value="id">
              {{ name }}
            </option>
          </FormSelect>
        </div>
        <div class="mt-8">
          <FormInput
            id="slack_user_id"
            class="read-only:bg-gray-100"
            v-model="form.slack_user_id"
            :label="trans('registration.form.slack_user_id.label')"
            :placeholder="trans('staff.form.slack_user_id.placeholder')"
            :help-text="trans('staff.form.slack_user_id.helpText')"
            :error="form.errors.slack_user_id"
            required
          />
        </div>
        <BaseButton type="submit" class="mt-4" :disabled="form.processing">
          {{ trans('registration.form.submit') }}
        </BaseButton>
      </form>
    </section>
  </GuestLayout>
</template>
