<?php declare(strict_types=1);

namespace App\Http\Requests;

use App\Models\Staff;
use Illuminate\Foundation\Http\FormRequest as BaseFormRequest;

/**
 * Custom FormRequest implementation (abstract) that has correct defaults.
 */
abstract class FormRequest extends BaseFormRequest
{
    /**
     * Get the validation rules that apply to the request.
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint
     * @return array<string, list<mixed>>
     */
    abstract public function rules(): array;

    /**
     * Determine if the user is authorized to make this request.
     * It returns true because this is not a concern of the FormRequest class to do some authorization.
     */
    final public function authorize(): bool
    {
        return true;
    }

    /** @inheritDoc */
    public function user($guard = null): Staff
    {
        /** @var \App\Models\Staff $staff */
        $staff = parent::user($guard);

        return $staff;
    }
}
