<?php declare(strict_types=1);

namespace App\Notifications;

use App\Models\WeeklyUpdates\WeeklyUpdate;
use App\Services\Slack\IxDFSlackWebhookWorkspace;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Slack\BlockKit\Blocks\SectionBlock;
use Illuminate\Notifications\Slack\SlackMessage;

final class WeeklyUpdateSubmitted extends Notification
{
    public function __construct(public readonly WeeklyUpdate $weeklyUpdate)
    {
    }

    /**
     * Get the notification's delivery channels.
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint.DisallowedMixedTypeHint
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.ParameterTypeHint.MissingAnyTypeHint
     * @phpcsSuppress SlevomatCodingStandard.Functions.UnusedParameter.UnusedParameter
     * @return list<string>
     */
    public function via($notifiable)
    {
        return ['slack'];
    }

    /** Get the Slack representation of the notification. */
    public function toSlack(IxDFSlackWebhookWorkspace $notifiable): SlackMessage
    {
        $author = $this->weeklyUpdate->teamLead;

        $message = sprintf(
            '<@%s> has just submitted a *weekly* update for %s - %s:',
            $author->slack_user_id,
            $this->weeklyUpdate->reporting_week_end_date->clone()->startOfWeek()->toFormattedDateString(),
            $this->weeklyUpdate->reporting_week_end_date->clone()->endOfWeek()->toFormattedDateString()
        );

        return (new SlackMessage())
            ->username((string) config('ixdf_slack.weekly.webhook.username'))
            ->emoji((string) config('ixdf_slack.webhook.weekly.icon_url'))
            ->to($notifiable->getDefaultChannel())
            ->sectionBlock(static function (SectionBlock $sectionBlock) use ($message) {
                $sectionBlock->text($message)->markdown();
            })
            ->sectionBlock(function (SectionBlock $sectionBLock) {
                $sectionBLock->text("*Progress*\n{$this->weeklyUpdate->progress_last_week}")->markdown();
            })
            ->sectionBlock(function (SectionBlock $sectionBlock) {
                $sectionBlock->text("*Plans*\n{$this->weeklyUpdate->plans_this_week}")->markdown();
            })
            ->sectionBlock(function (SectionBlock $sectionBlock) {
                $sectionBlock->text("*Problems*\n{$this->weeklyUpdate->potential_problems}")->markdown();
            });
    }
}
