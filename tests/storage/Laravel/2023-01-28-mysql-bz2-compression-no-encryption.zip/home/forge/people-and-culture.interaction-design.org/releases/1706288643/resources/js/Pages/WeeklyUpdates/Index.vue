<script setup lang="ts">
import {Link, Head} from '@inertiajs/inertia-vue3';
import {getWeekNumberFromDate} from '@/vanilla/date';
import route from 'ziggy-js';
import {trans} from 'laravel-vue-i18n';

import Layout from '@/Shared/Layout.vue';
import WeeklyUpdateTable from '@/Components/WeeklyUpdateTable.vue';
import {WeeklyUpdateReport} from '@/types';

defineProps<{
  reports: WeeklyUpdateReport[];
}>();
</script>

<template>
  <Layout>
    <Head :title="trans('weeklyUpdates.indexTitle')" />

    <section class="py-12">
      <h1 class="text-4xl font-bold mb-3">
        {{ trans('weeklyUpdates.indexTitle') }}
      </h1>
      <p class="mb-3">
        {{ trans('weeklyUpdates.indexDescription') }}
        {{
          trans('weeklyUpdates.currentWeek', {
            year: new Date().getFullYear().toString(),
            week: getWeekNumberFromDate(new Date()).toString(),
          })
        }}
      </p>

      <div class="my-4">
        <Link
          :href="route('peopleAndCulture.weeklyUpdates.create')"
          class="text-white bg-brand-01 hover:bg-brand-02 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 dark:bg-brand-01 dark:hover:bg-brand-02 dark:focus:ring-blue-800"
        >
          ➕ {{ trans('weeklyUpdates.postAction') }}
        </Link>
      </div>
    </section>

    <WeeklyUpdateTable :reports="reports" />
  </Layout>
</template>
