<?php declare(strict_types=1);

namespace App\Services\Slack;

use Illuminate\Notifications\AnonymousNotifiable;
use Illuminate\Notifications\Notifiable;

final class IxDFSlackApiWorkspace extends AnonymousNotifiable
{
    use Notifiable;

    private string $channelOrUser;

    /**
     * $channelOrUser rules:
     *  - start channels from #
     *  - start users from @
     *
     * ⚠️ $channelOrUser currently used for interactive Slack notifications (rare case).
     * In 99.5 percent of cases, you need to specify a channel in a Notification class (toSlack() method).
     * Do You need to change the default channel for testing purposes? - Change SLACK_BOT_USER_DEFAULT_CHANNEL to your @name
     */
    public function __construct(?string $channelOrUser = null)
    {
        if ($channelOrUser === null) {
            $this->channelOrUser = '#'.config('services.slack.channel');
        }
    }

    /**
     * $channelOrUser rules:
     *  - start channels from #
     *  - start users from @
     *
     * ⚠️ $channelOrUser currently used for interactive Slack notifications (rare case).
     * In 99.5% percent of cases you need to specify a channel in a Notification class (toSlack() method).
     */
    public function setDefaultChannel(string $channelOrUser): self
    {
        $this->channelOrUser = $channelOrUser;
        return $this;
    }

    public function getDefaultChannel(): string
    {
        $channelToRedirectAllNotifications = config('ixdf_slack.channel_to_redirect_all_notifications');
        if (is_string($channelToRedirectAllNotifications) && $channelToRedirectAllNotifications !== '') {
            return $channelToRedirectAllNotifications;
        }

        return $this->channelOrUser;
    }

    /** Route notifications for the Slack channel. */
    public function routeNotificationForSlack(): string
    {
        return $this->getDefaultChannel();
    }
}
