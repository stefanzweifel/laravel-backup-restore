<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('peopleAndCulture__leaves', static function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('staff_id');
            $table->foreign('staff_id')->references('id')->on('peopleAndCulture__staff');
            $table->string('calendar_event_uid')->unique();
            $table->date('leave_date');
            $table->string('leave_period', 100); /** @see \App\Services\StaffLeave\LeavePeriod */
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('peopleAndCulture__leaves');
    }
};
