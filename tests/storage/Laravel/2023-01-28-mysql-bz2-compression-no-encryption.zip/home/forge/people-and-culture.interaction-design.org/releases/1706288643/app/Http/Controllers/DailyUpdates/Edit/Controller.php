<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Edit;

use App\Models\DailyUpdates\DailyUpdate;
use Illuminate\Support\Carbon;
use Inertia\Inertia;
use Inertia\Response;

final class Controller
{
    public function __invoke(DailyUpdate $dailyUpdate): Response
    {
        return Inertia::render('DailyUpdates/Edit', [
            'id' => $dailyUpdate->id,
            'submission_date' => Carbon::parse($dailyUpdate->reporting_date),
            'feeling' => $dailyUpdate->feeling,
            'update' => $dailyUpdate->done_today,
            'plans' => $dailyUpdate->plans_tomorrow,
            'blockers' => $dailyUpdate->blocked_progress,
            'highlights' => $dailyUpdate->highlights,
            'workday' => $dailyUpdate->is_full_day ? 'full' : 'half' ,
            'hours_worked' => $dailyUpdate->hours_worked,
            'holiday' => $dailyUpdate->has_leave ? '1' : '0',
        ]);
    }
}
