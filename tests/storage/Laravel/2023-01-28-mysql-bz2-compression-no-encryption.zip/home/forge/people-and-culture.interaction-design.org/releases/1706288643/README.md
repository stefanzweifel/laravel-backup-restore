[![Run tests and deploy](https://github.com/InteractionDesignFoundation/people-and-culture/actions/workflows/main.yml/badge.svg)](https://github.com/InteractionDesignFoundation/people-and-culture/actions/workflows/main.yml)
[![Static Analysis](https://github.com/InteractionDesignFoundation/people-and-culture/actions/workflows/static_analysis.yml/badge.svg)](https://github.com/InteractionDesignFoundation/people-and-culture/actions/workflows/static_analysis.yml)

# People and Culture System

## Authentication

Authentication happens using OAuth login with IxDF. Only IxDF admins are allowed
to use this app. Regular members should face an error trying to log in.

## Installation

### First installation
- Create a new `.env` file from .env.example: `cp .env.example .env`
- Review .env file for port forwarding variables, optionally uncomment them and update their values
- Run Docker containers in the background: `docker-compose up -d` or `./vendor/bin/sail up -d`
- Install composer dependencies: `docker-compose exec app composer install` (or use local composer as a faster alternative)
- Regenerate a Laravel app key: `docker-compose exec app php artisan key:generate` (or use locally installed PHP as a faster alternative)
- Run migrations: `docker-compose exec app php artisan migrate`
- Migrate the testing database: `docker-compose exec app php artisan migrate --env=testing`
- **Dev env step only**: Run DB seeders: `docker-compose exec app php artisan db:seed --class=DevelopmentDatabaseSeeder`
- Install npm dependencies: `yarn install`
- **Dev env step only**: Run [vite development server](https://laravel.com/docs/master/vite#running-vite): `yarn dev`


## Daily Usage

- Run Docker containers in the background: `docker-compose up -d` or `./vendor/bin/sail up -d`. The local site will be accessible on either port 80 or on a different port specified by the `APP_PORT` environment variable.
- Run [vite development server](https://laravel.com/docs/master/vite#running-vite): `yarn dev`


### Run Tests

Run `docker-compose exec app php artisan test` or `./vendor/bin/sail test`


### Stop and remove Docker containers

Run `docker-compose down` or `./vendor/bin/sail down`


## Deployment

a) Just tag a new version on [GitHub UI](https://github.com/InteractionDesignFoundation/people-and-culture/releases) (publish an existing Draft, if any).
b) `./deployer.phar depoy production` (if Deployer not installed: use `composer deployer:install`)
