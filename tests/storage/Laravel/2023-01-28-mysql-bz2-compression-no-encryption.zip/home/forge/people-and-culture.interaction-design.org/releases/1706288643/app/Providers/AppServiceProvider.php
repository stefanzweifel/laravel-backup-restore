<?php declare(strict_types=1);

namespace App\Providers;

use App\Utility\GitHubUrl;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\ParallelTesting;
use Illuminate\Support\ServiceProvider;
use Laravel\Sanctum\Sanctum;

final class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        Sanctum::ignoreMigrations(); // we don’t use this feature

        $this->app->singleton(GitHubUrl::class, static fn () => new GitHubUrl(sprintf('%s/%s', config('release.github.organisation'), config('release.github.repository'))));

        ParallelTesting::setUpTestDatabase(static function (): void {
            Artisan::call('db:seed');
        });
    }
}
