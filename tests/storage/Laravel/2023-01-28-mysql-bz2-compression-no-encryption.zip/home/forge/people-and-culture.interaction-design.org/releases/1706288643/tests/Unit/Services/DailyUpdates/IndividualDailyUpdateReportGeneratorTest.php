<?php declare(strict_types=1);

namespace Tests\Unit\Services\DailyUpdates;

use App\Services\DailyUpdates\IndividualDailyUpdateReportGenerator;
use App\ValueObjects\DatetimeRange;
use Database\Factories\DailyUpdates\DailyUpdateFactory;
use Database\Factories\StaffFactory;
use Illuminate\Support\Carbon;

it('should not count other peoples updates', function () {
    Carbon::setTestNow(Carbon::parse('2022-02-09 12:00'));
    $jan24th = now()->startOf('week')->subWeeks(2);
    $jan25th = $jan24th->clone()->addDay();
    $jan30th = now()->startOf('week')->subWeeks(2)->endOfWeek();
    $staff = StaffFactory::new()->createOne();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($jan25th)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($staff, new DatetimeRange($jan24th, $jan30th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($jan24th, $jan30th)
        ->withMonthlyStat('Jan 2022')
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 1)
        ->withStaff($staff)
        ->withWorkingDays(5)
        ->withReportStats(fullDayHolidays: 5)
        ->withLastUpdatedAt($update->created_at)
        ->build();
    $this->assertEquals($expected, $report);
});

it('should work for weekly report with one full day report on weekday mid month', function () {
    Carbon::setTestNow(Carbon::parse('2022-02-09 12:00'));
    $jan24th = now()->startOf('week')->subWeeks(2);
    $jan25th = $jan24th->clone()->addDay();
    $jan30th = now()->startOf('week')->subWeeks(2)->endOfWeek();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($jan25th)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($update->staff, new DatetimeRange($jan24th, $jan30th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($jan24th, $jan30th)
        ->withMonthlyStat('Jan 2022', updates: 1)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 1)
        ->withWeeklyStat(4)
        ->withStaff($update->staff)
        ->withWorkingDays(5)
        ->withUpdates([$update])
        ->withReportStats(fullDayReports: 1, fullDayHolidays: 4)
        ->build();
    $this->assertEquals($expected, $report);
});

it('should work for weekly report with one half day report on weekday mid month', function () {
    Carbon::setTestNow(Carbon::parse('2022-02-09 12:00'));
    $jan24th = now()->startOf('week')->subWeeks(2);
    $jan25th = $jan24th->clone()->addDay();
    $jan30th = now()->startOf('week')->subWeeks(2)->endOfWeek();
    $update = DailyUpdateFactory::new()->halfDay()->reportedAt($jan25th)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($update->staff, new DatetimeRange($jan24th, $jan30th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($jan24th, $jan30th)
        ->withMonthlyStat('Jan 2022', updates: 1)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 1)
        ->withWeeklyStat(4)
        ->withStaff($update->staff)
        ->withWorkingDays(5)
        ->withUpdates([$update])
        ->withReportStats(halfDayReports: 1, fullDayHolidays: 4, halfDayHolidays: 1)
        ->build();
    $this->assertEquals($expected, $report);
});

it('should work for weekly report with multiple reports on weekday mid month', function () {
    Carbon::setTestNow(Carbon::parse('2021-11-18 12:00'));
    $nov8th = now()->startOf('week')->subWeek();
    $nov9th = $nov8th->clone()->addDay();
    $nov10th = $nov8th->clone()->addDays(2);
    $nov12th = $nov8th->clone()->addDays(4);
    $nov14th = now()->startOf('week')->subWeek()->endOfWeek();
    $staff = StaffFactory::new()->createOne();
    $updates = [
        DailyUpdateFactory::new()
            ->for($staff, 'staff')->halfDay()->reportedAt($nov9th)->createOne(),
        DailyUpdateFactory::new()
            ->for($staff, 'staff')->fullDay()->reportedAt($nov10th)->createOne(),
        DailyUpdateFactory::new()
            ->for($staff, 'staff')->fullDay()->reportedAt($nov12th)->createOne(),
    ];
    $sut = new IndividualDailyUpdateReportGenerator($staff, new DatetimeRange($nov8th, $nov14th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($nov8th, $nov14th)
        ->withMonthlyStat('Nov 2021', updates: 3, days: 22)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 42, year: 2021)
        ->withWeeklyStat(week: 45, year: 2021, updates: 3)
        ->withStaff($staff)
        ->withWorkingDays(5)
        ->withUpdates($updates)
        ->withReportStats(fullDayReports: 2, halfDayReports: 1, fullDayHolidays: 2, halfDayHolidays: 1)
        ->build();
    $this->assertEquals($expected, $report);
});

it('should work for monthly report with one full day report on weekday mid month', function () {
    Carbon::setTestNow(Carbon::parse('2022-03-09 12:00'));
    $feb1st = now()->subMonth()->startOfMonth();
    $feb25th = now()->subMonth()->setDay(25);
    $feb28th = now()->subMonth()->endOfMonth();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($feb25th)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($update->staff, new DatetimeRange($feb1st, $feb28th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($feb1st, $feb28th)
        ->withMonthlyStat('Feb 2022', updates: 1, days: 20)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 5, numberOfWeeks: 5)
        ->withWeeklyStat(week: 8)
        ->withStaff($update->staff)
        ->withWorkingDays(20)
        ->withUpdates([$update])
        ->withReportStats(fullDayReports: 1, fullDayHolidays: 19)
        ->build();
    $this->assertEquals($expected, $report);
});

it('should work for monthly report with one full day report on first day of month', function () {
    Carbon::setTestNow(Carbon::parse('2022-03-09 12:00'));
    $feb1st = now()->subMonth()->startOfMonth();
    $feb28th = now()->subMonth()->endOfMonth();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($feb1st)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($update->staff, new DatetimeRange($feb1st, $feb28th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($feb1st, $feb28th)
        ->withMonthlyStat('Feb 2022', updates: 1, days: 20)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 6)
        ->withWeeklyStat(week: 5)
        ->withStaff($update->staff)
        ->withWorkingDays(20)
        ->withUpdates([$update])
        ->withReportStats(fullDayReports: 1, fullDayHolidays: 19)
        ->build();
    $this->assertEquals($expected, $report);
});

it('it should work for monthly report with one full day report on last day of month', function () {
    Carbon::setTestNow(Carbon::parse('2022-03-09 12:00'));
    $feb1st = now()->subMonth()->startOfMonth();
    $feb28th = now()->subMonth()->endOfMonth();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($feb28th)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($update->staff, new DatetimeRange($feb1st, $feb28th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($feb1st, $feb28th)
        ->withMonthlyStat('Feb 2022', updates: 1, days: 20)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 5)
        ->withWeeklyStat(week: 9)
        ->withStaff($update->staff)
        ->withWorkingDays(20)
        ->withUpdates([$update])
        ->withReportStats(fullDayReports: 1, fullDayHolidays: 19)
        ->build();
    $this->assertEquals($expected, $report);
});

it('it should work for weekly report with one full day report on week start', function () {
    Carbon::setTestNow(Carbon::parse('2022-03-09 12:00'));
    $feb21st = Carbon::parse('2022-02-21');
    $feb27th = Carbon::parse('2022-02-27');
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($feb21st)->createOne();
    $sut = new IndividualDailyUpdateReportGenerator($update->staff, new DatetimeRange($feb21st, $feb27th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($feb21st, $feb27th)
        ->withMonthlyStat('Feb 2022', updates: 1, days: 20)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 5)
        ->withWeeklyStat(week: 8)
        ->withStaff($update->staff)
        ->withWorkingDays(5)
        ->withUpdates([$update])
        ->withReportStats(fullDayReports: 1, fullDayHolidays: 4)
        ->build();
    $this->assertEquals($expected, $report);
});

it('it should work for weekly report with one full day report on 3 last weeks', function () {
    Carbon::setTestNow(Carbon::parse('2022-03-09 12:00'));
    $feb21st = Carbon::parse('2022-02-21');
    $feb27th = Carbon::parse('2022-02-27');

    $staff = StaffFactory::new()->createOne();
    DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-09'))->createOne();
    DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-12'))->createOne();
    DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-18'))->createOne();
    DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-20'))->createOne();
    $lastUpdate = DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-28'))->createOne();

    $sut = new IndividualDailyUpdateReportGenerator($staff, new DatetimeRange($feb21st, $feb27th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($feb21st, $feb27th)
        ->withMonthlyStat('Feb 2022', updates: 5, days: 20)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 5)
        ->withWeeklyStat(week: 6, updates: 2)
        ->withWeeklyStat(week: 7, updates: 2)
        ->withStaff($staff)
        ->withWorkingDays(5)
        ->withReportStats(fullDayHolidays: 5)
        ->withLastUpdatedAt($lastUpdate->created_at)
        ->build();
    $this->assertEquals($expected, $report);
});

it('it should work for weekly reports on weeks spanning two months', function () {
    Carbon::setTestNow(Carbon::parse('2022-04-04 12:00'));
    $march28th = Carbon::parse('2022-03-28');
    $april3rd = Carbon::parse('2022-04-03');

    $staff = StaffFactory::new()->createOne();
    $updates = [
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-03-28'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-03-29'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-03-30'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-03-31'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-04-01'))->createOne(),
    ];

    $sut = new IndividualDailyUpdateReportGenerator($staff, new DatetimeRange($march28th, $april3rd));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($march28th, $april3rd)
        ->withMonthlyStat('Mar 2022', updates: 4, days: 23)
        ->withMonthlyStat('Apr 2022', updates: 1, days: 21)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 10)
        ->withWeeklyStat(week: 13, updates: 5)
        ->withStaff($staff)
        ->withWorkingDays(5)
        ->withReportStats(fullDayReports: 5)
        ->withUpdates($updates)
        ->build();
    $this->assertEquals($expected, $report);
});

it('it should work for monthly report with multiple reports', function () {
    Carbon::setTestNow(Carbon::parse('2022-02-23 12:00'));
    $feb1st = Carbon::parse('2022-02-01');
    $feb28th = Carbon::parse('2022-02-30');

    $staff = StaffFactory::new()->createOne();
    /** @var array<\App\Models\DailyUpdates\DailyUpdate> $updates */
    $updates = [
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-01'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-09'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-12'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-18'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-19'))->createOne(),
        DailyUpdateFactory::new()->for($staff, 'staff')->fullDay()->reportedAt(Carbon::parse('2022-02-20'))->createOne(),
    ];

    $sut = new IndividualDailyUpdateReportGenerator($staff, new DatetimeRange($feb1st, $feb28th));

    $report = $sut->generate();

    $expected = IndividualReportBuilder::of($feb1st, $feb28th)
        ->withMonthlyStat('Feb 2022', updates: 6, days: 20)
        ->withWeeklyStatsWithZeroUpdates(fromWeek: 5, numberOfWeeks: 5)
        ->withWeeklyStat(week: 5)
        ->withWeeklyStat(week: 6, updates: 2)
        ->withWeeklyStat(week: 7, updates: 3)
        ->withStaff($staff)
        ->withWorkingDays(16)
        ->withUpdates($updates)
        ->withReportStats(fullDayReports: 6, fullDayHolidays: 10)
        ->build();
    $this->assertEquals($expected, $report);
});
