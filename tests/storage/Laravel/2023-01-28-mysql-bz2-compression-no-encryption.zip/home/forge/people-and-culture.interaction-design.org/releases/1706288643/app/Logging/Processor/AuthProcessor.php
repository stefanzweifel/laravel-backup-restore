<?php declare(strict_types=1);

namespace App\Logging\Processor;

use App\Models\Staff;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Monolog\LogRecord;
use Monolog\Processor\ProcessorInterface;

/** Adds additional request data to the log message */
final class AuthProcessor implements ProcessorInterface
{
    /**
     * @psalm-suppress LessSpecificImplementedReturnType
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint
     */
    public function __invoke(LogRecord $record): LogRecord // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
    {
        if (App::runningInConsole()) {
            return $record;
        }

        try {
            /** @var \Illuminate\Contracts\Auth\Authenticatable|null $authenticatable */
            $authenticatable = Auth::user();
        } catch (\Throwable) {
            $record['extra']['visitor'] = 'Couldn’t fetch visitor’s info';
            return $record;
        }

        if ($authenticatable instanceof Authenticatable) {
            $record['extra']['visitor']['id'] = $authenticatable->getAuthIdentifier();
            $record['extra']['visitor']['type'] = class_basename($authenticatable);

            if ($authenticatable instanceof Staff) {
                $record['extra']['visitor']['name'] = $authenticatable->getName();
                $record['extra']['visitor']['email'] = $authenticatable->getEmailAddress();
            }
        } else {
            $record['extra']['visitor']['type'] = 'guest';
        }

        return $record;
    }
}
