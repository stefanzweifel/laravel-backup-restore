<?php declare(strict_types=1);

namespace App\Http\Controllers\Auth;

use App\Models\Staff;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

/** @psalm-type OAuthData = array{first_name: string, last_name: string, email: string, timezone: (string|null), avatar: array{small: string, medium: string}, 'is': array<string, bool>} */
final class AuthController
{
    public function create(): Response
    {
        return Inertia::render('Auth/Login');
    }

    public function store(Request $request): \Symfony\Component\HttpFoundation\Response
    {
        $request->session()->put('state', $state = Str::random(40));

        $request->session()->put(
            'code_verifier',
            $codeVerifier = Str::random(128)
        );

        $codeChallenge = strtr(rtrim(
            base64_encode(hash('sha256', $codeVerifier, true)),
            '='
        ), '+/', '-_');

        $query = http_build_query([
            'client_id' => config('ixdf_oauth.client_id'),
            'redirect_uri' => route('auth.callback'),
            'response_type' => 'code',
            'scope' => 'profile-read',
            'state' => $state,
            'code_challenge' => $codeChallenge,
            'code_challenge_method' => 'S256',
        ]);

        return Inertia::location(config('ixdf_oauth.authorization_url').'?'.$query);
    }

    public function callback(Request $request): RedirectResponse
    {
        $state = $request->session()->pull('state');

        $codeVerifier = $request->session()->pull('code_verifier');

        throw_unless(
            $state !== '' && $state === $request->input('state'),
            \InvalidArgumentException::class
        );

        $response = Http::asForm()->post(config('ixdf_oauth.token_url'), [
            'grant_type' => 'authorization_code',
            'client_id' => config('ixdf_oauth.client_id'),
            'redirect_uri' => route('auth.callback'),
            'code_verifier' => $codeVerifier,
            'code' => $request->input('code'),
        ]);

        if ($response->failed()) {
            return redirect()->route('auth.login')->with('error', $response->json('error_description'));
        }

        $accessToken = $response->json('access_token');

        $response = Http::withHeaders([
            'Accept' => 'application/json',
            'Authorization' => 'Bearer '.$accessToken,
        ])->get(config('ixdf_oauth.profile_url'));

        if ($response->failed()) {
            return redirect()->route('auth.login')->with('error', $response->json('error_description'));
        }

        /** @psalm-var OAuthData $userData */
        $userData = $response->json();
        if (($userData['is']['admin'] ?? false) !== true) {
            abort(403, 'It seems like you are not an IxDF staff member. Please ping the developers if you are :)');
        }

        $staff = Staff::query()->firstWhere('email', $userData['email']);
        if (! $staff instanceof Staff) {
            return redirect()->to(route('registration.create'))->with(['staff' => $userData]);
        }

        $this->updateInfoIfNecessary($userData, $staff);

        Auth::login($staff);

        return redirect()->intended(RouteServiceProvider::HOME);
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): \Illuminate\Http\RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->to('/');
    }

    /**
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint
     * @param array<string, mixed> $userData
     * @psalm-param OAuthData $userData
     */
    private function updateInfoIfNecessary(array $userData, Staff $staff): void
    {
        if ($staff->avatar_url === $userData['avatar']['small']) {
            $staff->avatar_url = $userData['avatar']['small'];
        }

        if ($staff->timezone !== $userData['timezone']) {
            $staff->timezone = $userData['timezone'];
        }

        if ($staff->isDirty()) {
            $staff->save();
        }
    }
}
