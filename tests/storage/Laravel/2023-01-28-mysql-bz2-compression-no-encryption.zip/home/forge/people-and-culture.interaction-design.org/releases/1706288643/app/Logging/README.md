# Logging

See official [Laravel Logging documentation](https://laravel.com/docs/logging)
