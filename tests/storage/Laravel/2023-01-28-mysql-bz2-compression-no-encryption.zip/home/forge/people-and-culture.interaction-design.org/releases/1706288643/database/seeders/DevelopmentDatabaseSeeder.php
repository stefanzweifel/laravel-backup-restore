<?php declare(strict_types=1);

namespace Database\Seeders;

use Database\Factories\DailyUpdates\DailyUpdateFactory;
use Database\Factories\StaffFactory;
use Database\Factories\StaffLeave\StaffLeaveFactory;
use Database\Factories\TeamFactory;
use Database\Factories\WeeklyUpdates\WeeklyUpdateFactory;
use Illuminate\Database\Eloquent\Factories\Sequence;
use Illuminate\Database\Seeder;

final class DevelopmentDatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $teamFactory = TeamFactory::new()
            ->count(6)
            ->state(new Sequence(
                ['slug' => 'development', 'name' => 'Development'],
                ['slug' => 'growth', 'name' => 'Growth'],
                ['slug' => 'editorial', 'name' => 'Editorial'],
                ['slug' => 'member-experience', 'name' => 'Member Experience and Operations'],
                ['slug' => 'design', 'name' => 'Product Design'],
                ['slug' => 'video', 'name' => 'Video Production']
            ));

        try {
            $teams = $teamFactory->create();
        } catch (\Illuminate\Database\QueryException) {
            echo "DB is already seeded by test data, nothing to do this time.\n\n";
            return;
        }

        foreach ($teams as $team) {
            $teamMembers = StaffFactory::new()->count(5)->create(['team_id' => $team->getKey()]);
            foreach ($teamMembers as $teamMember) {
                DailyUpdateFactory::new()->count(10)->create([
                    'staff_id' => $teamMember->getKey(),
                ]);

                WeeklyUpdateFactory::new()->count(2)->create([
                    'team_lead_id' => $teamMember->getKey(),
                ]);

                StaffLeaveFactory::new()->count(2)->create([
                    'staff_id' => $teamMember->getKey(),
                ]);
            }
        }
    }
}
