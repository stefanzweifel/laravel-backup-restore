<?php declare(strict_types=1);

return [
    'title' => 'Create your profile',
    'description' => "It seems you don't have a staff profile yet, let's create it!",
    'form' => [
        'avatar' => [
            'alt' => 'Staff image',
        ],
        'name' => [
            'label' => '<b>Name</b>',
        ],
        'email' => [
            'label' => '<b>Email</b>',
        ],
        'team' => [
            'label' => '<b>Team</b>',
            'placeholder' => 'Select a team',
        ],
        'slack_user_id' => [
            'label' => '<b>Member ID on Slack</b>',
            'placeholder' => 'Example: U04U6E1J5S5',
            'helpText' => 'See <a href="https://www.workast.com/help/article/how-to-find-a-slack-user-id/" target="_blank" class="underline text-blue-600">how to find it</a>. Used for Slack and Spock integration.',
        ],
        'submit' => 'Finish registration',
    ],
];
