<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Store;

use App\Http\Requests\DailyUpdate\PostDailyUpdateRequest;
use App\Models\Staff;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

final class Controller
{
    public function __invoke(PostDailyUpdateRequest $request): RedirectResponse
    {
        $staff = Auth::user();
        assert($staff instanceof Staff);

        $staff->createDailyUpdate($request->validated());

        return redirect()->route('peopleAndCulture.dailyUpdates.index', [
            'range' => $request->currentWeekAsDateRange(),
            'by' => "staff:$staff->email",
        ])->with('success', 'Thanks for posting your update 💛💙❤️🤍❤️💚🧡💜');
    }
}
