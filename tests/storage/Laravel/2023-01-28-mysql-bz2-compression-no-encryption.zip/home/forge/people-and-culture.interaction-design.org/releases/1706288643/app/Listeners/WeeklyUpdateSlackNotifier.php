<?php declare(strict_types=1);

namespace App\Listeners;

use App\Events\WeeklyUpdateSubmitted;
use App\Services\Slack\IxDFSlackWebhookWorkspace;

final class WeeklyUpdateSlackNotifier
{
    public function __construct(private readonly IxDFSlackWebhookWorkspace $slackWorkspace)
    {
    }

    public function handle(WeeklyUpdateSubmitted $event): void
    {
        $weeklyUpdate = $event->weeklyUpdate;

        $this->slackWorkspace->setDefaultChannel((string) config('ixdf_slack.channel_for_all_updates'))
            ->notify(new \App\Notifications\WeeklyUpdateSubmitted($weeklyUpdate));

        $channel = $weeklyUpdate->teamLead->team->channel_for_updates;
        if (is_string($channel)) {
            $this->slackWorkspace->setDefaultChannel($channel)
                ->notify(new \App\Notifications\WeeklyUpdateSubmitted($weeklyUpdate));
        }
    }
}
