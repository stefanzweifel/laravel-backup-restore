<script setup lang="ts">
import {Head, Link} from '@inertiajs/inertia-vue3';
import {trans} from 'laravel-vue-i18n';
import route from 'ziggy-js';
import {Staff} from '@/types';

import Layout from '@/Shared/Layout.vue';
import StaffTable from '@/Components/StaffTable.vue';

defineProps<{
  staff: Staff[];
}>();
</script>

<template>
  <Layout>
    <Head title="Team management" />
    <section class="py-12">
      <div class="my-4">
        <Link
          :href="route('admin.staff.create')"
          class="text-white bg-brand-01 hover:bg-brand-02 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 dark:bg-brand-01 dark:hover:bg-brand-02 dark:focus:ring-blue-800"
        >
          {{ trans('staff.add') }}
        </Link>
      </div>
    </section>
    <StaffTable :staff="staff" />
  </Layout>
</template>
