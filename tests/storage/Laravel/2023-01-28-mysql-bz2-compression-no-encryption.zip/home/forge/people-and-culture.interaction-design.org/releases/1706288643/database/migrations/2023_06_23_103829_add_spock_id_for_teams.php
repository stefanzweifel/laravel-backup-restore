<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('peopleAndCulture__team', static function (Blueprint $table): void {
            $table->unsignedSmallInteger('spock_team_id')->after('symbol');
        });
    }

    public function down(): void
    {
        Schema::dropColumns('peopleAndCulture__team', ['spock_team_id']);
    }
};
