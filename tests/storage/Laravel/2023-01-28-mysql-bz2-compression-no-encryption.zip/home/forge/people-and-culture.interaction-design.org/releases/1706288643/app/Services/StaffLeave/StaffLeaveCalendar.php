<?php declare(strict_types=1);

namespace App\Services\StaffLeave;

use ICal\ICal;
use Illuminate\Support\Collection;

final readonly class StaffLeaveCalendar
{
    /** @return \Illuminate\Support\Collection<int, \App\Services\StaffLeave\StaffLeaveEvent> */
    public function getEvents(int $daysInThePast, int $daysInTheFuture): Collection
    {
        /** @var array<int, \ICal\Event> $events */
        $events = $this->loadCalendar($daysInThePast, $daysInTheFuture)->events();

        return collect(array_map(static fn (\ICal\Event $event) => StaffLeaveEvent::fromICalEvent($event), $events));
    }

    private function loadCalendar(int $daysInThePast, int $daysInTheFuture): ICal
    {
        return new ICal($this->calendarUrl(), [
            'filterDaysBefore' => $daysInThePast,
            'filterDaysAfter' => $daysInTheFuture,
        ]);
    }

    private function calendarUrl(): string
    {
        return (string) config('ixdf_spock.calendar');
    }
}
