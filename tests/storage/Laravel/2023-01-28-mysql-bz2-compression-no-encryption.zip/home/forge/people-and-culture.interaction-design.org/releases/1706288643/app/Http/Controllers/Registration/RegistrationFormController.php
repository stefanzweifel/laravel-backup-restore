<?php declare(strict_types=1);

namespace App\Http\Controllers\Registration;

use App\Models\Team;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

final class RegistrationFormController
{
    public function __invoke(Request $request): Response | RedirectResponse
    {
        $staffData = $request->session()->get('staff');
        if ($staffData === null) {
            return redirect()->to(route('auth.login'));
        }

        return Inertia::render('Registration/Form', [
            'teams' => Team::query()->orderBy('name')->pluck('name', 'id'),
            'staff' => $request->session()->get('staff'),
        ]);
    }
}
