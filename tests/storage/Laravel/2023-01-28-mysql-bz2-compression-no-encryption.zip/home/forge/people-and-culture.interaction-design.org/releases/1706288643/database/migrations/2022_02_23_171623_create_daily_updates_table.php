<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('peopleAndCulture__daily_update_sheets', static function (Blueprint $table): void {
            $table->increments('id');
            $table->string('sheet_id')->comment('Google sheet Id of import source');
            $table->string('range')->comment('Range of columns and rows imported');
            $table->unsignedInteger('last_index')->nullable();
            $table->boolean('is_success')->comment('Was the import successful?');
            $table->timestamps();
        });

        Schema::create('peopleAndCulture__daily_updates', static function (Blueprint $table): void {
            $table->increments('id');
            $table->unsignedBigInteger('staff_id')->nullable();
            $table->foreign('staff_id')->references('id')->on('peopleAndCulture__staff');
            $table->date('reporting_date');
            $table->unsignedTinyInteger('feeling')->comment('How do you feel today?');
            $table->text('done_today')->comment('What did you do? Please focus on results.');
            $table->text('plans_tomorrow')->comment('What are your concrete plans for your next workday?');
            $table->text('blocked_progress')->comment('Is there anything blocking your progress?');
            $table->boolean('is_full_day')->default(true)->comment('Did you work a full day or half a day?');
            $table->boolean('has_leave')->default(false)->comment('Did you have any leave (holiday, sick days, etc.) since your last update?');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('peopleAndCulture__daily_updates');
        Schema::dropIfExists('peopleAndCulture__daily_update_sheets');
    }
};
