<?php declare(strict_types=1);

namespace App\Http\Requests\WeeklyUpdates;

use App\Http\Requests\FormRequest;
use App\Models\WeeklyUpdates\WeeklyUpdate;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

final class PostWeeklyUpdatesRequest extends FormRequest
{
    /** @inheritDoc */
    public function rules(): array
    {
        return [
            'reporting_week_end_date' => ['required', 'date', Rule::unique((new WeeklyUpdate())->getTable())->where(static function (Builder $query) {
                return $query->where('team_lead_id', Auth::id());
            })],
            'update' => ['required'],
            'plans' => ['required'],
            'blockers' => ['required'],
            'notes' => ['nullable'],
        ];
    }

    /** @inheritDoc */
    public function messages(): array
    {
        return [
            'unique' => 'There’s already an update for that week. Contact a developer if you have problems 🙂',
        ];
    }

    /** @inheritDoc */
    protected function prepareForValidation()
    {
        $this->merge([
            'reporting_week_end_date' => Carbon::parse($this->input('reporting_week_end_date'))->endOfWeek(Carbon::FRIDAY)->format('Y-m-d'),
        ]);
    }
}
