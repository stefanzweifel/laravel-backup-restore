<?php declare(strict_types=1);

namespace App\Events;

use App\Models\WeeklyUpdates\WeeklyUpdate;

final readonly class WeeklyUpdateSubmitted
{
    public function __construct(public WeeklyUpdate $weeklyUpdate)
    {
    }
}
