<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Destroy;

use App\Http\Requests\DailyUpdate\DailyUpdateAnalyticsRequest;
use App\Models\DailyUpdates\DailyUpdate;
use App\Models\Staff;
use Carbon\CarbonInterface;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

final class Controller
{
    public function __invoke(DailyUpdate $dailyUpdate): RedirectResponse
    {
        $staff = Auth::user();
        assert($staff instanceof Staff);

        $dailyUpdate->delete();

        $startOfTheWeek = now()->copy()->startOfDay()->modify('previous Monday');
        assert($startOfTheWeek instanceof CarbonInterface);

        $endOfTheWeek = now()->copy()->endOfDay()->modify('next Sunday');
        assert($endOfTheWeek instanceof CarbonInterface);

        $dateRange = DailyUpdateAnalyticsRequest::convertDateRangeForUrl([$startOfTheWeek, $endOfTheWeek]);

        return redirect()->route('peopleAndCulture.dailyUpdates.index', [
            'range' => $dateRange,
            'by' => "staff:$staff->email",
        ], 303)->with('success', 'Daily update deleted');
    }
}
