<?php declare(strict_types=1);

namespace Tests\Services\Slack;

use App\Services\Slack\UserLinker;
use PHPUnit\Framework\TestCase;

/** @covers \App\Services\Slack\UserLinker */
final class UserLinkerTest extends TestCase
{
    /** @test */
    public function it_replaces_known_user_name_by_user_id(): void
    {
        $userLinker = new UserLinker();

        $result = $userLinker->linkNames('Hello @John and @John and @Liz!', ['John' => 'U42', 'Liz' => 'U43']);

        $this->assertSame('Hello <@U42> and <@U42> and <@U43>!', $result);
    }

    /** @test */
    public function it_does_not_replace_unknown_user_name_by_user_id(): void
    {
        $userLinker = new UserLinker();

        $result = $userLinker->linkNames('Hello @UnknownSlackUser!', ['John' => 'U42']);

        $this->assertSame('Hello @UnknownSlackUser!', $result);
    }
}
