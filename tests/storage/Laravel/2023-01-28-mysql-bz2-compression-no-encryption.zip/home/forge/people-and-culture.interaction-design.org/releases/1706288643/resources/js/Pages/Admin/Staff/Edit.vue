<script setup lang="ts">
import {Head} from '@inertiajs/inertia-vue3';
import {trans} from 'laravel-vue-i18n';
import {Staff, Team} from '@/types';

import Layout from '@/Shared/Layout.vue';
import StaffForm from '@/Components/StaffForm.vue';

defineProps<{
  staff: Staff;
  teams: Team[];
}>();
</script>

<template>
  <Layout>
    <Head :title="trans('staff.form.editTitle', {name: staff.name})" />
    <section class="md:w-3/4 mx-auto py-12">
      <h1 class="text-4xl font-bold mb-3">
        {{ trans('staff.form.editTitle', {name: staff.name}) }}
      </h1>
      <StaffForm :teams="teams" :staff="staff" />
    </section>
  </Layout>
</template>
