<?php declare(strict_types=1);

namespace App\Notifications;

use App\Models\Staff;
use App\Services\Slack\IxDFSlackApiWorkspace;
use App\Services\StaffLeave\LeavePeriod;
use App\ValueObjects\DatetimeRange;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Slack\BlockKit\Blocks\ContextBlock;
use Illuminate\Notifications\Slack\BlockKit\Blocks\SectionBlock;
use Illuminate\Notifications\Slack\BlockKit\Elements\ImageElement;
use Illuminate\Notifications\Slack\SlackMessage;
use Illuminate\Support\Str;

/**
 * @see https://app.slack.com/block-kit-builder
 * @see https://quickchart.io/documentation/send-charts-with-slack-bot
 * @psalm-type StaffWeeklyStatistics = array{"fullDayUpdates": int, "partDayUpdates": int, "fullDayLeaves": int, "partDayLeaves": int, missingUpdates: float, expectedUpdates: int<0, 5>}
 */
final class WeeklyDigest extends Notification
{
    private const NUMBER_OF_DAYS_IN_A_WEEK = 7;

    /** @param \Illuminate\Database\Eloquent\Collection<int, \App\Models\Team> $teams */
    public function __construct(private readonly DatetimeRange $weekDateRange, private readonly Collection $teams)
    {
    }

    /**
     * Get the notification's delivery channels.
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint.DisallowedMixedTypeHint
     * @phpcsSuppress SlevomatCodingStandard.Functions.UnusedParameter.UnusedParameter
     * @return list<string>
     */
    public function via(): array
    {
        return ['slack'];
    }

    /** Get the Slack representation of the notification. */
    public function toSlack(IxDFSlackApiWorkspace $notifiable): SlackMessage // phpcs:ignore SlevomatCodingStandard.Files.FunctionLength.FunctionLength, SlevomatCodingStandard.Functions.FunctionLength.FunctionLength
    {
        $slackMessage = (new SlackMessage())
            ->to($notifiable->getDefaultChannel())
            ->text('Daily updates and leaves weekly digest is available!')
            ->headerBlock('Daily updates Digest')
            ->contextBlock(static function (ContextBlock $block): void {
                $block->text('Generated based on Spock leaves and daily updates.');
            })
            ->sectionBlock(static function (SectionBlock $block): void {
                $weekDay = now()->dayName;
                $text = "Happy $weekDay, dear colleagues!\nHere is a weekly report for daily updates and leaves. :coffee:";
                $block->text($text)->markdown();
            });

        foreach ($this->teams as $team) {
            $slackMessage
                ->dividerBlock()
                ->sectionBlock(function (SectionBlock $block) use ($team): void {
                    $teamUrl = route('peopleAndCulture.dailyUpdates.index', ['by' => 'team:'.$team->slug, 'range' => 'previous-week']);

                    /** @var list<StaffWeeklyStatistics> $teamStatistics */
                    $teamStatistics = [];

                    $message = $team->members->where('should_post_daily_updates', true)->toBase()
                        ->map(function (Staff $staff) use (&$teamStatistics): array {
                            $staffStatistics = $this->generateStaffStatistics($staff);
                            $teamStatistics[] = $staffStatistics;

                            return ['staff' => $staff, 'statistics' => $staffStatistics];
                        })
                        ->sortByDesc('statistics.missingUpdates') // start report from Staff with the most missing updates
                        ->reduce(function (string $message, array $staffWithStatistics): string {
                            return $message.$this->generateStaffMessage($staffWithStatistics['staff'], $staffWithStatistics['statistics']);
                        }, "*<$teamUrl|{$team->name}>* team:\n");

                    $excludedStaff = $team->members->where('should_post_daily_updates', false);
                    if ($excludedStaff->count() > 0) {
                        $message .= sprintf("\n\nExcluded from this list: *%s*", $excludedStaff->pluck('name')->join(', '));
                    }

                    $block->text($message)->markdown();

                    $teamScore = $this->calculateTeamScore($teamStatistics);

                    $imgSrc = $this->getChartImgSrc($teamScore);
                    $block->accessory(new ImageElement($imgSrc, "{$team->name} score is $teamScore%"));
                });
        }

        return $slackMessage
            ->dividerBlock()
            ->sectionBlock(static function (SectionBlock $block): void {
                $text = 'Whenever someone forgets to register leave or daily update, please send them a friendly reminder. '.
                    "It’s important that we all do it as a code of trust between each other.\n".
                    "You can use <https://www.interaction-design.org/courses/ixdf-handbook/lessons/daily-updates|“Daily Updates”> IxDF Handbook Lesson Item as a reference.\n\n".
                    'Have a wonderful week! :unicorn_face:';

                $block->text($text)->markdown();
            })
            ->contextBlock(static function (ContextBlock $block): void {
                $block->text('Please add a :heavy_check_mark: to this message if you had any missing updates and have already posted them.');
            });
    }

    /**
     * @return array<string, int|float>
     * @psalm-return StaffWeeklyStatistics
     */
    private function generateStaffStatistics(Staff $staff): array
    {
        /** @var \Carbon\CarbonInterface $dateFrom */
        $dateFrom = max($this->weekDateRange->from, $staff->created_at);
        /** @var \Carbon\CarbonInterface $dateTo */
        $dateTo = min($this->weekDateRange->to, $staff->deleted_at ?: $this->weekDateRange->to);

        $dailyUpdates = $staff->dailyUpdates()->whereBetween('reporting_date', [$dateFrom, $dateTo])->get();
        $fullDayUpdatesCount = $dailyUpdates->where('is_full_day', true)->count();
        $partDayUpdatesCount = $dailyUpdates->count() - $fullDayUpdatesCount;

        $leaves = $staff->leaves()->whereBetween('leave_date', [$dateFrom, $dateTo])->get();
        $fullDayLeavesCount = $leaves->where('leave_period', LeavePeriod::AllDay)->count();
        $partDayLeavesCount = $leaves->count() - $fullDayLeavesCount;

        $personalWeekendDays = self::NUMBER_OF_DAYS_IN_A_WEEK - count($staff->working_days);
        /** @var int<0, 7> $expectedUpdates */
        $expectedUpdates = $dateTo->clone()->addSecond()->diffInDays($dateFrom) - $personalWeekendDays;

        $missingUpdatesCount = $expectedUpdates
            - $fullDayUpdatesCount
            - $fullDayLeavesCount
            - ($partDayUpdatesCount / 2)
            - ($partDayLeavesCount / 2);

        $missingUpdatesCount = (float) max($missingUpdatesCount, 0.0); // for cases when there are more than 5 working days

        return [
            'fullDayUpdates' => $fullDayUpdatesCount,
            'partDayUpdates' => $partDayUpdatesCount,
            'fullDayLeaves' => $fullDayLeavesCount,
            'partDayLeaves' => $partDayLeavesCount,
            'missingUpdates' => $missingUpdatesCount,
            'expectedUpdates' => $expectedUpdates,
        ];
    }

    /**
     * @param array<string, int|float> $staffWeeklyStatistics
     * @psalm-param StaffWeeklyStatistics $staffWeeklyStatistics
     */
    private function generateStaffMessage(Staff $staff, array $staffWeeklyStatistics): string // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
    {
        $staffUrl = route('peopleAndCulture.dailyUpdates.index', ['by' => 'staff:'.$staff->email, 'range' => 'previous-week']);

        $message = "\n - *<$staffUrl|{$staff->name}>*: ";

        $fullDayUpdatesCount = $staffWeeklyStatistics['fullDayUpdates'];
        $partDayUpdatesCount = $staffWeeklyStatistics['partDayUpdates'];
        $fullDayLeavesCount = $staffWeeklyStatistics['fullDayLeaves'];
        $partDayLeavesCount = $staffWeeklyStatistics['partDayLeaves'];
        $missingUpdatesCount = $staffWeeklyStatistics['missingUpdates'];

        $optionalMessageParts = [];

        if ($missingUpdatesCount > 0) {
            $optionalMessageParts[] = "❗️*$missingUpdatesCount* missing ".Str::plural('update', (int) ceil($missingUpdatesCount));
        }

        if ($fullDayUpdatesCount > 0) {
            $optionalMessageParts[] = "*$fullDayUpdatesCount* full daily ".Str::plural('update', $fullDayUpdatesCount);
        }

        if ($partDayUpdatesCount > 0) {
            $optionalMessageParts[] = "*$partDayUpdatesCount* half day ".Str::plural('update', $partDayUpdatesCount);
        }

        if ($fullDayLeavesCount > 0) {
            $optionalMessageParts[] = "*$fullDayLeavesCount* full day ".Str::plural('leave', $fullDayLeavesCount);
        }

        if ($partDayLeavesCount > 0) {
            $optionalMessageParts[] = "*$partDayLeavesCount* half day ".Str::plural('leave', $partDayLeavesCount);
        }

        if (count($optionalMessageParts) > 0) {
            $message .= implode('; ', $optionalMessageParts);
        }

        return $message;
    }

    /**
     * @param list<array<string, int|float>> $teamStatistics
     * @psalm-param list<StaffWeeklyStatistics> $teamStatistics
     * @return int<0, 100>
     */
    private function calculateTeamScore(array $teamStatistics): int
    {
        $expectedNumberOfCoveredDaysByTeam = array_reduce(
            $teamStatistics,
            static fn (int $total, array $staffStatistics): int => $total + $staffStatistics['expectedUpdates'],
            0
        );
        $numberOfMissingUpdates = array_reduce(
            $teamStatistics,
            static fn (float $score, array $staffStatistics): float => $score + $staffStatistics['missingUpdates'],
            0.0
        );

        /** @var int<0, 100> $teamScore */
        return (int) (($expectedNumberOfCoveredDaysByTeam - $numberOfMissingUpdates) / $expectedNumberOfCoveredDaysByTeam * 100);
    }

    private function getChartImgSrc(int $teamScore): string
    {
        $colorOfTeamProgress = match (true) {
            $teamScore === 100 => 'green',
            $teamScore > 85 => 'orange',
            default => 'red',
        };

        /** @see https://quickchart.io/documentation/chart-types/ */
        $chartConfig = "{type:'radialGauge',data:{datasets:[{data:[$teamScore],backgroundColor:'$colorOfTeamProgress'}]}}";

        return "https://quickchart.io/chart?v=2.9.4&c=$chartConfig";
    }
}
