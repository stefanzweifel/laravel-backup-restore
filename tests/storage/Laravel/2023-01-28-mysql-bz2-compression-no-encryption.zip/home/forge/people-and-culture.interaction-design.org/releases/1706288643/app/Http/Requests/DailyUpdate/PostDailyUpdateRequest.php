<?php declare(strict_types=1);

namespace App\Http\Requests\DailyUpdate;

use App\Http\Requests\FormRequest;
use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Feeling;
use Illuminate\Contracts\Database\Query\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Enum;

final class PostDailyUpdateRequest extends FormRequest
{
    /** @inheritDoc */
    public function rules(): array
    {
        return [
            'submission_date' => ['required', 'date', Rule::unique((new DailyUpdate())->getTable(), 'reporting_date')->where(static function (Builder $query) {
                return $query->where('staff_id', Auth::id())->where('deleted_at', null);
            })->ignore($this->input('id'))],
            'feeling' => ['required', new Enum(Feeling::class)],
            'update' => ['required'],
            'plans' => ['required'],
            'blockers' => ['required'],
            'highlights' => ['required'],
            'workday' => ['required', Rule::in('half', 'full')],
            'hours_worked' => ['required', 'integer', ...$this->input('workday') === 'half' ? ['min:1', 'max:7'] : ['in:8']],
            'holiday' => ['required', 'boolean'],
        ];
    }

    /** @inheritDoc */
    public function messages(): array
    {
        return [
            'unique' => 'There’s already an update for this date. Contact a developer if you have problems 🙂',
        ];
    }

    /** Example: '2022-03-21T00:00:3000+00:00###2022-03-27T23:59:59+00:00' */
    public function currentWeekAsDateRange(): string
    {
        $dayOfTheUpdate = Carbon::parse($this->input('submission_date'));
        $startOfTheWeek = $dayOfTheUpdate->copy()->startOfDay()->modify('previous Monday');
        $endOfTheWeek = $dayOfTheUpdate->copy()->endOfDay()->modify('next Sunday');

        return DailyUpdateAnalyticsRequest::convertDateRangeForUrl([$startOfTheWeek, $endOfTheWeek]);
    }
}
