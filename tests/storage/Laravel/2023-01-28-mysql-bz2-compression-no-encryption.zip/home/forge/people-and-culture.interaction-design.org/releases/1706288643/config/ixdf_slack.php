<?php declare(strict_types=1);

return [
    // @see https://interaction-design.slack.com/services/153079556816
    // @see https://api.slack.com/incoming-webhooks
    'webhook' => [
        'url' => env('SLACK_WEBHOOK_URL'),
        'daily' => [
            'username' => 'Daily updates', // the username that this integration will post as.
            'icon_url' => ':rooster:', // icon that is used for messages from this integration
        ],
        'weekly' => [
            'username' => 'Weekly updates', // the username that this integration will post as.
            'icon_url' => ':turkey:', // icon that is used for messages from this integration
        ],
    ],

    'channel_for_all_updates' => '#daily-updates',
    'channel_for_team_leads' => '#team-leads',
    'channel_to_redirect_all_notifications' => env('SLACK_CHANNEL_TO_REDIRECT_ALL_NOTIFICATIONS'), // useful for local testing
];
