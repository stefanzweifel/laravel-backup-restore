<?php declare(strict_types=1);

return [
    'currentWeek' => 'It is currently week :week of :year.',
    'form' => [
        'blockers' => [
            'label' => '<b>Potential problems</b>',
            'placeholder' => 'Share your blockers/dependencies/etc.',
        ],
        'createTitle' => 'Post your update for week :week of :year',
        'date' => [
            'label' => '<b>Date</b>',
            'helpText' => 'Based on the date that you pick, the week of the update will be calculated automatically. If you want to post an update for a previous week, you can do so by picking a date in the past.',
        ],
        'notes' => [
            'label' => '<b>Additional notes</b>',
            'placeholder' => 'Anything else you want to share?',
        ],
        'plans' => [
            'label' => '<b>Plans (next week)</b>',
            'placeholder' => 'What are your plans for the upcoming week?',
        ],
        'update' => [
            'label' => '<b>Progress (this week)</b>',
            'placeholder' => 'What were your accomplished goals (high/mid level)?',
        ],
    ],
    'indexDescription' => 'The weekly updates are written by the Team Leads at the end of each
    week.',
    'indexTitle' => 'Weekly Updates',
    'postAction' => 'Post your update',
    'table' => [
        'blockers' => 'Potential problems',
        'empty' => 'There are no reports yet. You can be the first one to post one!',
        'notes' => 'Additional notes',
        'progress' => 'Progress this week',
        'plans' => 'Plans for next week',
        'week' => 'Week :week of :year',
    ],
];
