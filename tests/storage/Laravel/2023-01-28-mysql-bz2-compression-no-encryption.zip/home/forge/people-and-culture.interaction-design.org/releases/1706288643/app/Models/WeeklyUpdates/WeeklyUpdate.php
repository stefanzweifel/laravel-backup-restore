<?php declare(strict_types=1);

namespace App\Models\WeeklyUpdates;

use App\Models\Staff;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property int $id
 * @property int $team_lead_id
 * @property \Illuminate\Support\Carbon $reporting_week_end_date
 * @property string $progress_last_week
 * @property string $plans_this_week
 * @property string $potential_problems
 * @property string $notes Additional notes (arbitrary).
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \App\Models\Staff $teamLead
 */
final class WeeklyUpdate extends Model
{
    use SoftDeletes;

    /** @var string */
    protected $table = 'peopleAndCulture__weekly_updates';

    /** @var array<string, string> */
    protected $casts = [
        'reporting_week_end_date' => 'datetime',
    ];

    public function teamLead(): BelongsTo
    {
        return $this->belongsTo(Staff::class, 'team_lead_id')->withoutGlobalScopes();
    }
}
