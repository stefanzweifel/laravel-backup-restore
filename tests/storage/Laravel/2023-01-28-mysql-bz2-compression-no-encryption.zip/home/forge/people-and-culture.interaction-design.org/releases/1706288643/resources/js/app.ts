import {createApp, h} from 'vue';
import {createInertiaApp} from '@inertiajs/inertia-vue3';
import {InertiaProgress} from '@inertiajs/progress';
import {i18nVue} from 'laravel-vue-i18n';
import axios from 'axios';

import '../css/app.css';

const csrfMetaTag = document.querySelector('meta[name="csrf-token"]');
const csrfToken = csrfMetaTag.getAttribute('content');

/**
 * Prevent axios magic from reading the XSRF-TOKEN cookie and modifying headers behind the scenes
 * @see https://github.com/InteractionDesignFoundation/people-and-culture/issues/84
 */
axios.interceptors.request.use((config) => {
    config.xsrfCookieName = undefined; // Disable axios magic
    config.headers['X-CSRF-TOKEN'] = csrfToken; // Set header on each request

    return config;
}, function (error) {
    return Promise.reject(error);
});

InertiaProgress.init();

createInertiaApp({
  title: (title) =>
    title ? `${title} - People and Culture` : 'People and Culture',
  resolve: (name) => {
    const pages = import.meta.glob('./Pages/**/*.vue', {eager: true});
    return pages[`./Pages/${name}.vue`];
  },
  setup({el, App, props, plugin}) {
    createApp({render: () => h(App, props)})
      .use(i18nVue, {
        resolve: (lang) => import(`../../lang/${lang}.json`),
      })
      .use(plugin)
      .mount(el);
  },
});
