<script setup lang="ts">
import {useForm, Link} from '@inertiajs/inertia-vue3';
import {formatDateForInput} from '@/vanilla/date';
import {trans} from 'laravel-vue-i18n';
import route from 'ziggy-js';

import BaseButton from '@/Components/BaseButton.vue';
import FormDatepicker from '@/Components/Form/FormDatepicker.vue';
import FormInput from '@/Components/Form/FormInput.vue';
import FormSelect from '@/Components/Form/FormSelect.vue';
import FormTextArea from '@/Components/Form/FormTextArea.vue';

const props = defineProps<{
  id?: number;
  previousPlans?: string;
  submission_date?: string;
  feeling?: number;
  update?: string;
  plans?: string;
  blockers?: string;
  highlights?: string;
  workday?: string;
  holiday?: string;
  hours_worked?: number;
}>();

const form = useForm<{
  id: number | null;
  submission_date: Date;
  feeling: number | null;
  update: string;
  plans: string;
  blockers: string;
  highlights: string;
  workday: string;
  holiday: string;
  hours_worked: number;
}>({
  id: props.id ?? null,
  submission_date: props.submission_date
    ? new Date(props.submission_date)
    : new Date(),
  feeling: props.feeling ?? null,
  update: props.update ?? '',
  plans: props.plans ?? '',
  blockers: props.blockers ?? '-',
  highlights: props.highlights ?? '-',
  workday: props.workday ?? 'full',
  holiday: props.holiday ?? '0',
  hours_worked: props.hours_worked ?? 8,
});

const formSubmit = () => {
  const date = form.submission_date;
  form
    .transform((data) => ({
      ...data,
      submission_date: formatDateForInput(date),
    }))
    .post(
      props.id
        ? route('peopleAndCulture.dailyUpdates.update', props.id)
        : route('peopleAndCulture.dailyUpdates.store')
    );
};

const addPrevious_plansToCompletedToday = () => {
  form.update += (form.update === '' ? '' : '\n') + props.previousPlans;
};
</script>

<template>
  <form @submit.prevent="formSubmit" novalidate>
    <FormDatepicker
      v-model="form.submission_date"
      :label="trans('dailyUpdates.form.submissionDate.label')"
      id="date"
      required
      :error="form.errors.submission_date"
      :help-text="trans('dailyUpdates.form.submissionDate.helpText')"
    />
    <div class="mt-4">
      <FormSelect
        id="feeling"
        :label="trans('dailyUpdates.form.feeling.label')"
        v-model="form.feeling"
        required
        :error="form.errors.feeling"
        :placeholder="trans('dailyUpdates.form.feeling.placeholder')"
      >
        <option value="" disabled>{{ trans('form.select.choose') }}:</option>
        <option value="1">&#128561; (💔/5)</option>
        <option value="2">&#128577; (💚💚/5)</option>
        <option value="3">&#128528; (💚💚💚/5)</option>
        <option value="4">&#128512; (💚💚💚💚/5)</option>
        <option value="5">&#128513; (💚💚💚💚💚/5)</option>
      </FormSelect>
    </div>

    <div class="mt-4">
      <FormTextArea
        id="update"
        :label="trans('dailyUpdates.form.update.label')"
        v-model="form.update"
        required
        rows="4"
        :placeholder="trans('dailyUpdates.form.update.placeholder')"
        :help-text="trans('dailyUpdates.form.update.helpText')"
        :error="form.errors.update"
      />
      <div v-if="previousPlans" class="mt-small">
        <button
          type="button"
          class="link mr-small text-sm"
          @click="addPrevious_plansToCompletedToday"
        >
          {{ trans('dailyUpdates.form.update.autoFill') }}
        </button>
      </div>
    </div>
    <div class="mt-4">
      <FormTextArea
        id="plans"
        :label="trans('dailyUpdates.form.plans.label')"
        :placeholder="trans('dailyUpdates.form.plans.placeholder')"
        v-model="form.plans"
        required
        rows="4"
        :error="form.errors.plans"
        :help-text="trans('dailyUpdates.form.plans.helpText')"
      />
    </div>
    <div class="mt-4">
      <FormTextArea
        id="blockers"
        :label="trans('dailyUpdates.form.blockers.label')"
        v-model="form.blockers"
        :placeholder="trans('dailyUpdates.form.blockers.placeholder')"
        rows="2"
        :error="form.errors.blockers"
        :help-text="trans('dailyUpdates.form.blockers.helpText')"
      />
    </div>
    <div class="mt-4">
      <FormTextArea
        id="highlights"
        :label="trans('dailyUpdates.form.highlights.label')"
        v-model="form.highlights"
        :placeholder="trans('dailyUpdates.form.highlights.placeholder')"
        rows="2"
        :error="form.errors.highlights"
        :help-text="trans('dailyUpdates.form.highlights.helpText')"
      />
    </div>
    <div class="mt-4">
      <div class="flex">
        <div class="md:w-3/4">
          <div class="pr-4">
            <FormSelect
              id="workday"
              :label="trans('dailyUpdates.form.workDay.label')"
              v-model="form.workday"
              required
              min="1"
              max="20"
              :error="form.errors.workday"
              :placeholder="trans('form.select.placeholder')"
              :help-text="trans('dailyUpdates.form.workDay.helpText')"
            >
              <option value="" disabled>
                {{ trans('form.select.choose') }}
              </option>
              <option value="half">
                {{ trans('dailyUpdates.form.workDay.halfDay') }}
              </option>
              <option value="full">
                {{ trans('dailyUpdates.form.workDay.full') }}
              </option>
            </FormSelect>
          </div>
        </div>
        <div class="md:w-1/4" v-show="form.workday === 'half'">
          <FormInput
            type="number"
            min="1"
            max="7"
            id="hours_worked"
            :label="trans('dailyUpdates.form.hoursWorked.label')"
            v-model="form.hours_worked"
            required
            :error="form.errors.hours_worked"
            :help-text="trans('dailyUpdates.form.hoursWorked.helpText')"
          />
        </div>
      </div>
    </div>
    <div class="mt-4">
      <FormSelect
        id="holiday"
        :label="trans('dailyUpdates.form.holiday.label')"
        v-model="form.holiday"
        required
        :error="form.errors.holiday"
        :placeholder="trans('form.select.placeholder')"
        :help-text="trans('dailyUpdates.form.holiday.helpText')"
      >
        <option value="" disabled>
          {{ trans('form.select.choose') }}
        </option>
        <option value="0">{{ trans('general.no') }}</option>
        <option value="1">{{ trans('general.yes') }} ⛱</option>
      </FormSelect>
      <div
        v-if="form.holiday === '1'"
        class="mt-3 p-4 mb-4 text-sm text-blue-700 bg-blue-100 rounded-lg dark:bg-blue-200 dark:text-blue-800"
        role="alert"
      >
        <span class="font-medium">Spock: </span>
        {{ trans('dailyUpdates.form.holiday.reminder') }}
      </div>
    </div>

    <BaseButton
      variation="primary"
      type="submit"
      class="mt-4"
      :disabled="form.processing"
    >
      {{ trans('dailyUpdates.form.submit') }}
    </BaseButton>

    <Link
      class="font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 bg-white focus:ring-4 border-2 border-gray-500"
      :href="route('peopleAndCulture.dailyUpdates.index')"
    >
      {{ trans('form.cancel') }}
    </Link>
  </form>
</template>
