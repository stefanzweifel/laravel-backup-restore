<?php declare(strict_types=1);

return [
    'cancel' => 'Cancel',
    'errors' => 'There were some errors!',
    'select' => [
        'choose' => 'Please choose an option',
        'placeholder' => 'Select one',
    ],
    'submit' => 'Submit',
];
