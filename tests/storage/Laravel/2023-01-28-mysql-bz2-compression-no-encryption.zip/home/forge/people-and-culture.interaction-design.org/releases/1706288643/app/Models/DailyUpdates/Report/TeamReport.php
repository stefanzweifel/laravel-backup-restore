<?php declare(strict_types=1);

namespace App\Models\DailyUpdates\Report;

use Carbon\CarbonInterface;

/** @psalm-type TeamReportStatistic = array{count: int, email: string, name: string} */
final class TeamReport extends Report
{
    /**
     * @param list<array{name: string, email: string}> $teamMembers
     * @param array<string, array<string, (\App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO)>> $updates
     * @param list<\App\Models\StaffLeave\Report\LeaveDTO> $leaves
     * @param list<TeamReportStatistic> $dailyUpdateStats
     * @param list<TeamReportStatistic> $leaveStats
     */
    public function __construct(
        public readonly string $teamName,
        public readonly array $teamMembers,
        public readonly int $workingDays,
        public readonly ?CarbonInterface $lastUpdatedAt,
        public readonly array $updates,
        public readonly array $leaves,
        public readonly array $dailyUpdateStats,
        public readonly array $leaveStats,
        public readonly int $numberOfFullDayReports,
        public readonly int $numberOfHalfDayReports,
        public readonly int $numberOfFullDayHolidays,
        public readonly int $numberOfHalfDayHolidays
    ) {
    }
}
