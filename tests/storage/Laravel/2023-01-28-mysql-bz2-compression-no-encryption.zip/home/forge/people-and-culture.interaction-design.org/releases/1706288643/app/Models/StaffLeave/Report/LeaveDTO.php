<?php declare(strict_types=1);

namespace App\Models\StaffLeave\Report;

use App\Models\StaffLeave\Leave;

final class LeaveDTO
{
    private function __construct(
        public readonly string $staffEmail,
        public readonly string $leaveDate,
        public readonly string $leavePeriod
    ) {
    }

    public static function createFromModel(Leave $leave, string $staffEmail): self
    {
        return new self(
            $staffEmail,
            $leave->leave_date->toFormattedDateString(),
            $leave->leave_period->value
        );
    }
}
