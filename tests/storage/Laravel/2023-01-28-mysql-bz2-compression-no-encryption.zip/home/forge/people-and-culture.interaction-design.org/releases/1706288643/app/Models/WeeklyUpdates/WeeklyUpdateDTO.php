<?php declare(strict_types=1);

namespace App\Models\WeeklyUpdates;

final class WeeklyUpdateDTO
{
    private function __construct(
        public readonly int $updateId,
        public readonly int $teamLeadId,
        public readonly string $teamLeadName,
        public readonly string $reportingWeekEndDate,
        public readonly string $progressLastWeek,
        public readonly string $plansThisWeek,
        public readonly string $potentialProblems,
        public readonly string $notes
    ) {
    }

    public static function fromWeeklyUpdate(WeeklyUpdate $weeklyUpdate): self
    {
        return new self(
            $weeklyUpdate->id,
            $weeklyUpdate->team_lead_id,
            $weeklyUpdate->teamLead->name,
            $weeklyUpdate->reporting_week_end_date->toFormattedDateString(),
            $weeklyUpdate->progress_last_week,
            $weeklyUpdate->plans_this_week,
            $weeklyUpdate->potential_problems,
            $weeklyUpdate->notes
        );
    }
}
