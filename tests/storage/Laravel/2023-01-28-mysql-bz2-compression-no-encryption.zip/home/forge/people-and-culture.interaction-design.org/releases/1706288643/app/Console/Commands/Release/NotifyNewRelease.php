<?php declare(strict_types=1);

namespace App\Console\Commands\Release;

use App\Notifications\NewReleaseWithChangelogNotification;
use App\Services\Slack\IxDFSlackWebhookWorkspace;
use GrahamCampbell\GitHub\Facades\GitHub;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;

final class NotifyNewRelease extends Command
{
    /** @var string */
    protected $signature = 'release:notify {--force}';

    /** @var string */
    protected $description = 'Notify developers and Slack about a recent deployment to any server.';

    public function handle(IxDFSlackWebhookWorkspace $slackWebhookChannel): int
    {
        if ($this->shouldSkip()) {
            return self::SUCCESS;
        }

        $this->notifyAnnouncementsSlackChannel($slackWebhookChannel);
        return self::SUCCESS;
    }

    private function shouldSkip(): bool
    {
        if ($this->option('force')) {
            return false;
        }

        if (App::environment('local')) {
            $this->info(now().' No need for notifications about local deployment. Have a nice day, IxDF developer :)');

            return true;
        }

        return ! App::isProduction();
    }

    private function notifyAnnouncementsSlackChannel(IxDFSlackWebhookWorkspace $slackWebhookChannel): void
    {
        /** @see https://github.com/KnpLabs/php-github-api/blob/master/doc/repo/releases.md */
        $releaseData = $this->fetchReleaseDataFromGitHub($this->getAppVersion())
            ?? $this->fetchLatestReleaseDataFromGitHub();

        $releaseNotes = $releaseData['body'];
        assert(is_string($releaseNotes));

        $author = $releaseData['author'];
        assert(is_array($author));

        $notification = new NewReleaseWithChangelogNotification($this->getAppVersion(), $author, $releaseNotes);

        $slackWebhookChannel->notifyNow($notification);
    }

    private function getAppVersion(): string
    {
        return (string) config('release.app_version');
    }

    /** @return array{author: array{login: string, html_url: string, avatar_url: string}, body: string}|null */
    private function fetchReleaseDataFromGitHub(string $appVersion): ?array
    {
        try {
            return GitHub::api('repo')->releases()->tag((string) config('release.github.organisation'), (string) config('release.github.repository'), $appVersion);
        } catch (\RuntimeException) {
            return null;
        }
    }

    /**
     * @throws \Github\Exception\RuntimeException
     * @return array<string, string>
     */
    private function fetchLatestReleaseDataFromGitHub(): array
    {
        return GitHub::api('repo')
            ->releases()
            ->latest((string) config('release.github.organisation'), (string) config('release.github.repository'));
    }
}
