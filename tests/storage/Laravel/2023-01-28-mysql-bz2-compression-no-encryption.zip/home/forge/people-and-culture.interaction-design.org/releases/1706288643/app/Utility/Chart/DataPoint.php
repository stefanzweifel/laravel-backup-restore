<?php declare(strict_types=1);

namespace App\Utility\Chart;

/**
 * Represents a data point of a data set for a generic chart.
 * @see Chart
 * @see DataSet
 */
final class DataPoint
{
    /** @param float|int|null $value can be "null" if the point is missing on the data set for a given interval */
    public function __construct(private float | int | null $value, private readonly string $tooltip = '')
    {
    }

    public function getValue(): float | int | null
    {
        return $this->value;
    }

    public function getTooltip(): string
    {
        return $this->tooltip;
    }

    /** @return array{value: float|int|null, tooltip: string} */
    public function toArray(): array
    {
        return [
            'value' => $this->value,
            'tooltip' => $this->tooltip,
        ];
    }
}
