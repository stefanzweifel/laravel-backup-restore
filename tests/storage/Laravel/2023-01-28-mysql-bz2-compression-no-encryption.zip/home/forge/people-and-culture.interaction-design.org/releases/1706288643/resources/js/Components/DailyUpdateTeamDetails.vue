<script setup lang="ts">
import {trans} from 'laravel-vue-i18n';

import {Analytics} from '@/types';

import DailyUpdateMemberAnalytics from '@/Components/DailyUpdateMemberAnalytics.vue';

defineProps<{
  analytics: Analytics;
  teamName: string;
  currentRange: string;
}>();
</script>

<template>
  <h2 class="text-3xl font-bold my-3">
    {{ trans('dailyUpdates.teamUpdates', {teamName: teamName, date: currentRange}) }}
  </h2>

  <div class="font-serif mb-6">
    {{ trans('dailyUpdates.teamMembers') }}:
    <ul class="inline-flex">
      <li
        class="mr-2"
        v-for="teamMember in analytics.teamMembers"
        :key="teamMember.email"
      >
        <DailyUpdateMemberAnalytics
          :name="teamMember.name"
          :email="teamMember.email"
        />
      </li>
    </ul>
  </div>

  <p
    class="font-serif mb-3"
    v-html="
      trans('dailyUpdates.teamUpdateReport', {
        teamName: teamName,
        fullDayUpdates: analytics.numberOfReports.fullDayUpdates.toString(),
        halfDayUpdates: analytics.numberOfReports.halfDayUpdates.toString(),
        days: analytics.numberOfReports.days.toString(),
        fullDayHolidays:
          analytics.numberOfReports.numberOfFullDayHolidays.toString(),
        halfDayHolidays:
          analytics.numberOfReports.numberOfHalfDayHolidays.toString(),
      })
    "
  ></p>

  <span
    class="font-serif"
    v-html="
        trans('dailyUpdates.teamUpdateSpockLink', {
          fullDayHolidays:
            analytics.numberOfReports.numberOfFullDayHolidays.toString(),
          halfDayHolidays:
            analytics.numberOfReports.numberOfHalfDayHolidays.toString(),
        })
      "
  ></span>
</template>
