<?php declare(strict_types=1);

namespace App\Notifications;

use App\Http\Controllers\DailyUpdates\Presenters\DailyUpdatePresenter;
use App\Models\Staff;
use Carbon\CarbonInterface;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Slack\BlockKit\Blocks\SectionBlock;
use Illuminate\Notifications\Slack\SlackMessage;

final class MissingDailyUpdateReminder extends Notification
{
    public function __construct(private readonly CarbonInterface $date)
    {
    }

    /**
     * Get the notification's delivery channels.
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint.DisallowedMixedTypeHint
     * @phpcsSuppress SlevomatCodingStandard.Functions.UnusedParameter.UnusedParameter
     * @return list<string>
     */
    public function via(): array
    {
        return ['slack'];
    }

    /** Get the Slack representation of the notification. */
    public function toSlack(Staff $staff): SlackMessage
    {
        $formattedDate = $this->date->format(DailyUpdatePresenter::REPORT_DATETIME_FORMAT);
        $slackUserId = $staff->slack_user_id;
        $message = "Hello <@$slackUserId>!

It seems like you didn't post a daily update on *{$formattedDate}*.

Please make sure to either post a daily update or register leave on Spock.
Thanks so much!";

        return (new SlackMessage())
            ->username((string) config('ixdf_slack.webhook.daily.username'))
            ->emoji($staff->team->symbol)
            ->to($staff->slack_user_id)
            ->sectionBlock(static function (SectionBlock $sectionBlock) use ($message) {
                $sectionBlock->text($message)->markdown();
            })
            ->sectionBlock(function (SectionBlock $sectionBlock) {
                $postYourUpdateLink = route('peopleAndCulture.dailyUpdates.create', [
                    'date' => $this->date->toDateString(),
                ]);
                $content = sprintf('<%s|Post your daily update>', $postYourUpdateLink);
                $sectionBlock->text("*People and Culture*\n{$content}")->markdown();
            })
            ->sectionBlock(static function (SectionBlock $sectionBlock) {
                $dailyUpdatesLink = sprintf(
                    '- <%s|How to Post Daily Updates – And Why They’re So Important>',
                    'https://www.interaction-design.org/courses/ixdf-handbook/lessons/daily-updates'
                );
                $timeOffLink = sprintf(
                    '- <%s|How to Take Time Off>',
                    'https://www.interaction-design.org/courses/ixdf-handbook/lessons/time-off'
                );
                $content = implode("\r\n", [$dailyUpdatesLink, $timeOffLink]);

                $sectionBlock->text("*IxDF Handbook*\n{$content}")->markdown();
            });
    }
}
