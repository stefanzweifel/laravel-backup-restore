<script setup lang="ts">
import {useForm} from '@inertiajs/inertia-vue3';
import {Link} from '@inertiajs/inertia-vue3';
import route from 'ziggy-js';
import {trans} from 'laravel-vue-i18n';
import {Staff, Team} from '@/types';

import BaseButton from '@/Components/BaseButton.vue';
import FormSelect from '@/Components/Form/FormSelect.vue';
import FormInput from '@/Components/Form/FormInput.vue';

const props = defineProps<{
  staff?: Staff;
  teams: Team[];
}>();

const form = useForm<{
  name: string;
  email: string;
  team: number;
  slack_user_id: string;
  spock_user_id: string;
}>({
  name: props.staff?.name ?? '',
  email: props.staff?.email ?? '',
  team: props.staff?.team_id ?? 0,
  slack_user_id: props.staff?.slack_user_id ?? '',
  spock_user_id: props.staff?.spock_user_id ?? '',
});

const formSubmit = () => {
  if (props.staff?.id) {
    form.put(route('admin.staff.update', props.staff.id));
  } else {
    form.post(route('admin.staff.store'));
  }
};
</script>

<template>
  <form @submit.prevent="formSubmit" novalidate>
    <div>
      <FormInput
        id="name"
        v-model="form.name"
        :label="trans('staff.form.name.label')"
        :placeholder="trans('staff.form.name.placeholder')"
        :help-text="trans('staff.form.name.helpText')"
        :error="form.errors.name"
        required
      />
    </div>
    <div class="mt-8">
      <FormInput
        id="email"
        v-model="form.email"
        :label="trans('staff.form.email.label')"
        :placeholder="trans('staff.form.email.placeholder')"
        :help-text="trans('staff.form.email.helpText')"
        :error="form.errors.email"
        required
      />
    </div>
    <div class="mt-8">
      <FormSelect
        id="team"
        v-model="form.team"
        :label="trans('staff.form.team.label')"
        :placeholder="trans('staff.form.team.placeholder')"
        :help-text="trans('staff.form.team.helpText')"
        :error="form.errors.team"
        required
      >
        <option v-for="(name, id) in teams" :key="id" :value="id">
          {{ name }}
        </option>
      </FormSelect>
    </div>
    <div class="mt-8">
      <FormInput
        id="slack_user_id"
        class="read-only:bg-gray-100"
        v-model="form.slack_user_id"
        :label="trans('registration.form.slack_user_id.label')"
        :placeholder="trans('staff.form.slack_user_id.placeholder')"
        :help-text="trans('staff.form.slack_user_id.helpText')"
        :error="form.errors.slack_user_id"
        required
      />
    </div>
    <div class="mt-8">
      <FormInput
        id="spock_user_id"
        class="read-only:bg-gray-100"
        v-model="form.spock_user_id"
        :label="trans('staff.form.spock_user_id.label')"
        :placeholder="trans('staff.form.spock_user_id.placeholder')"
        :help-text="trans('staff.form.spock_user_id.helpText')"
        :error="form.errors.spock_user_id"
        readonly
        aria-disabled="true"
      />
    </div>
    <BaseButton type="submit" class="mt-4" :disabled="form.processing">
      {{ trans('form.submit') }}
    </BaseButton>
    <Link
      class="font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 bg-white focus:ring-4 border-2 border-gray-500"
      :href="route('admin.staff.index')"
    >
      {{ trans('form.cancel') }}
    </Link>
  </form>
</template>
