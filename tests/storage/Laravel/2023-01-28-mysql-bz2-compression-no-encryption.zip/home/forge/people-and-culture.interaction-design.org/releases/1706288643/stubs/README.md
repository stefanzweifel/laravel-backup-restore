# Custom stubs

[Stub Customization](https://laravel.com/docs/master/artisan#stub-customization).

Console command to publish stubs: `stub:publish {--force : Overwrite any existing files}` (\Illuminate\Foundation\Console\StubPublishCommand::class).

[Latest stubs on GitHub](https://github.com/laravel/framework/tree/master/src/Illuminate/Foundation/Console/stubs).


## Policy

1. Publish stubs ONLY for commands we use.
1. Publish stubs that have important changes in a compare with original ones.
1. Update published stubs on major framework updates.
