<script setup lang="ts">
import {WeeklyUpdateReport} from '@/types';
import {getWeekNumberFromDate} from '@/vanilla/date';
import {trans} from 'laravel-vue-i18n';

defineProps<{
  reports: WeeklyUpdateReport[];
}>();
</script>

<template>
  <table class="table-auto font-serif text-sm w-full">
    <tr :key="date" v-for="(rpts, date) in reports">
      <table class="w-full">
        <tr>
          <td
            class="p-2 bg-neutral-700 text-base"
            v-html="
              trans('weeklyUpdates.table.week', {
                year: new Date(date).getFullYear().toString(),
                week: getWeekNumberFromDate(new Date(date)).toString(),
              })
            "
          ></td>
        </tr>
        <tr :key="idx" v-for="(report, idx) in rpts">
          <td>
            <table class="w-full">
              <tr>
                <td class="p-2 bg-neutral-200" colspan="3">
                  <b>{{ report.teamLeadName }}</b>
                </td>
              </tr>
              <tr class="text-left border-neutral-300 border-b-2">
                <th class="p-2 w-1/2">
                  {{ trans('weeklyUpdates.table.progress') }}
                </th>
                <th class="p-2">{{ trans('weeklyUpdates.table.plans') }}</th>
              </tr>
              <tr>
                <td class="align-top whitespace-pre-wrap break-words p-2">
                  {{ report.progressLastWeek }}
                </td>
                <td class="align-top whitespace-pre-wrap break-words p-2">
                  {{ report.plansThisWeek }}
                </td>
              </tr>
              <tr class="border-neutral-300 border-t-2">
                <td class="break-words p-2 pb-4" colspan="2">
                  <b>{{ trans('weeklyUpdates.table.blockers') }}:</b>
                  {{ report.potentialProblems }}
                </td>
              </tr>
              <tr v-if="report.notes" class="border-neutral-300 border-t-2">
                <td class="break-words p-2 pb-4" colspan="2">
                  <b>{{ trans('weeklyUpdates.table.notes') }}:</b>
                  {{ report.notes }}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </tr>
  </table>
</template>
