<?php declare(strict_types=1);

namespace Tests\Unit\Services\DailyUpdates;

use App\Services\StaffLeave\LeavePeriod;
use App\Services\StaffLeave\StaffLeaveEvent;
use ICal\Event;

it('should parse ICal event', function () {
    $staffLeaveEvent = StaffLeaveEvent::fromICalEvent(createICalEvent());

    $this->assertSame($staffLeaveEvent->calendarEventUid, 'UID-44661831var341nio6093b3a7d596g3d@interaction-design');
    $this->assertSame($staffLeaveEvent->slackDisplayName, '@jonathan');
    $this->assertSame($staffLeaveEvent->spockUserId, 'U30G75V8CYG112C42EEC14676084RSD35');
    $this->assertSame($staffLeaveEvent->leaveDate->format('D F jS, Y'), 'Tue June 13th, 2023');
    $this->assertSame($staffLeaveEvent->leaveType, 'Holiday');
    $this->assertSame($staffLeaveEvent->leavePeriod, LeavePeriod::AllDay);
});

function createICalEvent(): Event
{
    return new Event([
        'summary' => 'Jonathan Ive - Holiday - All day',
        'dtstart' => '20230613',
        'dtstamp' => '20230613T101625Z',
        'dtstart_tz' => '20230613T000000',
        'dtend_tz' => '20230613T000000',
        'uid' => 'UID-44661831var341nio6093b3a7d596g3d@interaction-design',
        'description' => "Notes: Son's 4th birthday\n
            -----------------------\n
            Spock for Interaction Design Foundation in Slack\n
            \n
            Slack User: @jonathan (U30G75V8CYG112C42EEC14676084RSD35)",
    ]);
}
