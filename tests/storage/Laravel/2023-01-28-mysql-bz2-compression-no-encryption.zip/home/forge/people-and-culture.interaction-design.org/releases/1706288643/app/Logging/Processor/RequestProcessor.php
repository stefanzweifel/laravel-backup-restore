<?php declare(strict_types=1);

namespace App\Logging\Processor;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Str;
use Monolog\LogRecord;
use Monolog\Processor\ProcessorInterface;

/**
 * Adds additional request data to the log message
 */
final class RequestProcessor implements ProcessorInterface
{
    private const IGNORE_REQUEST_INPUTS = [
        'password',
        'confirm_password',
        'current_password',
        'new_password',
        '_token',
    ];

    private readonly Request $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * @psalm-suppress LessSpecificImplementedReturnType
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint
     */
    public function __invoke(LogRecord $record): LogRecord
    {
        return App::runningInConsole()
            ? $this->getConsoleData($this->request, $record)
            : $this->getRequestData($this->request, $record);
    }

    private function getConsoleData(Request $request, LogRecord $record): LogRecord
    {
        $record['extra']['console']['command'] = implode(' ', $request->server('argv', []));
        if ($request->server('USER')) {
            $record['extra']['console']['script user'] = $request->server('USER');
        }

        return $record;
    }

    private function getRequestData(Request $request, LogRecord $record): LogRecord // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
    {
        $record['extra']['request']['method'] = $request->getMethod();
        $record['extra']['request']['uri'] = $request->getRequestUri();

        if (!$request->isMethod('GET')) {
            $record['extra']['request']['inputs'] = collect($request->except(self::IGNORE_REQUEST_INPUTS))
                ->map(static fn ($inputValue) => \is_string($inputValue) ? Str::limit($inputValue, 50, '…') : $inputValue)
                ->all();
        }

        try {
            $urlPrevious = $request->session()->get('_previous.url');
            if ($urlPrevious) {
                $record['extra']['request']['uri_previous'] = $urlPrevious;
            }
        } catch (\RuntimeException) {
            /**
             * do nothing
             * Session service is not available in some cases (e.g. API routes)
             */
        }

        $record['extra']['request']['ip'] = $request->ip();
        if ($request->ip() !== '127.0.0.1') {
            $record['extra']['request']['ip_location'] = "https://iplocation.com/?ip={$request->ip()}";
        }

        return $record;
    }
}
