<?php declare(strict_types=1);

use App\Http\Controllers\Admin\StaffManagementController;
use App\Http\Controllers\WeeklyUpdates\WeeklyUpdateController;
use App\Models\Staff;
use Illuminate\Support\Facades\Route;

Route::get('/daily-updates', \App\Http\Controllers\DailyUpdates\Index\Controller::class)->name('peopleAndCulture.dailyUpdates.index')->middleware('auth');
Route::get('/daily-updates/create', \App\Http\Controllers\DailyUpdates\Create\Controller::class)->name('peopleAndCulture.dailyUpdates.create')->middleware('auth');
Route::post('/daily-updates', \App\Http\Controllers\DailyUpdates\Store\Controller::class)->name('peopleAndCulture.dailyUpdates.store')->middleware('auth');
Route::get('/daily-updates/{dailyUpdate}/edit', \App\Http\Controllers\DailyUpdates\Edit\Controller::class)->name('peopleAndCulture.dailyUpdates.edit')->can('update', 'dailyUpdate')->middleware('auth');
Route::post('/daily-updates/{dailyUpdate}/update', \App\Http\Controllers\DailyUpdates\Update\Controller::class)->name('peopleAndCulture.dailyUpdates.update')->can('update', 'dailyUpdate')->middleware('auth');
Route::delete('/daily-updates/{dailyUpdate}', \App\Http\Controllers\DailyUpdates\Destroy\Controller::class)->name('peopleAndCulture.dailyUpdates.destroy')->can('update', 'dailyUpdate')->middleware('auth');

Route::controller(WeeklyUpdateController::class)
    ->middleware('auth')
    ->prefix('weekly-updates')
    ->group(static function (): void {
        Route::get('/', 'index')->name('peopleAndCulture.weeklyUpdates.index');
        Route::get('create', 'create')->name('peopleAndCulture.weeklyUpdates.create');
        Route::post('/', 'store')->name('peopleAndCulture.weeklyUpdates.store');
    });

Route::controller(StaffManagementController::class)
    ->middleware('auth')
    ->prefix('staff')
    ->group(static function (): void {
        Route::get('/', 'index')->name('admin.staff.index')->can('view', Staff::class);
        Route::get('create', 'create')->name('admin.staff.create')->can('view', Staff::class);
        Route::post('/', 'store')->name('admin.staff.store')->can('create', Staff::class);
        Route::get('{staff:id}/edit', 'edit')->name('admin.staff.edit')->can('view', 'staff');
        Route::put('{staff:id}', 'update')->name('admin.staff.update')->can('update', 'staff');
        Route::delete('{staff:id}', 'destroy')->name('admin.staff.destroy')->can('delete', 'staff');
    });

Route::redirect('/', 'daily-updates')->name('home');

Route::controller(\App\Http\Controllers\Auth\AuthController::class)
    ->prefix('auth')
    ->group(static function (): void {
        Route::group(['middleware' => 'guest'], static function (): void {
            Route::redirect('/', 'auth/login');
            Route::get('login', 'create')->name('auth.login');
            Route::post('login', 'store');
            Route::get('callback', 'callback')->name('auth.callback');
        });

        Route::post('logout', 'destroy')->name('auth.logout')->middleware('auth');
    });

Route::get('registration', \App\Http\Controllers\Registration\RegistrationFormController::class)
    ->name('registration.create')
    ->middleware(['guest']);

Route::post('registration', \App\Http\Controllers\Registration\RegistrationController::class)
    ->name('registration.store')
    ->middleware(['guest']);
