<?php declare(strict_types=1);

namespace App\Http\Requests\DailyUpdate;

use App\Http\Requests\FormRequest;
use App\Models\Staff;
use App\Models\Team;
use App\ValueObjects\DatetimeRange;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

final class DailyUpdateAnalyticsRequest extends FormRequest
{
    private const DATE_SEPARATOR = ';';

    /** @inheritDoc */
    public function rules(): array
    {
        return [
            'range' => ['nullable', 'string'],
            'by' => ['nullable', 'string', 'starts_with:team,staff'],
        ];
    }

    public function hasFilter(): bool
    {
        $dateRange = (string) $this->query('range');

        return $dateRange !== '';
    }

    public function dateFilterOptions(): DatetimeRange
    {
        $dateRange = $this->query('range');
        if (! is_string($dateRange)) { // current week by default (the default is not set in stone - feel free to change it)
            return new DatetimeRange(now()->startOfWeek(), now()->endOfWeek());
        }

        $parsedDateRangeAlias = $this->findDateRangeAlias($dateRange);
        if ($parsedDateRangeAlias instanceof DatetimeRange) {
            return $parsedDateRangeAlias;
        }

        return $this->parseDateRangeString($dateRange);
    }

    private function parseDateRangeString(string $dateRange): DatetimeRange
    {
        if (! str_contains($dateRange, self::DATE_SEPARATOR)) {
            throw new \BadMethodCallException('Unable to find date filters!');
        }

        $dates = explode(self::DATE_SEPARATOR, $dateRange);

        [$startDate, $endDate] = $dates;

        return new DatetimeRange(Carbon::parse($startDate), Carbon::parse($endDate));
    }

    private function findDateRangeAlias(string $probablyDateRangeAlias): ?DatetimeRange // phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded, SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
    {
        $range = match ($probablyDateRangeAlias) {
            'today' => new DatetimeRange(today(), today()->endOfDay()),
            'yesterday' => new DatetimeRange(today()->subDay(), today()->subDay()->endOfDay()),
            'this-week' => new DatetimeRange(today()->startOfWeek(), today()->endOfWeek()),
            'week-ago', '1-week-ago', 'previous-week' => new DatetimeRange(today()->subWeek()->startOfWeek(), today()->subWeek()->endOfWeek()),
            'this-month' => new DatetimeRange(today()->startOfMonth(), today()->endOfMonth()),
            'month-ago', '1-month-ago', 'previous-month' => new DatetimeRange(today()->subMonth()->startOfMonth(), today()->subMonth()->endOfMonth()),
            default => null,
        };

        if ($range instanceof DatetimeRange) {
            return $range;
        }

        $dateTimeModifier = str_replace('-', ' ', $probablyDateRangeAlias);
        $result = preg_match('/^(?<number_of_units>\d+) (?<unit>\w+)$/', $dateTimeModifier, $matches);
        if ($result === false) {
            return null;
        }

        $unit = $matches['unit'] ?? null;
        $numberOfUnits = $matches['number_of_units'] ?? null;
        if (! is_string($unit) || ! is_numeric($numberOfUnits)) {
            return null;
        }

        $numberOfUnits = (int) $numberOfUnits;
        if ($numberOfUnits < 1) {
            return null;
        }

        $unit = Str::singular($unit);

        $rangeStart = today()->startOf($unit)->sub($unit, $numberOfUnits - 1);

        return new DatetimeRange($rangeStart, today()->endOfDay());
    }

    /** @return array{type: string, identifier: string} */
    private function parseBy(string $by): array
    {
        if (! str_contains($by, ':')) {
            throw new \RuntimeException('Invalid syntax for `by` parameter.');
        }

        [$type, $identifier] = explode(':', $by);

        return [
            'type' => $type,
            'identifier' => $identifier,
        ];
    }

    /** @param list{\Carbon\CarbonInterface, \Carbon\CarbonInterface} $dateRange */
    public static function convertDateRangeForUrl(array $dateRange): string
    {
        /**
         * @todo: Change the format to 'Y-m-d' - most likely it will require to
         * be more clever when parsing the dates in the `parseDateRangeString` method:
         * return [Carbon::parse($startDate)->startOfDay(), Carbon::parse($endDate)->endOfDay()];
         */
        return implode(self::DATE_SEPARATOR, [
            $dateRange[0]->format('Y-m-d'),
            $dateRange[1]->format('Y-m-d'),
        ]);
    }

    public function hasTeam(): bool
    {
        $by = (string) $this->query('by');
        return str_starts_with($by, 'team:');
    }

    private function getTeamSlug(): string
    {
        if (! $this->hasTeam()) {
            throw new \BadMethodCallException('Unable to find team filter!');
        }

        return $this->parseBy((string) $this->query('by'))['identifier'];
    }

    public function team(): Team
    {
        $teamSlug = $this->getTeamSlug();
        if ($teamSlug === 'my') {
            $authStaff = $this->user();
            assert($authStaff instanceof Staff);
            $teamSlug = $authStaff->team->slug;
        }

        $team = Team::query()->firstWhere('slug', $teamSlug);
        if (! $team instanceof Team) {
            throw new \InvalidArgumentException("Unable to find team {$teamSlug}");
        }

        return $team;
    }

    public function hasStaff(): bool
    {
        $by = (string) $this->query('by');
        return str_starts_with($by, 'staff:');
    }

    public function getStaffEmail(): string
    {
        if (! $this->hasStaff()) {
            throw new \BadMethodCallException('Unable to find team-member filter!');
        }

        return $this->parseBy((string) $this->query('by'))['identifier'];
    }
}
