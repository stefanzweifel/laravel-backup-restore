<?php declare(strict_types=1);

use App\Models\DailyUpdates\DailyUpdate;
use Database\Factories\DailyUpdates\DailyUpdateFactory;
use Database\Factories\StaffFactory;
use Inertia\Testing\AssertableInertia as Assert;
use function Pest\Faker\fake;

it('should redirect to daily updates page', function () {
    /** @psalm-scope-this \Illuminate\Foundation\Testing\TestCase */
    $this
        ->get('/')
        ->assertRedirect(route('peopleAndCulture.dailyUpdates.index'));
});

it('should render the daily update index page', function () {
    $staff = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('peopleAndCulture.dailyUpdates.index'))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('DailyUpdates/Index')
            ->has('reports'));
});

it('should render the daily update create page', function () {
    $staff = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('peopleAndCulture.dailyUpdates.create'))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('DailyUpdates/Create')
            ->has('previousPlans'));
});

it('should_create_daily_update', function () {
    $staff = StaffFactory::new()->createOne();
    $dailyUpdate = DailyUpdateFactory::new()->makeOne();
    $date = now()->toDateString();

    $updateData = [
        'submission_date' => $date,
        'feeling' => $dailyUpdate->feeling->value,
        'update' => $dailyUpdate->done_today,
        'plans' => $dailyUpdate->plans_tomorrow,
        'blockers' => $dailyUpdate->blocked_progress,
        'highlights' => $dailyUpdate->highlights,
        'workday' => $dailyUpdate->is_full_day ? 'full' : 'half',
        'hours_worked' => $dailyUpdate->is_full_day ? 8 : 3,
        'holiday' => $dailyUpdate->has_leave,
    ];

    $this
        ->actingAs($staff)
        ->post(route('peopleAndCulture.dailyUpdates.store'), $updateData)
        ->assertSessionDoesntHaveErrors();

    $this->assertDatabaseHas(DailyUpdate::class, [
        'feeling' => $dailyUpdate->feeling->value,
        'done_today' => $dailyUpdate->done_today,
        'plans_tomorrow' => $dailyUpdate->plans_tomorrow,
        'blocked_progress' => $dailyUpdate->blocked_progress,
        'highlights' => $dailyUpdate->highlights,
        'is_full_day' => $dailyUpdate->is_full_day,
        'hours_worked' => $dailyUpdate->is_full_day ? 8 : 3,
        'has_leave' => $dailyUpdate->has_leave,
        'reporting_date' => $date,
    ]);
});

it('should render the update daily update page', function () {
    $staff = StaffFactory::new()->createOne();
    $dailyUpdate = DailyUpdateFactory::new()->createOne(['staff_id' => $staff->id]);

    $this
        ->actingAs($staff)
        ->get(route('peopleAndCulture.dailyUpdates.edit', $dailyUpdate))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('DailyUpdates/Edit')
            ->has('id')
            ->has('submission_date')
            ->has('feeling')
            ->has('update')
            ->has('plans')
            ->has('blockers')
            ->has('highlights')
            ->has('workday')
            ->has('hours_worked')
            ->has('holiday'));
});

it('should update a daily update', function () {
    $staff = StaffFactory::new()->createOne();
    $dailyUpdate = DailyUpdateFactory::new()->createOne(['staff_id' => $staff->id]);
    $date = now()->toDateString();

    $updateData = [
        'id' => $dailyUpdate->id,
        'submission_date' => $date,
        'feeling' => $dailyUpdate->feeling,
        'update' => fake()->text,
        'plans' => fake()->text,
        'blockers' => fake()->text,
        'highlights' => fake()->text,
        'workday' => $dailyUpdate->is_full_day ? 'full' : 'half',
        'hours_worked' => $dailyUpdate->is_full_day ? 8 : 3,
        'holiday' => $dailyUpdate->has_leave,
    ];

    $this
        ->actingAs($staff)
        ->json('post', route('peopleAndCulture.dailyUpdates.update', $dailyUpdate), $updateData)
        ->assertSessionDoesntHaveErrors()
        ->assertStatus(302);

    $this->assertDatabaseHas(DailyUpdate::class, [
        'done_today' => $updateData['update'],
        'plans_tomorrow' => $updateData['plans'],
        'blocked_progress' => $updateData['blockers'],
        'highlights' => $updateData['highlights'],
    ]);
});

it('should delete a daily update', function () {
    $staff = StaffFactory::new()->createOne();
    $dailyUpdate = DailyUpdateFactory::new()->createOne(['staff_id' => $staff->id]);

    $this
        ->actingAs($staff)
        ->delete(route('peopleAndCulture.dailyUpdates.destroy', $dailyUpdate))
        ->assertSessionDoesntHaveErrors()
        ->assertStatus(303);

    $this->assertSoftDeleted(DailyUpdate::class, [
        'id' => $dailyUpdate->id,
    ]);
});
