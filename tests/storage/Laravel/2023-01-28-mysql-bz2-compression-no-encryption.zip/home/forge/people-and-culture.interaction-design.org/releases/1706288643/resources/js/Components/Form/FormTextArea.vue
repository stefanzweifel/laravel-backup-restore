<script lang="ts">
export default {
  inheritAttrs: false,
};
</script>

<script setup lang="ts">
withDefaults(
  defineProps<{
    label: string;
    id: string;
    modelValue: string;
    error?: string;
    helpText?: string;
  }>(),
  {
    error: '',
    helpText: '',
  }
);

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void;
}>();

const emitUpdateModelValue = (event: Event) => {
  emit('update:modelValue', (event.target as HTMLInputElement).value);
};
</script>

<template>
  <label
    :for="id"
    class="cursor-pointer text-lg text-neutral-600 leading-3"
    v-html="label"
  />
  <textarea
    :value="modelValue"
    :id="id"
    @change="emitUpdateModelValue"
    v-bind="$attrs"
    class="textarea mt-1"
    :class="{'border-red-500 focus:ring focus:ring-red-200': error}"
  />
  <div v-if="error" class="text-red-700 mt-2 text-sm">
    {{ error }}
  </div>
  <div v-if="helpText && !error" class="text-sm text-neutral-500 mt-2">
    {{ helpText }}
  </div>
</template>
