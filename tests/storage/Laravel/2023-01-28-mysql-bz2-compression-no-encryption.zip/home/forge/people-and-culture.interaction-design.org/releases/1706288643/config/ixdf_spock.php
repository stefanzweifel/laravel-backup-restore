<?php declare(strict_types=1);

return [
    /**
     * Where to find the link to the calendar?
     * - open https://spockoffice.com/spockapp/calendar/
     * - authenticate via Slack
     * - find "Subscribe Company Calendar" button in the top right corner
     * - Use the "Copy Link Address" option or equivalent option in the browser to copy the link
     * - Replace "webcal://" with "https://"
     */
    'calendar' => 'https://spockoffice.com/spockapp/feed/8df8670b6ebe42d9e3a4ded710ff07c6/team.ics',

    /**
     * The ID translation layer can be used to retrieve a unique Spock user ID based on the provided Slack user ID.
     */
    'idTranslationLayer' => 'https://spockoffice.com/spockapp/uid-translate/8df8670b6ebe42d9e3a4ded710ff07c6/%s/',
];
