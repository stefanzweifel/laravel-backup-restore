<?php declare(strict_types=1);

namespace App\Services\Spock;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

final class SlackToSpockIdTranslator
{
    /** Take a Slack user ID and return Spock user ID. */
    public function translate(string $slackUserId): string
    {
        $response = Http::get(sprintf((string) config('ixdf_spock.idTranslationLayer'), $slackUserId));

        if ($response->notFound()) {
            Log::warning("Unable to translate Slack user ID {$slackUserId} to a Spock user ID.", [
                'response' => $response,
            ]);
            return '';
        }

        if ($response->failed()) {
            Log::warning('Unable to reach remote Spock server.', [
                'response' => $response,
            ]);
            return '';
        }

        return (string) $response->json('unique_user_id');
    }
}
