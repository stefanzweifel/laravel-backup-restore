<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::dropIfExists('peopleAndCulture__daily_update_sheets');
    }

    public function down(): void
    {
        Schema::create('peopleAndCulture__daily_update_sheets', static function (Blueprint $table): void {
            $table->increments('id');
            $table->string('sheet_id')->comment('Google sheet Id of import source');
            $table->string('range')->comment('Range of columns and rows imported');
            $table->unsignedInteger('last_index')->nullable();
            $table->boolean('is_success')->comment('Was the import successful?');
            $table->timestamps();
        });
    }
};
