<?php declare(strict_types=1);

namespace App\Services\DailyUpdates;

use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Report\DailyUpdateDTO;
use App\Models\DailyUpdates\Report\NullUpdateDTO;
use App\Models\DailyUpdates\Report\Report;
use App\ValueObjects\DatetimeRange;
use Carbon\CarbonInterface;
use Illuminate\Support\Collection;

/** @template T of \App\Models\DailyUpdates\Report\Report */
abstract class DailyUpdateReportGenerator
{
    public function __construct(protected readonly DatetimeRange $datetimeRange)
    {
    }

    /** @return T */
    abstract public function generate(): Report;

    protected function calculateLastUpdatedDate(): ?CarbonInterface
    {
        $update = DailyUpdate::query()->latest()->first();

        return $update instanceof DailyUpdate ? $update->created_at : null;
    }

    protected function numberOfWorkingDays(): int
    {
        $endDateToConsider = $this->datetimeRange->to->min(now()->subDay()->endOfDay());

        return (int) ceil($endDateToConsider->floatDiffInDays($this->datetimeRange->from)) - $endDateToConsider->diffInWeekendDays($this->datetimeRange->from);
    }

    /** @param array<string, array<string, \App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO>> $reports */
    protected function getNumberOfHalfDayReports(array $reports): int
    {
        return (int) collect($reports)
            ->sum(static fn (Collection $updates): int => (int) $updates
                ->filter(static fn (DailyUpdateDTO|NullUpdateDTO $updateDTO): bool => $updateDTO instanceof DailyUpdateDTO)
                ->sum(static fn (DailyUpdateDTO $updateDTO): int => $updateDTO->isFullDay ? 0 : 1));
    }

    /** @param array<string, array<string, \App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO>> $reports */
    protected function getNumberOfFullDayReports(array $reports): int
    {
        return (int) collect($reports)
            ->sum(static fn (Collection $updates): int => (int) $updates
                ->filter(static fn (DailyUpdateDTO|NullUpdateDTO $updateDTO): bool => $updateDTO instanceof DailyUpdateDTO)
                ->sum(static fn (DailyUpdateDTO $updateDTO): int => $updateDTO->isFullDay ? 1 : 0));
    }
}
