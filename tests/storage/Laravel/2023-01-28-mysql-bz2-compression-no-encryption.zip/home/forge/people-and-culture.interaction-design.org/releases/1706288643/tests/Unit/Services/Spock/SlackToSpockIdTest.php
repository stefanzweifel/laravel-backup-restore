<?php declare(strict_types=1);

namespace Tests\Unit\Services\Spock;

use App\Services\Spock\SlackToSpockIdTranslator;
use Illuminate\Support\Facades\Http;

it('should translate Slack user id to Spock user id', function () {
    Http::fake([
        'spockoffice.com/*' => Http::response(['unique_user_id' => 'U7DFA81EH942L45V7OP442K36P1G48TF2'], 200),
    ]);

    $spockUserId = (new SlackToSpockIdTranslator())->translate('U0214PRBQVG');

    $this->assertSame('U7DFA81EH942L45V7OP442K36P1G48TF2', $spockUserId);
});
