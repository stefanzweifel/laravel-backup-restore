<script setup lang="ts">
import {trans} from 'laravel-vue-i18n';
import {Analytics, Filters} from '@/types';
import BarChart from '@/Components/Charts/BarChart.vue';

defineProps<{
  date?: string;
  filters: Filters;
  analytics: Analytics;
}>();
</script>

<template>
  <section class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
    <div v-if="filters.by?.startsWith('team') && date">
      <h3 class="text-2xl font-bold mb-6">
        {{ trans('dailyUpdates.chart.memberLabel', {date: date}) }}
      </h3>
      <BarChart
        :datasets="analytics.teamChartData.datasets"
        :labels="analytics.teamChartData.labels"
        :max-scale-value="date.includes('month') ? 23 : 7"
      />
    </div>

    <template v-if="filters.by?.startsWith('staff')">
      <div>
        <h3 class="text-2xl font-bold mb-6">
          {{ trans('dailyUpdates.chart.weekLabel') }}
        </h3>
        <BarChart
          :datasets="analytics.teamMemberChartData.weekly.datasets"
          :labels="analytics.teamMemberChartData.weekly.labels"
          :max-scale-value="7"
        />
      </div>
      <div>
        <h3 class="text-2xl font-bold mb-6">
          {{ trans('dailyUpdates.chart.monthLabel') }}
        </h3>
        <BarChart
          :datasets="analytics.teamMemberChartData.monthly.datasets"
          :labels="analytics.teamMemberChartData.monthly.labels"
          :max-scale-value="23"
        />
      </div>
    </template>
  </section>
</template>
