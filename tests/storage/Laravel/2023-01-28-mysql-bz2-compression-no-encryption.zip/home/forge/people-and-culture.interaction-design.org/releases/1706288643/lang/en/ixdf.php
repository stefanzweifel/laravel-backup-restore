<?php declare(strict_types=1);

return [
    'name' => 'The Interaction Design Foundation',
];
