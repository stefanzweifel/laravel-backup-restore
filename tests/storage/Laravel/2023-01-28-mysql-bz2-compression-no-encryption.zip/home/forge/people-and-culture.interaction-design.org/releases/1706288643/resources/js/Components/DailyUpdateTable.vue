<script setup lang="ts">
import {computed} from 'vue';
import {Link} from '@inertiajs/inertia-vue3';
import {Inertia} from '@inertiajs/inertia';
import {trans} from 'laravel-vue-i18n';
import route from 'ziggy-js';

import {DailyUpdateReport, Feeling, Leave} from '@/types';

import IconDelete from '@/Components/Icons/IconDelete.vue';
import IconEdit from '@/Components/Icons/IconEdit.vue';

const props = defineProps<{
  reports: {
    string: DailyUpdateReport[]; // where key is a human-readable date
  };
  leaves: Leave[];
}>();

const staffLeaves = computed(() => (email: string, date: string) => {
  return props.leaves.filter(leave => leave.staffEmail === email && leave.leaveDate === date);
});

const deleteDailyUpdate = (id: number) => {
  if (window.confirm(trans('dailyUpdates.delete'))) {
    Inertia.delete(route('peopleAndCulture.dailyUpdates.destroy', id));
  }
};
</script>

<template>
  <div class="mt-8">
    <table class="table-auto font-serif text-sm">
      <tr :key="date" v-for="(rpts, date) in reports">
        <table class="w-full mb-6">
          <tr>
            <td class="p-2 bg-neutral-700 text-base">
              <h3 class="text-2xl font-bold">🗓️ {{ date }}</h3>
            </td>
          </tr>
          <tr :key="idx" v-for="(report, idx) in rpts">
            <td v-if="report.submitted">
              <table class="w-full mb-5">
                <tr>
                  <td
                    v-if="report.isFullDay"
                    class="p-2 bg-neutral-200"
                    colspan="3"
                  >
                    <h4
                      class="text-xl"
                      v-html="
                      trans('dailyUpdates.fullDayReport', {
                      name: report.staffName,
                      feeling: Feeling[report.feelingToday as keyof typeof Feeling],
                      })
                      "></h4>
                  </td>
                  <td
                    v-else
                    class="p-2 bg-neutral-200"
                    colspan="3">
                    <h4
                      class="text-xl"
                      v-html="
                        trans('dailyUpdates.halfDayReport', {
                          name: report.staffName,
                          feeling: Feeling[report.feelingToday as keyof typeof Feeling],
                          hours: report.hoursWorked?.toString()!,
                        })
                      "></h4>
                  </td>
                  <td
                    class="mt-2 flex space-x-1 justify-end"
                    v-if="report.userCanUpdate"
                  >
                    <Link
                      class="text-brand-02 hover:text-brand-01"
                      :href="
                        route(
                          'peopleAndCulture.dailyUpdates.edit',
                          report.updateId
                        )
                      "
                    >
                      <IconEdit />
                    </Link>

                    <button
                      class="text-red-700 hover:text-red-500"
                      @click="deleteDailyUpdate(report.updateId!)"
                      :href="
                        route(
                          'peopleAndCulture.dailyUpdates.destroy',
                          report.updateId
                        )
                      "
                    >
                      <IconDelete />
                    </button>
                  </td>
                </tr>
                <tr></tr>
                <tr class="text-left border-neutral-300 border-b-2">
                  <th class="p-2" style="width: 50%">
                    {{ trans('general.done') }}
                  </th>
                  <th class="p-2">{{ trans('dailyUpdates.plans') }}</th>
                </tr>
                <tr>
                  <td class="align-top whitespace-pre-wrap break-words p-2">
                    {{ report.doneToday }}
                  </td>
                  <td class="align-top whitespace-pre-wrap break-words p-2">
                    {{ report.plansTomorrow }}
                  </td>
                </tr>
                <tr class="border-neutral-300 border-t-2">
                  <td class="break-words p-2 pb-4" colspan="2">
                    <b>{{ trans('dailyUpdates.blockers') }}:</b>
                    {{ report.blockedProgress }}
                  </td>
                </tr>
                <tr class="border-neutral-300 border-t-2">
                  <td class="break-words p-2 pb-4" colspan="2">
                    <b>{{ trans('dailyUpdates.highlights') }}:</b>
                    {{ report.highlights }}
                  </td>
                </tr>
                <tr class="border-neutral-300 border-t-2">
                  <td class="break-words p-2 pb-4" colspan="2">
                    <p v-for="leave in staffLeaves(report.staffEmail, report.reportingDate)">
                      {{ trans('dailyUpdates.leave') }}: <b>{{ leave.leavePeriod }}</b>
                    </p>
                  </td>
                </tr>
              </table>
            </td>
            <td v-else>
              <table class="w-full mb-5">
                <tr>
                  <td
                    class="p-2 bg-neutral-200"
                    colspan="3"
                  >
                    <h4 class="text-xl" v-html="trans('dailyUpdates.noUpdates', {name: report.staffName})"></h4>
                    <p v-for="leave in staffLeaves(report.staffEmail, report.reportingDate)">
                      {{ trans('dailyUpdates.leave') }}: <b>{{ leave.leavePeriod }}</b>
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </tr>
    </table>
  </div>
</template>
