<?php declare(strict_types=1);

return [
    'client_id' => env('IXDF_OAUTH_CLIENT_ID'),
    'authorization_url' => env('IXDF_OAUTH_AUTHORIZATION_URL'),
    'token_url' => env('IXDF_OAUTH_TOKEN_URL'),
    'profile_url' => env('IXDF_OAUTH_PROFILE_URL'),
];
