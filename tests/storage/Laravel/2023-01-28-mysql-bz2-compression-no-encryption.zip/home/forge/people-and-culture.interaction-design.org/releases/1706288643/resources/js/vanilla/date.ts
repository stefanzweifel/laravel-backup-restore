export function formatDateForInput(date: Date): string {
  const formattedDate = new Date(date);
  const monthNumber = formattedDate.getMonth() + 1;
  const dayNumber = formattedDate.getDate();
  return `${formattedDate.getFullYear()}-${
    monthNumber < 10 ? '0' + monthNumber : monthNumber
  }-${dayNumber < 10 ? '0' + dayNumber : dayNumber}`;
}

export function stringToDate(dateAsString: string): Date {
  const parts = dateAsString.split('-');

  return new Date(
    parseInt(parts[0]),
    parseInt(parts[1]) - 1,
    parseInt(parts[2])
  );
}

export function getWeekNumberFromDate(date: Date): number {
  const d = new Date(
    Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())
  );
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}
