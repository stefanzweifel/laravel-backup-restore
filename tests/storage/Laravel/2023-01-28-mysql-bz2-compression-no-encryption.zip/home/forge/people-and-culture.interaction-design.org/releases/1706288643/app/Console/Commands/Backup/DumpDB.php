<?php declare(strict_types=1);

namespace App\Console\Commands\Backup;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

final class DumpDB extends Command
{
    /** @var string */
    protected $name = 'backup:dump';

    public function handle(): int
    {
        $dirName = (string) config('backup.backup.name');
        $zipFileName = storage_path("app/{$dirName}/db.zip");

        $this->info('Dumping database backup');

        Artisan::call('backup:run --only-db --filename=db.zip --only-to-disk=local', [], $this->output);

        if (! File::exists($zipFileName)) {
            $this->error("Unable to find db dump at {$zipFileName}");

            return 1;
        }

        Storage::disk('local')->move("{$dirName}/db.zip", 'latest-db-dump.zip');

        return 0;
    }
}
