<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('peopleAndCulture__daily_updates', static function (Blueprint $table) {
            $table->text('highlights')->comment('Share something positive about your day')->after('blocked_progress');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropColumns('peopleAndCulture__daily_updates', ['highlights']);
    }
};
