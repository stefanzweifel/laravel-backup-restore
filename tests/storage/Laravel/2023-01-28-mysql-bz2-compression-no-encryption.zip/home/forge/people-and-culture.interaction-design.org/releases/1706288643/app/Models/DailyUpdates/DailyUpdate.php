<?php declare(strict_types=1);

namespace App\Models\DailyUpdates;

use App\Models\Staff;
use Carbon\CarbonInterface;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property int $id
 * @property \Illuminate\Support\Carbon $reporting_date
 * @property \App\Models\DailyUpdates\Feeling $feeling
 * @property string $done_today
 * @property string $plans_tomorrow
 * @property string $blocked_progress
 * @property string $highlights
 * @property bool $is_full_day
 * @property int<1, 24> $hours_worked
 * @property bool $has_leave @deprecated Not used after introducing {@see \App\Models\StaffLeave\Leave}.
 * @property int $staff_id
 * @property \Illuminate\Support\Carbon $created_at Time at which the object was created.
 * @property \Illuminate\Support\Carbon $updated_at Time at which the object was last time updated.
 * @property \Illuminate\Support\Carbon|null $deleted_at Time at which the object was deleted.
 * @property-read \App\Models\Staff $staff
 */
final class DailyUpdate extends Model
{
    use SoftDeletes;

    /** @var string */
    protected $table = 'peopleAndCulture__daily_updates';

    /** @var array<string, string> */
    protected $casts = [
        'reporting_date' => 'date',
        'is_full_day' => 'bool',
        'has_leave' => 'bool',
        'feeling' => Feeling::class,
    ];

    public function scopeReportedWithin(
        Builder $query,
        CarbonInterface $dateTimeRangeStart,
        CarbonInterface $dateTimeRangeEnd
    ): void {
        $query->whereBetween('reporting_date', [$dateTimeRangeStart, $dateTimeRangeEnd]);
    }

    public function scopeForMember(Builder $query, string $email): void
    {
        $query->whereHas('staff', static function (\Illuminate\Contracts\Database\Query\Builder $query) use ($email): void {
            $query->where('email', $email);
        });
    }

    public function scopeForTeam(Builder $query, string $teamName): void
    {
        $query->where('team_name', $teamName);
    }

    public function staff(): BelongsTo
    {
        return $this->belongsTo(Staff::class)->withoutGlobalScopes();
    }
}
