<?php declare(strict_types=1);

namespace Tests\Unit\Services\DailyUpdates;

use App\Http\Controllers\DailyUpdates\Presenters\TeamDailyUpdatePresenter;
use App\Models\DailyUpdates\Report\DailyUpdateDTO;
use App\Models\DailyUpdates\Report\NullUpdateDTO;
use App\Models\DailyUpdates\Report\TeamReport;
use App\Models\Staff;
use App\Models\StaffLeave\Report\LeaveDTO;
use App\Services\DailyUpdates\TeamDailyUpdateReportGenerator;
use App\ValueObjects\DatetimeRange;
use Carbon\CarbonInterface;
use Carbon\CarbonPeriod;
use Database\Factories\DailyUpdates\DailyUpdateFactory;
use Database\Factories\StaffLeave\StaffLeaveFactory;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

it('should work for weekly report with one full day report on weekday mid month', function () {
    Carbon::setTestNow(Carbon::parse('2022-02-09 12:00'));
    $jan24th = now()->startOf('week')->subWeeks(2);
    $jan25th = $jan24th->clone()->addDay();
    $jan26th = $jan25th->clone()->addDay();
    $jan30th = now()->startOf('week')->subWeeks(2)->endOfWeek();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($jan25th)->createOne();
    $leaveOnTheSameDayAsAnUpdate = StaffLeaveFactory::new()->for($update->staff, 'staff')->onDate($jan25th)->createOne();
    $leave = StaffLeaveFactory::new()->for($update->staff, 'staff')->onDate($jan26th)->createOne();
    $sut = new TeamDailyUpdateReportGenerator($update->staff->team, new DatetimeRange($jan24th, $jan30th));

    $report = $sut->generate();

    $expected = new TeamReport(
        $update->staff->team->name,
        getTeamMembers($update->staff),
        5,
        $update->created_at,
        getUpdates([DailyUpdateDTO::fromDailyUpdate($update)], $update->staff->team->members, $jan24th, $jan30th),
        [
            LeaveDTO::createFromModel($leave, $leave->staff->email),
            LeaveDTO::createFromModel($leaveOnTheSameDayAsAnUpdate, $leaveOnTheSameDayAsAnUpdate->staff->email), // ignored in statistics
        ],
        [['count' => 1, 'name' => $update->staff->name, 'email' => $update->staff->email]],
        [['count' => 1, 'name' => $leave->staff->name, 'email' => $leave->staff->email]],
        1,
        0,
        4,
        0
    );
    $this->assertEquals($expected, $report);
});

it('should work for monthly report with one full day report mid month', function () {
    Carbon::setTestNow(Carbon::parse('2022-02-09 12:00'));
    $jan1st = now()->subMonth()->startOfMonth();
    $jan25th = now()->subMonth()->setDay(25);
    $jan30th = now()->subMonth()->endOfMonth();
    $update = DailyUpdateFactory::new()->fullDay()->reportedAt($jan25th)->createOne();
    $staffName = $update->staff->name;
    $staffEmail = $update->staff->email;
    $sut = new TeamDailyUpdateReportGenerator($update->staff->team, new DatetimeRange($jan1st, $jan30th));

    $report = $sut->generate();

    $expected = new TeamReport(
        $update->staff->team->name,
        getTeamMembers($update->staff),
        21,
        $update->created_at,
        getUpdates([DailyUpdateDTO::fromDailyUpdate($update)], $update->staff->team->members, $jan1st, $jan30th),
        [],
        [['count' => 1, 'name' => $staffName, 'email' => $staffEmail]],
        [['count' => 0, 'name' => $staffName, 'email' => $staffEmail]],
        1,
        0,
        20,
        0
    );
    $this->assertEquals($expected, $report);
});

/** @return list<array{name: string, email: string}> */
function getTeamMembers(Staff $staff): array
{
    return $staff->team->members()
        ->select(['name', 'email'])
        ->get()
        ->toArray();
}

/**
 * @param array<\App\Models\DailyUpdates\Report\DailyUpdateDTO> $dailyUpdates
 * @param \Illuminate\Support\Collection<int, \App\Models\Staff> $teamMembers
 * @return \Illuminate\Support\Collection<string, array<string, (\App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO)>>
 */
function getUpdates(array $dailyUpdates, Collection $teamMembers, CarbonInterface $from, CarbonInterface $to): array // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
{
    $dailyUpdatesCollection = collect($dailyUpdates)
        ->keyBy(static fn (DailyUpdateDTO $dailyUpdateDTO): string => md5(json_encode([
            'e' => $dailyUpdateDTO->staffEmail,
            't' => Carbon::parse($dailyUpdateDTO->reportingDate)->getTimestamp(),
        ], \JSON_THROW_ON_ERROR)));
    $updates = [];
    $period = CarbonPeriod::create($from, $to)->toArray();
    foreach ($period as $date) {
        $key = $date->format(TeamDailyUpdatePresenter::REPORT_DATETIME_FORMAT);
        if (!array_key_exists($key, $updates)) {
            $updates[$key] = collect([]);
        }

        foreach ($teamMembers as $teamMember) {
            $key1 = md5(json_encode([
                'e' => $teamMember->email,
                't' => $date->getTimestamp(),
            ], \JSON_THROW_ON_ERROR));
            $updates[$key]->put($teamMember->email, $dailyUpdatesCollection->has($key1)
                ? $dailyUpdatesCollection->get($key1)
                : NullUpdateDTO::create($teamMember, $date));
        }
    }

    return $updates;
}
