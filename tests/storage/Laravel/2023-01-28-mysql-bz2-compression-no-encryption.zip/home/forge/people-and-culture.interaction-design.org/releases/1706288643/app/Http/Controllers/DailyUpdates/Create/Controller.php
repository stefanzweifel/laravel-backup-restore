<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Create;

use App\Models\DailyUpdates\DailyUpdate;
use App\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;

final class Controller
{
    public function __invoke(Request $request): Response
    {
        $staff = Auth::user();
        assert($staff instanceof Staff);

        /** @var \App\Models\DailyUpdates\DailyUpdate|null $latestUpdate */
        $latestUpdate = DailyUpdate::query()->latest('reporting_date')->firstWhere('staff_id', $staff->id);

        return Inertia::render('DailyUpdates/Create', [
            'previousPlans' => $latestUpdate?->plans_tomorrow ?? '',
            'preselectedDate' => $request->query('date'),
        ]);
    }
}
