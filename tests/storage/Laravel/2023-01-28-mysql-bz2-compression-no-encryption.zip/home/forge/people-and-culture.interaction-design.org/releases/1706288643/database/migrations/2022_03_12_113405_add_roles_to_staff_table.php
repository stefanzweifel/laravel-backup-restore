<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('peopleAndCulture__staff', static function (Blueprint $table) {
            $table->boolean('is_admin')->after('team_id')->default(false);
        });
    }

    public function down(): void
    {
        Schema::table('peopleAndCulture__staff', static function (Blueprint $table) {
            $table->dropColumn('is_admin');
        });
    }
};
