<?php declare(strict_types=1);

namespace Database\Factories;

use App\Models\Staff;
use Illuminate\Support\Str;

/** @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Staff> */
final class StaffFactory extends \Illuminate\Database\Eloquent\Factories\Factory
{
    /** @var class-string<\App\Models\Staff> */
    protected $model = Staff::class;

    /** @inheritDoc */
    public function definition(): array
    {
        return [
            'name' => $this->faker->name,
            'email' => $this->faker->unique()->email,
            'team_id' => TeamFactory::new(),
            'slack_user_id' => 'U'.Str::of(Str::random(8))->upper()->toString(),
            'is_admin' => false,
        ];
    }

    public function admin(): self
    {
        return $this->state([
            'is_admin' => true,
        ]);
    }
}
