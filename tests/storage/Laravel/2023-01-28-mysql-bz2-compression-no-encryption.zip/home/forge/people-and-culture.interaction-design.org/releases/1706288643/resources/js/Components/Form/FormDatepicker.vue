<script setup lang="ts">
import {computed} from 'vue';
import {formatDateForInput, stringToDate} from '@/vanilla/date';

const props = defineProps<{
  /** @see https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/date */
  modelValue: Date;
  label: string;
  id: string;
  error?: string;
  helpText?: string;
}>();
const emit = defineEmits<{
  (e: 'update:modelValue', value: Date): void;
}>();

const formattedDateValue = computed(() => formatDateForInput(props.modelValue));
const emitUpdateModelValue = (event: Event) => {
  emit(
    'update:modelValue',
    stringToDate((event.target as HTMLInputElement).value)
  );
};
</script>

<template>
  <label
    :for="`dp-input-${id}`"
    class="cursor-pointer text-lg text-neutral-600"
    v-html="label"
  />
  <input
    :model-value="modelValue"
    @change="emitUpdateModelValue($event)"
    :uid="id"
    v-bind="$attrs"
    type="date"
    :value="formattedDateValue"
    class="input mt-1"
    required
    pattern="\d{4}-\d{2}-\d{2}"
    :max="formatDateForInput(new Date())"
  />
  <div v-if="error" class="text-red-700 mt-2 text-sm">{{ error }}</div>
  <div v-if="helpText && !error" class="text-sm text-neutral-500 mt-2">
    {{ helpText }}
  </div>
</template>
