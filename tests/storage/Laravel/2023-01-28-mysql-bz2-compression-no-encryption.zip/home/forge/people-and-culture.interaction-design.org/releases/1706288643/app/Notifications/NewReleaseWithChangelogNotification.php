<?php declare(strict_types=1);

namespace App\Notifications;

use App\Facades\GithubUrl;
use Illuminate\Notifications\Messages\SlackAttachment;
use Illuminate\Notifications\Messages\SlackMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\App;

final class NewReleaseWithChangelogNotification extends Notification
{
    /** @return array<string> */
    public function via(): array
    {
        return ['slack'];
    }

    /** @param array{login: string, html_url: string, avatar_url: string} $authorInfo */
    public function __construct(
        private readonly string $appVersion,
        private readonly array $authorInfo,
        private readonly string $releaseNotes
    ) {
    }

    public function toSlack(): SlackMessage
    {
        $versionType = $this->versionType($this->appVersion);

        return (new SlackMessage())
            ->from('Deployment Notifier', ':octocat:')
            ->to(config('release.slack.channel'))
            ->content(sprintf(
                ':rocket: We just deployed a new %s *<%s|%s>* version of *%s* to %s.',
                $versionType,
                GithubUrl::tag($this->appVersion),
                $this->appVersion,
                config('release.github.repository'),
                App::environment()
            ))
            ->attachment(function (SlackAttachment $attachment) use ($versionType): void {
                $attachment
                    ->color($versionType === 'patch' ? 'warning' : 'good')
                    ->content($this->releaseNotes)
                    ->author($this->authorInfo['login'], $this->authorInfo['html_url'], $this->authorInfo['avatar_url']);
            })
            ->unfurlLinks(false)
            ->unfurlMedia(false);
    }

    private function versionType(string $version): string
    {
        $parts = explode('.', $version);
        if (count($parts) < 3) {
            return 'unknown';
        }

        if ($parts[1] === '0' && $parts[2] === '0') {
            return 'major';
        }

        if ($parts[2] === '0') {
            return 'minor';
        }

        return 'patch';
    }
}
