<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('peopleAndCulture__staff', static function (Blueprint $table): void {
            $table->json('working_days')->nullable()->after('timezone');
        });
    }

    public function down(): void
    {
        Schema::dropColumns('peopleAndCulture__staff', ['working_days']);
    }
};
