<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Index;

use App\Services\DailyUpdates\DailyUpdateAbstractFactory;
use Inertia\Response;

final class Controller
{
    public function __invoke(DailyUpdateAbstractFactory $factory): Response
    {
        $report = $factory->makeGenerator()->generate();

        return $factory->makePresenter()->present($report);
    }
}
