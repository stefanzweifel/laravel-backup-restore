<script setup lang="ts">
import {Head} from '@inertiajs/inertia-vue3';
import {trans} from 'laravel-vue-i18n';

import Layout from '@/Shared/Layout.vue';
import DailyUpdateForm from '@/Components/DailyUpdateForm.vue';

const props = defineProps<{
  id: number;
  submission_date: string;
  feeling: number;
  update: string;
  plans: string;
  blockers: string;
  highlights: string;
  workday: string;
  holiday: string;
  hours_worked: number;
}>();
</script>

<template>
  <Layout>
    <Head :title="trans('dailyUpdates.form.editTitle')" />
    <section class="md:w-3/4 mx-auto py-12">
      <h1 class="text-4xl font-bold mb-3">
        {{ trans('dailyUpdates.form.editTitle') }} 🚀 🚀
      </h1>
      <a
        href="https://www.interaction-design.org/courses/ixdf-handbook/lessons/daily-updates"
        target="_blank"
        class="link mb-6"
      >
        {{ trans('dailyUpdates.info') }}
      </a>

      <DailyUpdateForm v-bind="props" />
    </section>
  </Layout>
</template>
