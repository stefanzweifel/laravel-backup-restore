<?php declare(strict_types=1);

namespace App\Utility\Chart;

/**
 * Represents the data of a "generic" chart with multiple data sets.
 * @see DataSet
 * @see DataPoint
 */
final class Chart
{
    /** @var list<string> */
    private array $dataPointsLabels = [];

    /** @var \App\Utility\Chart\DataSet[] */
    private array $dataSets = [];

    /** @param list<string> $labels */
    public function setDataPointsLabels(array $labels): static
    {
        $this->dataPointsLabels = $labels;

        return $this;
    }

    /** @return list<string> */
    public function getDataPointsLabels(): array
    {
        return $this->dataPointsLabels;
    }

    public function addDataSet(DataSet $dataSet): static
    {
        $this->dataSets[] = $dataSet;

        return $this;
    }

    public function getDataSetsCount(): int
    {
        return count($this->dataSets);
    }

    public function getDataSet(int $index): DataSet
    {
        return $this->dataSets[$index];
    }

    /** @return float|int|null */
    public function getDataPointValue(int $dataSetIndex, int $dataPointIndex)
    {
        return $this->getDataSet($dataSetIndex)->getDataPoint($dataPointIndex)->getValue();
    }

    public function getDataPointTooltip(int $dataSetIndex, int $dataPointIndex): string
    {
        return $this->getDataSet($dataSetIndex)->getDataPoint($dataPointIndex)->getTooltip();
    }

    /** @return array{labels: string[], datasets: array<array{legend: string, data: array<array{value: float|int|null, tooltip: string}>}>} */
    public function toArray(): array
    {
        return [
            'labels' => $this->dataPointsLabels,
            'datasets' => array_map(
                static fn (DataSet $dataSet): array => $dataSet->toArray(),
                $this->dataSets
            ),
        ];
    }
}
