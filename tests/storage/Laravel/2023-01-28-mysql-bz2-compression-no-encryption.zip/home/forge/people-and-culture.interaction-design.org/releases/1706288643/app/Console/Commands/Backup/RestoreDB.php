<?php declare(strict_types=1);

namespace App\Console\Commands\Backup;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

final class RestoreDB extends Command
{
    /** @var string */
    protected $signature = 'backup:restore {--db=forge} {--disk=production-app-storage} {--password=secret}';

    public function handle(): int // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh, SlevomatCodingStandard.Functions.FunctionLength.FunctionLength, SlevomatCodingStandard.Files.FunctionLength.FunctionLength
    {
        if (App::isProduction()) {
            $answer = $this->ask("You're running restore on production! Please type 'confirm' to confirm it.");

            if ($answer !== 'confirm') {
                $this->info('Terminating...');

                return 1;
            }
        }

        $outputPath = storage_path('app');
        $databaseName = (string) $this->option('db');
        $fileName = "mysql-{$databaseName}.sql.gz";
        $databaseDumpFile = "{$outputPath}/db-dumps/{$fileName}";
        $diskName = (string) $this->option('disk');

        $this->info('Getting latest backup file.');

        Storage::disk('local')->put('latest-db-dump.zip', Storage::disk($diskName)->get('latest-db-dump.zip'));

        $this->info('Successfully copied the backup file to latest-db-dump.zip');

        $zipPassword = (string) $this->option('password');
        $path = storage_path('app/latest-db-dump.zip');
        $this->info('Unzipping the compressed dump');
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) {
            $this->error('Unable to open compressed database dump.');

            return 1;
        }

        $zip->setPassword($zipPassword);
        $result = $zip->extractTo($outputPath);
        $zip->close();
        if ($result !== true) {
            $this->error('Zip extraction failed');

            return 1;
        }

        $this->info("Successfully extracted to {$outputPath}");

        if (! File::exists($databaseDumpFile)) {
            $this->error("Unable to find extracted db archive {$databaseDumpFile}");

            return 1;
        }

        $this->info('Dropping all database tables');

        Artisan::call('migrate:reset', [], $this->output);

        $this->info("Importing: {$databaseDumpFile}");

        $content = gzfile($databaseDumpFile);
        if (! is_array($content)) {
            $this->error('Unable to extract mysql dump');

            return 1;
        }

        $sql = implode('', $content);

        /** @var \Illuminate\Database\MySqlConnection $connection */
        $connection = DB::connection();
        $connection->getPdo()->exec($sql);

        $this->info("Removing uncompressed dump file {$databaseDumpFile}.", 'v');
        File::delete($databaseDumpFile);

        return 0;
    }
}
