<?php declare(strict_types=1);

namespace App\Services\StaffLeave;

use Carbon\CarbonInterface;
use Illuminate\Support\Carbon;

final readonly class StaffLeaveEvent
{
    private const CALENDAR_EVENT_DESCRIPTION_REGEX = '/Slack User: (@\w+) \((\w+)\)/';

    private function __construct(
        public string $calendarEventUid,
        public string $slackDisplayName,
        public string $spockUserId,
        public CarbonInterface $leaveDate,
        public string $leaveType,
        public LeavePeriod $leavePeriod
    ) {
    }

    public static function fromICalEvent(\ICal\Event $event): self
    {
        $leaveDate = Carbon::parse($event->dtstart);
        $summary = $event->summary;

        $summaryContents = array_map('trim', explode(' - ', $summary));
        $staffMemberName = $summaryContents[0] ?? null;
        $leaveType = $summaryContents[1] ?? null;
        $leavePeriod = $summaryContents[2] ?? null;

        if ($staffMemberName === null || $leaveType === null || $leavePeriod === null) {
            throw new \DomainException("Unexpected format of event's summary: {$summary}");
        }

        return new self(
            $event->uid,
            self::extractSlackDisplayNameFromDescription($event->description),
            self::extractSpockUserIdFromDescription($event->description),
            $leaveDate,
            $leaveType,
            LeavePeriod::from($leavePeriod)
        );
    }

    private static function extractSlackDisplayNameFromDescription(string $description): string
    {
        $matches = [];
        preg_match(self::CALENDAR_EVENT_DESCRIPTION_REGEX, $description, $matches);

        $slackDisplayName = $matches[1] ?? null;
        if ($slackDisplayName === null) {
            throw new \DomainException("Cannot extract Slack display name from calendar event's description: {$description}");
        }

        return $slackDisplayName;
    }

    private static function extractSpockUserIdFromDescription(string $description): string
    {
        $matches = [];
        preg_match(self::CALENDAR_EVENT_DESCRIPTION_REGEX, $description, $matches);

        $spockUserId = $matches[2] ?? null;
        if ($spockUserId === null) {
            throw new \DomainException("Cannot extract Spock user ID from calendar event's description: {$description}");
        }

        return $spockUserId;
    }
}
