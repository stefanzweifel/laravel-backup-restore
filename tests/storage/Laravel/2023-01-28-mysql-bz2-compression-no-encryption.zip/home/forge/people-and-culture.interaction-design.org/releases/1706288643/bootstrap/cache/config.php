<?php return array (
  'app' => 
  array (
    'name' => 'People-and-Culture',
    'env' => 'production',
    'debug' => true,
    'url' => 'https://people-and-culture.interaction-design.org',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:XkDjWn5jy6uSzNabwH4Y4+8zC4tjzA7I57JycLTCBMc=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'staff',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'staff' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Staff',
      ),
    ),
  ),
  'backup' => 
  array (
    'backup' => 
    array (
      'name' => 'People-and-Culture',
      'source' => 
      array (
        'files' => 
        array (
          'include' => 
          array (
            0 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643',
            1 => '/etc/nginx',
            2 => '/etc/php/8.2',
            3 => '/etc/supervisor',
          ),
          'exclude' => 
          array (
            0 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/vendor',
            1 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/node_modules',
            2 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/People-and-Culture',
            3 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/db-dumps',
            4 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/docker',
            5 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/tools',
            6 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/.git',
          ),
          'follow_links' => false,
          'ignore_unreadable_directories' => true,
          'relative_path' => NULL,
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'database_dump_compressor' => 'Spatie\\DbDumper\\Compressors\\Bzip2Compressor',
      'database_dump_file_extension' => '',
      'destination' => 
      array (
        'filename_prefix' => '',
        'disks' => 
        array (
          0 => 's3-backup',
          1 => 'local',
        ),
      ),
      'temporary_directory' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/app/backup-temp',
      'password' => 'rainbow',
      'encryption' => 'default',
    ),
    'notifications' => 
    array (
      'notifications' => 
      array (
        'Spatie\\Backup\\Notifications\\Notifications\\BackupHasFailedNotification' => 
        array (
          0 => 'slack',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\UnhealthyBackupWasFoundNotification' => 
        array (
          0 => 'slack',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupHasFailedNotification' => 
        array (
          0 => 'slack',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\BackupWasSuccessfulNotification' => 
        array (
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\HealthyBackupWasFoundNotification' => 
        array (
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupWasSuccessfulNotification' => 
        array (
        ),
      ),
      'notifiable' => 'Spatie\\Backup\\Notifications\\Notifiable',
      'mail' => 
      array (
        'to' => 'develop@interaction-design.org',
        'from' => 
        array (
          'address' => 'hello@example.com',
          'name' => 'Example',
        ),
      ),
      'slack' => 
      array (
        'webhook_url' => 'https://hooks.slack.com/services/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',
        'channel' => '#errors-production',
        'username' => 'People-and-Culture',
        'icon' => ':tornado:',
      ),
      'discord' => 
      array (
        'webhook_url' => '',
        'username' => '',
        'avatar_url' => '',
      ),
    ),
    'monitor_backups' => 
    array (
      0 => 
      array (
        'name' => 'People-and-Culture',
        'disks' => 
        array (
          0 => 's3-backup',
          1 => 'local',
        ),
        'health_checks' => 
        array (
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumAgeInDays' => 1,
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumStorageInMegabytes' => 5000,
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'default_strategy' => 
      array (
        'keep_all_backups_for_days' => 7,
        'keep_daily_backups_for_days' => 16,
        'keep_weekly_backups_for_weeks' => 8,
        'keep_monthly_backups_for_months' => 4,
        'keep_yearly_backups_for_years' => 2,
        'delete_oldest_backups_when_using_more_megabytes_than' => 5000,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'redis',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => NULL,
        'secret' => NULL,
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'people_and_culture_cache_',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'forge',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'forge',
        'username' => 'forge',
        'password' => 'BC7piFOLsFyQDVts7TI5',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
        'dump' => 
        array (
          'useSingleTransaction' => true,
        ),
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'people_and_culture_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/app/public',
        'url' => 'https://people-and-culture.interaction-design.org/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
      's3-backup' => 
      array (
        'driver' => 's3',
        'key' => 'AKIAIPSZZVATCAVMSWYA',
        'secret' => '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',
        'region' => 'us-west-1',
        'bucket' => 'idf--backup',
        'cache' => true,
      ),
      'production-app-storage' => 
      array (
        'driver' => 'sftp',
        'host' => 'people-and-culture.interaction-design.org',
        'username' => 'forge',
        'privateKey' => NULL,
        'root' => '/home/forge/people-and-culture.interaction-design.org/current/storage/app',
        'timeout' => 30,
      ),
    ),
    'links' => 
    array (
      '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/public/storage' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/app/public',
    ),
  ),
  'github' => 
  array (
    'default' => 'main',
    'connections' => 
    array (
      'main' => 
      array (
        'token' => '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',
        'method' => 'token',
      ),
    ),
    'cache' => 
    array (
      'main' => 
      array (
        'driver' => 'illuminate',
        'connector' => NULL,
      ),
      'bar' => 
      array (
        'driver' => 'illuminate',
        'connector' => 'redis',
      ),
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'ixdf_oauth' => 
  array (
    'client_id' => '95b32e86-5600-413e-8c66-3a2e984bde54',
    'authorization_url' => 'https://www.interaction-design.org/oauth/authorize',
    'token_url' => 'https://www.interaction-design.org/oauth/token',
    'profile_url' => 'https://www.interaction-design.org/api/members/profile',
  ),
  'ixdf_slack' => 
  array (
    'webhook' => 
    array (
      'url' => 'https://hooks.slack.com/services/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',
      'daily' => 
      array (
        'username' => 'Daily updates',
        'icon_url' => ':rooster:',
      ),
      'weekly' => 
      array (
        'username' => 'Weekly updates',
        'icon_url' => ':turkey:',
      ),
    ),
    'channel_for_all_updates' => '#daily-updates',
    'channel_for_team_leads' => '#team-leads',
    'channel_to_redirect_all_notifications' => NULL,
  ),
  'ixdf_spock' => 
  array (
    'calendar' => 'https://spockoffice.com/spockapp/feed/8df8670b6ebe42d9e3a4ded710ff07c6/team.ics',
    'idTranslationLayer' => 'https://spockoffice.com/spockapp/uid-translate/8df8670b6ebe42d9e3a4ded710ff07c6/%s/',
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => 'daily',
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'daily',
          1 => 'slack',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'tap' => 
        array (
          0 => 'App\\Logging\\LogEnhancer',
        ),
        'path' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/logs/laravel.log',
        'level' => 'notice',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'tap' => 
        array (
          0 => 'App\\Logging\\LogEnhancer',
        ),
        'path' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/logs/laravel.log',
        'level' => 'notice',
        'days' => 7,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'tap' => 
        array (
          0 => 'App\\Logging\\LogEnhancer',
        ),
        'url' => 'https://hooks.slack.com/services/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',
        'channel' => 'errors--production',
        'username' => 'People-and-Culture',
        'emoji' => ':boom:',
        'level' => 'critical',
        'replace_placeholders' => true,
      ),
      'slack-js' => 
      array (
        'driver' => 'slack',
        'tap' => 
        array (
          0 => 'App\\Logging\\LogEnhancer',
        ),
        'url' => 'https://hooks.slack.com/services/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',
        'channel' => 'js-errors--production',
        'username' => 'People-and-Culture',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'notice',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'notice',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'notice',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'notice',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.mailgun.org',
        'port' => 587,
        'encryption' => 'tls',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/resources/views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => NULL,
        'secret' => NULL,
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'release' => 
  array (
    'app_version' => '1.0.10-2-g5e2f397',
    'branch' => 'main',
    'github' => 
    array (
      'repository' => 'people-and-culture',
      'organisation' => 'InteractionDesignFoundation',
    ),
    'slack' => 
    array (
      'webhook' => 'https://hooks.slack.com/services/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',
      'channel' => '#releases',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'people-and-culture.interaction-design.org',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'token_prefix' => '',
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => 'xoxb-309411067905-tVSSpYGhqxaDtOFsIKiNKDye',
        'channel' => 'dev',
      ),
    ),
  ),
  'session' => 
  array (
    'driver' => 'redis',
    'lifetime' => '43200',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'people_and_culture_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/resources/views',
    ),
    'compiled' => '/home/forge/people-and-culture.interaction-design.org/shared/storage/framework/views',
  ),
  'inertia' => 
  array (
    'ssr' => 
    array (
      'enabled' => true,
      'url' => 'http://127.0.0.1:13714',
    ),
    'testing' => 
    array (
      'ensure_pages_exist' => true,
      'page_paths' => 
      array (
        0 => '/home/forge/people-and-culture.interaction-design.org/releases/1706288643/resources/js/Pages',
      ),
      'page_extensions' => 
      array (
        0 => 'js',
        1 => 'jsx',
        2 => 'svelte',
        3 => 'ts',
        4 => 'tsx',
        5 => 'vue',
      ),
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
