<?php declare(strict_types=1);

namespace App\Services\StaffLeave;

enum LeavePeriod: string
{
    case AllDay = 'All day';

    case AmOnly = 'AM only';

    case PmOnly = 'PM only';
}
