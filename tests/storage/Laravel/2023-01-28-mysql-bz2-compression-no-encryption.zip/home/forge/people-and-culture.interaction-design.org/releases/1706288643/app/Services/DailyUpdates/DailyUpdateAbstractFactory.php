<?php declare(strict_types=1);

namespace App\Services\DailyUpdates;

use App\Http\Controllers\DailyUpdates\Presenters\DailyUpdatePresenter;
use App\Http\Controllers\DailyUpdates\Presenters\IndividualDailyUpdatePresenter;
use App\Http\Controllers\DailyUpdates\Presenters\TeamDailyUpdatePresenter;
use App\Http\Requests\DailyUpdate\DailyUpdateAnalyticsRequest;
use App\Models\Staff;

final class DailyUpdateAbstractFactory
{
    public function __construct(private readonly DailyUpdateAnalyticsRequest $request)
    {
    }

    public function makeGenerator(): DailyUpdateReportGenerator // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
    {
        $by = $this->request->query('by');
        if (! is_string($by) || $by === '') {
            $staff = $this->request->user();

            return new IndividualDailyUpdateReportGenerator($staff, $this->request->dateFilterOptions());
        }

        [$type, $id] = explode(':', $by);

        if ($type === 'staff') {
            $staff = Staff::query()->with(['team'])->firstWhere('email', $id);
            if (! $staff instanceof Staff) {
                throw new \RuntimeException('Unknown Staff email.');
            }

            return new IndividualDailyUpdateReportGenerator($staff, $this->request->dateFilterOptions());
        }

        if ($type === 'team') {
            $team = $this->request->team();

            return new TeamDailyUpdateReportGenerator($team, $this->request->dateFilterOptions());
        }

        throw new \BadMethodCallException('Unable to create Generator!');
    }

    public function makePresenter(): DailyUpdatePresenter
    {
        $by = $this->request->query('by');
        if (is_string($by) && str_starts_with($by, 'team:')) {
            return resolve(TeamDailyUpdatePresenter::class);
        }

        return resolve(IndividualDailyUpdatePresenter::class);
    }
}
