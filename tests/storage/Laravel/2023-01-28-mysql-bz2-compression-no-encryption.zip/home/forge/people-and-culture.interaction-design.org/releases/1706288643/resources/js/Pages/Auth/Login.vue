<script setup>
import {Head, useForm} from '@inertiajs/inertia-vue3';
import route from 'ziggy-js';

import GuestLayout from '@/Shared/GuestLayout.vue';

const form = useForm({});
</script>

<template>
  <GuestLayout>
    <Head title="Login" />
    <div class="px-4 py-8 md:flex-1 md:p-12 md:overflow-y-auto">
      <div class="flex items-center justify-center p-6 min-h-screen">
        <div class="w-full max-w-md">
          <form
            class="mt-8 bg-white rounded-lg shadow-xl overflow-hidden"
            @submit.prevent="form.post(route('auth.login'))"
          >
            <div class="flex px-10 py-4 bg-gray-100 border-t border-gray-100">
              <button
                class="px-6 py-3 rounded text-white text-sm leading-4 font-bold whitespace-nowrap bg-brand-01 hover:bg-accent-02 focus:bg-accent-02 mx-auto"
                type="submit"
              >
                Login with IxDF
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </GuestLayout>
</template>
