<script setup lang="ts">
import {Link} from '@inertiajs/inertia-vue3';
import {Inertia} from '@inertiajs/inertia';
import {trans} from 'laravel-vue-i18n';
import route from 'ziggy-js';
import {Staff} from '@/types';

import BaseTable from '@/Components/BaseTable.vue';

defineProps<{
  staff: Staff[];
}>();

const deleteStaff = (id: number) => {
  if (window.confirm(trans('staff.delete'))) {
    Inertia.delete(route('admin.staff.destroy', id));
  }
};
</script>
<template>
  <BaseTable>
    <template #headings>
      <th scope="col" class="th">{{ trans('general.name') }}</th>
      <th scope="col" class="th">{{ trans('general.email') }}</th>
      <th scope="col" class="th">{{ trans('general.team') }}</th>
      <th scope="col" class="th">{{ trans('general.actions') }}</th>
    </template>
    <template #default>
      <tr class="tr" v-for="person in staff" :key="person.id">
        <td class="td">{{ person.name }}</td>
        <td class="td">{{ person.email }}</td>
        <td class="td">{{ person.team_name }}</td>
        <td class="td">
          <Link
            v-if="person.can?.edit"
            :href="route('admin.staff.edit', person)"
            class="link"
          >
            {{ trans('general.edit') }}
          </Link>
          /
          <Link
            v-if="person.can?.delete"
            as="button"
            @click="deleteStaff(person.id)"
            class="link"
            href="#"
          >
            {{ trans('general.delete') }}
          </Link>
        </td>
      </tr>
    </template>
  </BaseTable>
</template>
