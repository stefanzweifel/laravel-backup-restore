<?php declare(strict_types=1);

namespace App\Logging;

use App\Logging\Processor\AuthProcessor;
use App\Logging\Processor\RequestProcessor;
use Illuminate\Http\Request;
use Illuminate\Log\Logger;
use Monolog\Processor\MemoryUsageProcessor;

/**
 * Adds some context info to error logs
 */
final class LogEnhancer
{
    private readonly Request $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * Customize the given logger instance.
     */
    public function __invoke(Logger $logger): void
    {
        /** @var \Monolog\Logger $monolog */
        $monolog = $logger->getLogger();

        /** @var \Monolog\Handler\HandlerWrapper $handler */
        foreach ($monolog->getHandlers() as $handler) {
            // ⚠️ All the processors will be executed in the reverse order.
            $handler->pushProcessor(new MemoryUsageProcessor());
            $handler->pushProcessor(new AuthProcessor());
            $handler->pushProcessor(new RequestProcessor($this->request));
        }
    }
}
