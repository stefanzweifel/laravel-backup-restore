<?php declare(strict_types=1);

namespace App\Exceptions;

use Doctrine\DBAL\Query\QueryException;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Database\Eloquent\RelationNotFoundException;
use Illuminate\Database\MultipleRecordsFoundException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Routing\Exceptions\UrlGenerationException;
use Illuminate\Session\TokenMismatchException;
use Illuminate\Support\Facades\App;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Psr\Container\ContainerExceptionInterface;
use Psr\Log\LogLevel;
use Symfony\Component\HttpKernel\Exception\HttpException;

final class Handler extends ExceptionHandler
{
    /**
     * A list of exception types with their corresponding custom log levels.
     * @var array<class-string<\Throwable>, \Psr\Log\LogLevel::*>
     */
    protected $levels = [
        ContainerExceptionInterface::class => LogLevel::ALERT, // Laravel uses it for BindingResolutionException
        ValidationException::class => LogLevel::INFO, // \Exception child. For Models, we use \App\Exceptions\Logic\ModelValidationFailed
        AuthorizationException::class => LogLevel::WARNING,
        TokenMismatchException::class => LogLevel::ALERT, // CSRF
        ThrottleRequestsException::class => LogLevel::CRITICAL, // \Symfony\Component\HttpKernel\Exception\HttpException child
        HttpException::class => LogLevel::NOTICE, // \RuntimeException child. Possibly should be changed to 'info'
        ModelNotFoundException::class => LogLevel::NOTICE, // \RuntimeException child. Possibly should be changed to 'info'
        MultipleRecordsFoundException::class => LogLevel::CRITICAL, // \RuntimeException child.
        \ErrorException::class => LogLevel::CRITICAL, // \Symfony\Component\Debug\Exception\FatalErrorException parent (\ErrorException child)
        \PDOException::class => LogLevel::CRITICAL, // \RuntimeException child
        QueryException::class => LogLevel::CRITICAL, // \Doctrine\DBAL\DBALException child (\Exception child)
        UrlGenerationException::class => LogLevel::ALERT,
        RelationNotFoundException::class => LogLevel::CRITICAL,
        \BadFunctionCallException::class => LogLevel::ALERT, // LogicException child
        \InvalidArgumentException::class => LogLevel::CRITICAL, // LogicException child
        \LogicException::class => LogLevel::CRITICAL,
        \JsonException::class => LogLevel::CRITICAL,
        \ReflectionException::class => LogLevel::CRITICAL, // \Exception child
        \Error::class => LogLevel::CRITICAL, /** includes {@see \AssertionError} throwing by assert() */
    ];

    /**
     * A list of the exception types that are not reported.
     * @var array<int, class-string<\Throwable>>
     */
    protected $dontReport = [
    ];

    /**
     * A list of the inputs that are never flashed to the session on validation exceptions.
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     * @see https://laravel.com/docs/master/errors#rendering-exceptions
     */
    public function register(): void
    {
        $this->reportable(static function (\Throwable $throwable): void {
        });
    }

    /**
     * phpcs:disable IxDFCodingStandard.NamingConventions.MeaningfulVariableName.NotMeaningfulVariableName
     * @inheritDoc
     * @see https://inertiajs.com/csrf-protection#handling-mismatches
     * @see https://inertiajs.com/error-handling
     * @param \Illuminate\Http\Request $request
     * @param \Throwable $e
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function render($request, \Throwable $e)
    {
        $response = parent::render($request, $e);

        if (
            ! App::environment(['local', 'testing'])
            && in_array($response->getStatusCode(), [500, 503, 404, 403], true)
        ) {
            return Inertia::render('Error', ['status' => $response->getStatusCode()])
                ->with('error', $e->getMessage()) // can be unsafe on public pages
                ->toResponse($request)
                ->setStatusCode($response->getStatusCode());
        }

        // CSRF, {@see https://inertiajs.com/csrf-protection#handling-mismatches}
        if ($response->getStatusCode() === 419) {
            return redirect()->back()->with('error', 'The page expired, please try again.');
        }

        return $response;
    }
}
