<?php declare(strict_types=1);

namespace App\Models\DailyUpdates\Report;

use App\Models\DailyUpdates\DailyUpdate;
use Illuminate\Support\Facades\Auth;

final class DailyUpdateDTO
{
    public readonly bool $submitted;

    private function __construct(
        public readonly int $updateId,
        public readonly string $staffName,
        public readonly string $staffEmail,
        public readonly string $teamName,
        public readonly string $reportingDate,
        public readonly int $feelingToday,
        public readonly string $doneToday,
        public readonly string $plansTomorrow,
        public readonly string $blockedProgress,
        public readonly string $highlights,
        public readonly bool $isFullDay,
        public readonly int $hoursWorked,
        public readonly bool $hasLeave,
        public readonly bool $userCanUpdate = false
    ) {
        $this->submitted = true;
    }

    public static function fromDailyUpdate(DailyUpdate $dailyUpdate): self
    {
        return new self(
            $dailyUpdate->id,
            $dailyUpdate->staff->name,
            $dailyUpdate->staff->email,
            $dailyUpdate->staff->team->name,
            $dailyUpdate->reporting_date->toFormattedDateString(),
            $dailyUpdate->feeling->value,
            $dailyUpdate->done_today,
            $dailyUpdate->plans_tomorrow,
            $dailyUpdate->blocked_progress,
            $dailyUpdate->highlights,
            $dailyUpdate->is_full_day,
            $dailyUpdate->hours_worked,
            $dailyUpdate->has_leave,
            Auth::user() ? Auth::user()->can('update', $dailyUpdate) : false // 💩Infrastructure code in DTO
        );
    }
}
