<?php declare(strict_types=1);

namespace App\Utility\Chart;

/**
 * Represents a data set for a generic chart.
 * @see Chart
 * @see DataPoint
 */
final class DataSet
{
    private string $legend = '';
    private string $color = '';

    /** @var \App\Utility\Chart\DataPoint[] */
    private array $dataPoints = [];

    public function setLegend(string $legend): self
    {
        $this->legend = $legend;

        return $this;
    }

    public function getLegend(): string
    {
        return $this->legend;
    }

    public function setColor(string $color): self
    {
        $this->color = $color;

        return $this;
    }

    public function getColor(): string
    {
        return $this->color;
    }

    public function addDataPoint(DataPoint $dataPoint): self
    {
        $this->dataPoints[] = $dataPoint;

        return $this;
    }

    public function getDataPointsCount(): int
    {
        return count($this->dataPoints);
    }

    public function getDataPoint(int $index): DataPoint
    {
        return $this->dataPoints[$index];
    }

    /** @return \App\Utility\Chart\DataPoint[] */
    public function getDataPoints(): array
    {
        return $this->dataPoints;
    }

    /** @return array{legend: string, data: array<array{value: float|int|null, tooltip: string}>} */
    public function toArray(): array
    {
        return [
            'legend' => $this->legend,
            'data' => array_map(
                static fn (DataPoint $dataPoint): array => $dataPoint->toArray(),
                $this->dataPoints
            ),
        ];
    }
}
