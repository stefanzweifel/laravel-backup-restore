<script setup lang="ts">
import {Head} from '@inertiajs/inertia-vue3';
import {trans} from 'laravel-vue-i18n';

import Layout from '@/Shared/Layout.vue';
import DailyUpdateForm from '@/Components/DailyUpdateForm.vue';

defineProps<{
  previousPlans: string;
  preselectedDate?: string;
}>();
</script>

<template>
  <Layout>
    <Head :title="trans('dailyUpdates.form.createTitle')" />
    <section class="md:w-3/4 mx-auto py-12">
      <h1 class="text-4xl font-bold mb-3">
        {{ trans('dailyUpdates.form.createTitle') }} 🚀
      </h1>
      <a
        href="https://www.interaction-design.org/courses/ixdf-handbook/lessons/daily-updates"
        target="_blank"
        class="link mb-6"
      >
        {{ trans('dailyUpdates.info') }}
      </a>

      <DailyUpdateForm :previous-plans="previousPlans" :submission_date="preselectedDate" />
    </section>
  </Layout>
</template>
