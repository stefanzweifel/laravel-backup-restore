<?php declare(strict_types=1);

return [
    'actions' => 'Actions',
    'delete' => 'Delete',
    'done' => 'Done',
    'edit' => 'Edit',
    'email' => 'Email',
    'filters' => 'Filters',
    'home' => 'Home',
    'logo' => 'Logo',
    'name' => 'Name',
    'no' => 'No',
    'staff' => 'Staff',
    'team' => 'Team',
    'yes' => 'Yes',
];
