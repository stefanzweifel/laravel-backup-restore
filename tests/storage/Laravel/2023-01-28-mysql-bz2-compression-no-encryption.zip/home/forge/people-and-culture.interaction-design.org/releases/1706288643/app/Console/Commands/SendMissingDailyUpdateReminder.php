<?php declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\Staff;
use App\Notifications\MissingDailyUpdateReminder;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder;

/**
 * Notify staff about missing daily updates. On each working day, it is expected
 * that the staff members post a daily update or register a leave.
 */
final class SendMissingDailyUpdateReminder extends Command
{
    /** @var string */
    protected $signature = 'notification:daily-update-reminder';

    /** @var string */
    protected $description = 'Send missing daily update reminder to staff.';

    public const UPDATE_VERIFICATION_DAYS_AGO = 3;

    public function handle(): int
    {
        $reportingDate = now()->subDays(self::UPDATE_VERIFICATION_DAYS_AGO)->startOfDay();

        /**
         * Please note this check is not completely future-proof, some team members may
         * work according to the Islamic calendar, which means their weekend is on Friday and Saturday.
         * @see https://en.wikipedia.org/wiki/Workweek_and_weekend#:~:text=Some%20Muslim%2Dmajority%20countries%20historically,of%20Saudi%20Arabia%20and%20UAE.
         */
        if ($reportingDate->isWeekend()) {
            $this->info('Nothing to do, the reporting date in on the weekend.', 'v');
            return self::SUCCESS;
        }

        Staff::query()
            ->where('should_post_daily_updates', true)
            ->where('created_at', '<', $reportingDate)
            ->whereDoesntHave('dailyUpdates', static fn (Builder $query): Builder => $query->where('reporting_date', $reportingDate))
            ->whereDoesntHave('leaves', static fn (Builder $query): Builder => $query->where('leave_date', $reportingDate))
            ->get()
            ->each(static function (Staff $staff) use ($reportingDate): void {
                $staff->notify(new MissingDailyUpdateReminder($reportingDate));
            });

        return self::SUCCESS;
    }
}
