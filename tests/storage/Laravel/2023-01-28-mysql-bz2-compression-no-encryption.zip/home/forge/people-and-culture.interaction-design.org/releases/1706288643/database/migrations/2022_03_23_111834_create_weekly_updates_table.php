<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('peopleAndCulture__weekly_updates', static function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedBigInteger('team_lead_id')->nullable();
            $table->foreign('team_lead_id')->references('id')->on('peopleAndCulture__staff');
            $table->date('reporting_week_end_date');
            $table->text('progress_last_week')->comment('What were your achieved high/mid level goals in the previous week?');
            $table->text('plans_this_week')->comment('What are your high/mid level goals for the upcoming week?');
            $table->text('potential_problems')->comment('Is there anything putting those goals at risk?');
            $table->text('notes')->comment('Any additional notes?');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('peopleAndCulture__weekly_updates');
    }
};
