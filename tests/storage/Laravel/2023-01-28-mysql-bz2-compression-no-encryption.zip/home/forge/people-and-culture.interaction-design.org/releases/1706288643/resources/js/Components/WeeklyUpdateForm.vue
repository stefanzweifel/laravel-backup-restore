<script setup lang="ts">
import {useForm} from '@inertiajs/inertia-vue3';
import {Link} from '@inertiajs/inertia-vue3';
import route from 'ziggy-js';
import {trans} from 'laravel-vue-i18n';

import BaseButton from '@/Components/BaseButton.vue';
import FormDatepicker from '@/Components/Form/FormDatepicker.vue';
import FormTextArea from '@/Components/Form/FormTextArea.vue';

const form = useForm<{
  reporting_week_end_date: Date;
  update: string;
  plans: string;
  blockers: string;
  notes: string;
}>({
  reporting_week_end_date: new Date(),
  update: '',
  plans: '',
  blockers: '',
  notes: '',
});

const formSubmit = () => {
  form
    .transform((data) => ({
      ...data,
      reporting_week_end_date: form.reporting_week_end_date,
    }))
    .post(route('peopleAndCulture.weeklyUpdates.store'));
};
</script>

<template>
  <form @submit.prevent="formSubmit" novalidate>
    <FormDatepicker
      v-model="form.reporting_week_end_date"
      :label="trans('weeklyUpdates.form.date.label')"
      id="date"
      required
      :error="form.errors.reporting_week_end_date"
      :help-text="trans('weeklyUpdates.form.date.helpText')"
    />
    <div class="mt-4">
      <FormTextArea
        id="update"
        :label="trans('weeklyUpdates.form.update.label')"
        v-model="form.update"
        required
        rows="3"
        :placeholder="trans('weeklyUpdates.form.update.placeholder')"
        :error="form.errors.update"
      />
    </div>
    <div class="mt-4">
      <FormTextArea
        id="plans"
        :label="trans('weeklyUpdates.form.plans.label')"
        :placeholder="trans('weeklyUpdates.form.plans.placeholder')"
        v-model="form.plans"
        required
        rows="3"
        :error="form.errors.plans"
      />
    </div>
    <div class="mt-4">
      <FormTextArea
        id="blockers"
        :label="trans('weeklyUpdates.form.blockers.label')"
        v-model="form.blockers"
        :placeholder="trans('weeklyUpdates.form.blockers.placeholder')"
        rows="3"
        :error="form.errors.blockers"
      />
    </div>
    <div class="mt-4">
      <FormTextArea
        id="notes"
        :label="trans('weeklyUpdates.form.notes.label')"
        v-model="form.notes"
        :placeholder="trans('weeklyUpdates.form.notes.placeholder')"
        rows="3"
        :error="form.errors.notes"
      />
    </div>
    <BaseButton type="submit" class="mt-4" :disabled="form.processing">
      {{ trans('form.submit') }}
    </BaseButton>
    <Link
      class="font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 bg-white focus:ring-4 border-2 border-gray-500"
      :href="route('peopleAndCulture.weeklyUpdates.index')"
    >
      {{ trans('form.cancel') }}
    </Link>
  </form>
</template>
