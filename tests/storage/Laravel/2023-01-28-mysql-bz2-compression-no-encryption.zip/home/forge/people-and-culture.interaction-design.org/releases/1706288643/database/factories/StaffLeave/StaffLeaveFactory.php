<?php declare(strict_types=1);

namespace Database\Factories\StaffLeave;

use App\Models\StaffLeave\Leave;
use App\Services\StaffLeave\LeavePeriod;
use Carbon\CarbonInterface;
use Database\Factories\StaffFactory;

/** @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\StaffLeave\Leave> */
final class StaffLeaveFactory extends \Illuminate\Database\Eloquent\Factories\Factory
{
    /** @var class-string<\App\Models\StaffLeave\Leave> */
    protected $model = Leave::class;

    /** @inheritDoc */
    public function definition(): array
    {
        return [
            'staff_id' => StaffFactory::new(),
            'calendar_event_uid' => sprintf('UID-%s', uniqid()),
            'leave_date' => $this->faker->date,
            'leave_period' => $this->faker->randomElement(LeavePeriod::cases()),
        ];
    }

    public function onDate(CarbonInterface $date): self
    {
        return $this->state([
            'leave_date' => $date,
        ]);
    }
}
