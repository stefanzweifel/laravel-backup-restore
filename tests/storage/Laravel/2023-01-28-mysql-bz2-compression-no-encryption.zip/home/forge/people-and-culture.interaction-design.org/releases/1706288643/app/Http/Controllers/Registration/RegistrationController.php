<?php declare(strict_types=1);

namespace App\Http\Controllers\Registration;

use App\Actions\CreateStaff;
use App\Models\Staff;
use App\Services\Spock\SlackToSpockIdTranslator;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

final class RegistrationController
{
    public function __invoke(
        Request $request,
        CreateStaff $createStaff,
        SlackToSpockIdTranslator $slackToSpockId
    ): RedirectResponse {
        /** @var array{avatar: string, first_name: string, email: string, team_id: int, slack_user_id: string} $validatedStaffData */
        $validatedStaffData = $request->validate([
            'avatar' => ['required', 'string'],
            'first_name' => ['required', 'string', 'min:2', 'max:255'],
            'email' => ['bail', 'required', 'email', Rule::unique(Staff::class, 'email')],
            'team_id' => ['required', 'int'],
            'slack_user_id' => ['bail', 'required', 'alpha_num', 'regex:/^U[A-Z0-9]+$/'],
        ]);

        $validatedStaffData['spock_user_id'] = $slackToSpockId->translate($request->string('slack_user_id')->toString());

        $createStaff->execute($validatedStaffData);

        return redirect()
            ->to(route('auth.login'))
            ->with('success', 'Your profile has been created. Now it’s time for your first login 🙂');
    }
}
