<?php declare(strict_types=1);

namespace App\Http\Controllers\WeeklyUpdates;

use App\Http\Requests\WeeklyUpdates\PostWeeklyUpdatesRequest;
use App\Models\WeeklyUpdates\WeeklyUpdate;
use App\Models\WeeklyUpdates\WeeklyUpdateDTO;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Collection;
use Inertia\Inertia;
use Inertia\Response;

final class WeeklyUpdateController
{
    public function index(): Response
    {
        $reports = WeeklyUpdate::query()
            ->with('teamLead')
            ->orderByDesc('reporting_week_end_date')
            ->get()
            ->groupBy(static fn (WeeklyUpdate $update) => $update->reporting_week_end_date)
            ->map(static fn (Collection $updates): Collection => $updates
                ->mapWithKeys(static fn (WeeklyUpdate $update): array => [$update->team_lead_id => WeeklyUpdateDTO::fromWeeklyUpdate($update)]));

        return Inertia::render('WeeklyUpdates/Index', [
            'reports' => static fn () => $reports,
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('WeeklyUpdates/Create');
    }

    public function store(PostWeeklyUpdatesRequest $request): RedirectResponse
    {
        if ($request->user()->cannot('create', WeeklyUpdate::class)) {
            return redirect()->back()->with('error', 'Unauthorized!');
        }

        $request->user()->createWeeklyUpdate($request->validated());

        return redirect()->route('peopleAndCulture.weeklyUpdates.index')
            ->with('success', 'Thanks for posting your weekly update 💛💙❤️🤍❤️💚🧡💜');
    }
}
