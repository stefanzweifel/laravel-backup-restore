<?php declare(strict_types=1);

namespace Deployer;

use Deployer\Utility\Httpie;

require 'recipe/laravel.php'; /** phpcs:disable PSR1.Files.SideEffects */

/**
 * We should close repo deep enough to get info about the latest available tag.
 * It’s hacky solution, but if you know better – please update the related code.
 * @psalm-internal
 */
define('GIT_CLONE_DEPTH_ENOUGH_FOR_TAGS', 300);

/**
 * @see https://deployer.org/docs
 *
 * How to start deployment examples:
 * ./deployer.phar deploy production
 * ⚠️ 'deploy' task will ship your CURRENT git branch
 *
 * Rollback latest deployment:
 * ./deployer.phar rollback production
 *
 * Run a single (any) task on a host:
 * ./deployer.phar {taskname} [{hostname}='localhost']
 * Examples:
 *  ./deployer.phar hello
 *  ./deployer.phar hello production
 *  ./deployer.phar artisan:queue:restart production
 *  ./deployer.phar laravel:config-changed production
 */

// Project name
set('application', 'People-and-Culture');

// Project repository
set('repository', 'git@github.com:InteractionDesignFoundation/people-and-culture.git');

// Number of releases to keep
set('keep_releases', 2);

// No need to use sudo to make writable directories
set('writable_use_sudo', false);
set('http_user', 'forge');

set('default_timeout', 1000);
set('ssh_multiplexing', true);

set('allow_anonymous_stats', false);
set('use_relative_symlink', false);

set('release_name', static fn () => run('date +"%s"')); // name of folder in releases

set('deploy_path', '~/{{hostname}}'); // name of folder in releases
set('php_fpm_version', '8.2'); // used to detect which PHP version to restart on deployments

set('composer_options', '--verbose --prefer-dist --no-progress --no-interaction --no-dev --optimize-autoloader');

task('hello', static function () {
    writeln('Hello world! This this is a simple deployer task for demo purposes');
})->desc('Test task, great to check a host connection');

// Hosts

// Run task(s) on localhost (default target if host is not specified)
localhost()
    ->set('fe_install_options', '--no-progress --pure-lockfile')
    ->set('composer_options', '--no-interaction --prefer-dist --no-progress');

host('production')
    ->setHostname('people-and-culture.interaction-design.org')
    ->setRemoteUser('forge')
    ->set('keep_releases', 3);
// Tasks

task('deploy:fe:install', static function () {
    $options = get('fe_install_options', '--pure-lockfile');
    run("cd {{release_path}} && yarn install $options");
})->desc('Install frontend packages');

task('deploy:fe:build', static function () {
    run('cd {{release_path}} && yarn run build');
})->desc('Build frontend');

task('artisan:app:set-revision', static function () {
    cd('{{release_or_current_path}}');

    $git = get('bin/git');
    $gitTag = run("$git describe --tags --always");

    $isOnCI = (bool) getenv('CI');
    $gitBranch = match (true) {
        get('branch') => get('branch'),
        $isOnCI => getenv('GITHUB_REF_NAME'), // @see https://docs.github.com/en/actions/learn-github-actions/environment-variables
        default => runLocally("$git branch --show-current") // git branch --show-current available from git v.2.22
            ?? runLocally("$git branch | grep \* | cut -d ' ' -f2"),
    };

    run("{{bin/php}} artisan app:set-revision $gitTag '$gitBranch'");
})->desc('Set a new application revision/version');

task('artisan:release:notify', static function () {
    run('{{bin/php}} {{release_path}}/artisan release:notify -q');
})->desc('Notify developers about a recent deployment to any site');

desc('Notifying Slack');
task('slack:notify', static function () {
    $webhookToken = 'https://hooks.slack.com/services/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'; // config('ixdf_slack.webhook.url')
    $body = [
        'channel' => get('slack_channel', '#dev'),
        'attachments' => [
            [
                'title' => get('slack_title', 'undefined title'),
                'text' => get('slack_text', 'undefined text'),
                'color' => get('slack_color', '#4d91f7'),
            ],
        ],
    ];

    Httpie::post($webhookToken)->formBody($body)->send();
})
    ->hidden();

task('slack:notify:rollback', static function () {
    if (get('stage') !== 'production') {
        return;
    }

    set('slack_channel', '#releases');
    set('slack_title', 'Release rollback -- PeopleAndCulture');
    set('slack_text', 'We have rolled back the latest the release due to issues we found. We’ll fix them and ship a new release with fixes.');
    set('slack_color', '#ff0909');
    invoke('slack:notify');
})->desc('Notify team in slack about release rollback');

/** @phpcs:disable SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh */
task('deploy:update_code', static function () {
    $repository = trim(get('repository'));
    $git = get('bin/git');

    $branchNameParameter = get('branch');
    /** Get the name of the local branch */
    $branchNameLocal = runLocally("$git branch --show-current") ?? runLocally("$git branch | grep \* | cut -d ' ' -f2");
    /** "HEAD" as branch parameter means we want to deploy the local branch */
    $branch = $branchNameParameter === 'HEAD' ? $branchNameLocal : $branchNameParameter;
    $gitCache = get('git_cache');
    $recursive = get('git_recursive', true) ? '--recursive' : '';
    $dissociate = get('git_clone_dissociate', true) ? '--dissociate' : '';
    $quiet = \Deployer\output()->isQuiet() ? '-q' : '';
    $depth = $gitCache ? '' : '--depth '.\GIT_CLONE_DEPTH_ENOUGH_FOR_TAGS;

    $at = '';

    if (!empty($branch)) {
        $at = "-b \"$branch\"";
    }

    // If option `tag` is set
    if (input()->hasOption('tag')) {
        $tag = input()->getOption('tag');
        if (!empty($tag)) {
            $at = "-b \"$tag\"";
        }
    }

    // If option `tag` is not set and option `revision` is set
    if (empty($tag) && input()->hasOption('revision')) {
        $revision = input()->getOption('revision');
        if (!empty($revision)) {
            $depth = '';
        }
    }

    // Enter deploy_path if present
    if (has('deploy_path')) {
        cd('{{deploy_path}}');
    }

    // Populate known hosts
    preg_match('/.*(@|\/\/)([^\/:]+).*/', $repository, $match);
    if (isset($match[2])) {
        $repositoryHostname = $match[2];
        try {
            run("ssh-keygen -F $repositoryHostname");
        } catch (\Deployer\Exception\RunException) {
            run("ssh-keyscan -H $repositoryHostname >> ~/.ssh/known_hosts");
        }
    }

    if ($gitCache && has('previous_release')) {
        try {
            run("$git clone $at $recursive $quiet --reference {{previous_release}} $dissociate $repository  {{release_path}} 2>&1");
        } catch (\Throwable) {
            // If {{deploy_path}}/releases/{$releases[1]} has a failed git clone, is empty, shallow etc, git would throw error and give up. So we're forcing it to act without reference in this situation
            run("$git clone $at $recursive $quiet $repository {{release_path}} 2>&1");
        }
    } else {
        // if we're using git cache this would be identical to above code in catch - full clone. If not, it would create shallow clone.
        run("$git clone $at $depth $recursive $quiet $repository {{release_path}} 2>&1");
    }

    if (!empty($revision)) {
        run("cd {{release_path}} && $git checkout $revision");
    }
})->desc('Update code with depth enough to fetch git tags');

task('laravel:config-changed', [
    'artisan:config:cache',
    'artisan:queue:restart',
    'php-fpm:reload',
])->desc('Restart all required processes to be sure that all of them use new config');

task('php-fpm:reload', static function () {
    /**
     * @see https://stackoverflow.com/a/64856322/4343530
     * After reload is executed, PHP-FPM will wait until all requests are processed but not longer than process_control_timeout.
     * If it reaches process_control_timeout, a 502 error will occur.
     * Current process_control_timeout = 2s
     * @see infrastructure/php/fpm/php-fpm.conf
     * ⚠️ PHP-CLI processes will not be interrupted by this task.
     */
    $phpFpmVersionAsConfigPathPart = get('php_fpm_version');
    run("sudo /usr/sbin/service php{$phpFpmVersionAsConfigPathPart}-fpm reload");
})->desc('Reload PHP-FPM to reset OPcache.');

/** @see https://selivan.github.io/2016/10/25/php-fpm-502-error-on-reload.html */
task('services:restart', static function () {
    // BE AWARE: removing the restart will not reset opcache.
    // If you want to reload, address the opcache reset as well.

    // Here we assume that we use the same PHP version for CLI and FPM
    $phpFpmVersionAsConfigPathPart = get('php_fpm_version');
    run("sudo /usr/sbin/service php{$phpFpmVersionAsConfigPathPart}-fpm reload");
    run('sudo /usr/sbin/service nginx restart');
    run('sudo /usr/sbin/service supervisor restart');
})->desc('Restart services: PHP FPM and nginx');

// Main task
task('deploy', [
    'deploy:prepare', // includes ('deploy:info', 'deploy:setup', 'deploy:lock', 'deploy:release', 'deploy:update_code',  'deploy:shared', 'deploy:writable')
    'deploy:vendors', // Composer install
    'artisan:storage:link', // Create a symbolic link from "public/storage" to "storage/app/public"
    'artisan:app:set-revision',
    'deploy:fe:install', // yarn/npm
    'deploy:fe:build', // (re)build frontend assets, should be after "set-revision" as it uses app version
    'artisan:cache:clear', // Flush only DB for a connection, specified in cache.[redis|memcached|etc].connection
    'artisan:config:cache',
    'artisan:route:cache',
    'artisan:view:cache',
    'artisan:event:cache',
    'artisan:migrate',
    'deploy:symlink', // 🚀 Switch the current symlink to release_path
    'php-fpm:reload', // stop serving previous app instances
    'deploy:unlock', // Allow further deployments
    'artisan:queue:restart', // Restart queue worker daemons after their current job
    'deploy:cleanup', // Clean up old releases using the keep_releases option
    'deploy:success', // Prints a success message
])->desc('Deploy project');

after('deploy', 'artisan:release:notify');

// ⚠️️ "rollback" removes the latest release directory
before('rollback', 'artisan:down');
after('rollback', 'php-fpm:reload');
after('rollback', 'artisan:app:set-revision');
after('rollback', 'artisan:queue:restart'); // Restart queue worker daemons after their current job
after('rollback', 'artisan:up');
after('rollback', 'deploy:unlock');
after('rollback', 'slack:notify:rollback');

// [Optional] if deploy fails automatically unlock.
after('deploy:failed', 'deploy:unlock');
