<?php declare(strict_types=1);

namespace Tests\Unit\Services\DailyUpdates;

use App\Http\Controllers\DailyUpdates\Presenters\IndividualDailyUpdatePresenter;
use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Report\DailyUpdateDTO;
use App\Models\DailyUpdates\Report\IndividualReport;
use App\Models\DailyUpdates\Report\NullUpdateDTO;
use App\Models\Staff;
use App\Models\StaffLeave\Leave;
use App\Models\StaffLeave\Report\LeaveDTO;
use Carbon\CarbonInterface;
use Carbon\CarbonPeriod;
use Database\Factories\StaffFactory;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

final class IndividualReportBuilder
{
    /** @var array<string, array{updates: int, leaves: int, days: int}> */
    private array $weeklyStats;

    private Staff $staff;

    /** @var array<\App\Models\DailyUpdates\DailyUpdate> */
    private array $dailyUpdates;

    /** @var array<\App\Models\StaffLeave\Leave> */
    private array $leaves;

    private ?CarbonInterface $updatedAt;

    /** @var array<string, array{updates: int, leaves: int, days: int}> */
    private array $monthlyStats;
    private int $workingDays;
    private int $fullDayReports;
    private int $halfDayReports;
    private int $fullDayHolidays;
    private int $halfDayHolidays;

    private function __construct(private readonly CarbonInterface $from, private readonly CarbonInterface $to)
    {
        $this->staff = StaffFactory::new()->createOne();
        $this->dailyUpdates = [];
        $this->leaves = [];
        $this->weeklyStats = [];
        $this->monthlyStats = [];
        $this->fullDayReports = 0;
        $this->halfDayReports = 0;
        $this->fullDayHolidays = 0;
        $this->halfDayHolidays = 0;
        $this->updatedAt = null;
    }

    public static function of(CarbonInterface $from, CarbonInterface $to): self
    {
        return new self($from->clone(), $to->clone());
    }

    public function withWeeklyStat(int $week, int $days = 5, int $year = 2022, int $updates = 1, int $leaves = 0): self
    {
        $this->weeklyStats["Week {$week} of {$year}"] = ['updates' => $updates, 'days' => $days, 'leaves' => $leaves];

        return $this;
    }

    public function withWeeklyStatsWithZeroUpdates(int $fromWeek, int $numberOfWeeks = 4, int $year = 2022): self
    {
        for ($i = 0; $i < $numberOfWeeks; $i++) {
            $this->withWeeklyStat($fromWeek + $i, year: $year, updates: 0);
        }

        return $this;
    }

    public function withStaff(Staff $staff): self
    {
        $this->staff = $staff;

        return $this;
    }

    public function withMonthlyStat(string $month, int $updates = 0, int $days = 21, int $leaves = 0): self
    {
        $this->monthlyStats[$month] = ['updates' => $updates, 'days' => $days, 'leaves' => $leaves];

        return $this;
    }

    /** @param array<\App\Models\DailyUpdates\DailyUpdate> $dailyUpdates */
    public function withUpdates(array $dailyUpdates): self
    {
        $this->dailyUpdates = $dailyUpdates;
        $this->updatedAt = Arr::last($dailyUpdates)?->created_at;

        return $this;
    }

    public function withLastUpdatedAt(CarbonInterface $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function withWorkingDays(int $workingDays = 21): self
    {
        $this->workingDays = $workingDays;

        return $this;
    }

    public function withReportStats(
        int $fullDayReports = 0,
        int $halfDayReports = 0,
        int $fullDayHolidays = 0,
        int $halfDayHolidays = 0
    ): self {
        $this->fullDayReports = $fullDayReports;
        $this->halfDayReports = $halfDayReports;
        $this->fullDayHolidays = $fullDayHolidays;
        $this->halfDayHolidays = $halfDayHolidays;

        return $this;
    }

    public function build(): IndividualReport
    {
        return new IndividualReport(
            $this->staff->name,
            $this->staff->team->name,
            $this->workingDays,
            $this->updatedAt,
            $this->updatesWithDefaults(),
            $this->leaveDTOs(),
            $this->weeklyStats,
            $this->monthlyStats,
            $this->fullDayReports,
            $this->halfDayReports,
            $this->fullDayHolidays,
            $this->halfDayHolidays
        );
    }

    /** @return array<string, array<string, (\App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO)>> */
    public function updatesWithDefaults(): array
    {
        $updates = collect($this->dailyUpdates)
            ->sortByDesc('reporting_date')
            ->values()
            ->groupBy(static fn (DailyUpdate $dailyUpdate): int => $dailyUpdate->reporting_date->startOfDay()->getTimestamp())
            ->map(static fn (Collection $updates): Collection => $updates
                ->mapWithKeys(static fn (DailyUpdate $dailyUpdate): array => [$dailyUpdate->staff->id => DailyUpdateDTO::fromDailyUpdate($dailyUpdate)]));

        $period = collect(CarbonPeriod::create($this->from, $this->to->min(now()))->toArray())->reverse();

        $default = $period->mapWithKeys(fn (Carbon $date): array => [
            $date->format(IndividualDailyUpdatePresenter::REPORT_DATETIME_FORMAT) => Collection::wrap(
                Arr::has($updates, $date->getTimestamp().'.'.$this->staff->id)
                    ? Arr::get($updates, $date->getTimestamp().'.'.$this->staff->id)
                    : NullUpdateDTO::create($this->staff, $date)
            )->keyBy('staff_email'),
        ]);

        return $default->all();
    }

    /** @return array<\App\Models\StaffLeave\Report\LeaveDTO> */
    private function leaveDTOs(): array
    {
        return collect($this->leaves)
            ->map(fn (Leave $leave) => LeaveDTO::createFromModel($leave, $this->staff->email))
            ->all();
    }
}
