<?php declare(strict_types=1);

namespace App\Models\Logging;

/** @mixin \App\Models\Staff */
trait InteractsWithLogging
{
    public function getName(): string
    {
        return $this->name;
    }

    public function getEmailAddress(): string
    {
        return $this->email;
    }
}
