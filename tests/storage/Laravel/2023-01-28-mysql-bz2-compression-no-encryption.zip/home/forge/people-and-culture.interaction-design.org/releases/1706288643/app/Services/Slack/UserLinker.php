<?php declare(strict_types=1);

namespace App\Services\Slack;

final class UserLinker
{
    /**
     * @param string $text Text probably contains @mention syntax that will be replaced to "<U123>"-like strings.
     * @param array<string, string> $namesToSlackIds
     */
    public function linkNames(string $text, array $namesToSlackIds): string
    {
        if (! str_contains($text, '@')) { // optimisation
            return $text;
        }

        preg_match_all('/(@\w+)/', $text, $matches);

        /** @var list<string> $foundNames */
        $foundNames = $matches[0];

        foreach ($foundNames as $atName) {
            $probablyNameWithoutAt = str_replace('@', '', $atName);
            $slackUserId = $namesToSlackIds[$probablyNameWithoutAt] ?? null;
            if (is_string($slackUserId)) {
                $text = str_replace($atName, "<@$slackUserId>", $text);
            }
        }

        return $text;
    }
}
