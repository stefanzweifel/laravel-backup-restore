<script setup lang="ts">
import {useForm} from '@inertiajs/inertia-vue3';
import {trans} from 'laravel-vue-i18n';
import route from 'ziggy-js';

import {Filters} from '@/types';

const props = defineProps<{
  filters: Filters;
}>();

const form = useForm<{
  range: string;
  by: string;
}>({
  range: props.filters.range,
  by: props.filters.by,
});

function filter() {
  form.get(route('peopleAndCulture.dailyUpdates.index'));
}
</script>

<template>
  <h2 class="text-3xl font-bold mb-2">{{ trans('general.filters') }}</h2>

  <form
    name="daily_update_filter"
    method="GET"
    @submit.prevent="filter"
    data-filters
    class="grid grid-cols-1 md:grid-cols-3 gap-4"
  >
    <div class="md:mr-3">
      <label for="dateRange">Date range</label>
      <select id="dateRange" class="select" v-model="form.range" name="range" @change="filter">
        <option :value="null" hidden>Select Date range…</option>
        <optgroup label="Days">
          <option
            v-for="(dates, dayNumber) in filters.rangeOptions.days"
            :value="dates"
            :key="dates"
          >
            {{ dayNumber }}
          </option>
        </optgroup>
        <optgroup label="Weeks">
          <option
            v-for="(dates, weekNumber) in filters.rangeOptions.weeks"
            :value="dates"
            :key="dates"
          >
            {{ weekNumber }}
          </option>
        </optgroup>
        <optgroup label="Months">
          <option
            v-for="(dates, month) in filters.rangeOptions.months"
            :value="dates"
            :key="dates"
          >
            {{ month }}
          </option>
        </optgroup>
      </select>
    </div>

    <div class="md:mr-3">
      <label for="by">Group by</label>
      <select
        id="by"
        class="select"
        name="by"
        v-model="form.by"
        @change="filter"
      >
        <option :value="null" disabled>Select Team or Staff…</option>
        <template v-for="team in filters.teams">
          <hr>
          <option :value="`team:${team.slug}`">{{ team.name }} team</option>

          <option
            v-for="(memberName, memberEmail) in team.members"
            :value="`staff:${memberEmail}`"
            :key="memberEmail"
          >
            - {{ memberName }}
          </option>
        </template>

      </select>
    </div>
  </form>
</template>
