<?php declare(strict_types=1);

namespace App\Notifications;

use Illuminate\Notifications\AnonymousNotifiable;
use Illuminate\Notifications\Notifiable;

final class ReleaseNotifiable extends AnonymousNotifiable
{
    use Notifiable;

    public function routeNotificationForSlack(): string
    {
        return (string) config('release.slack.webhook');
    }
}
