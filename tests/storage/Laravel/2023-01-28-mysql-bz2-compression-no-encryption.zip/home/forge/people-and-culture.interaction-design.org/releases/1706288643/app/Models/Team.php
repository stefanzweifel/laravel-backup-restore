<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property int $id
 * @property string $slug
 * @property string $name
 * @property string $symbol
 * @property string|null $channel_for_updates
 * @property int|null $last_updated_by_id
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Staff> $members
 */
final class Team extends Model
{
    use SoftDeletes;

    /** @var string */
    protected $table = 'peopleAndCulture__team';

    /** @var array<string, scalar|null> */
    protected $attributes = [
        'symbol' => ':rooster:',
    ];

    public function members(): HasMany
    {
        return $this->hasMany(Staff::class);
    }
}
