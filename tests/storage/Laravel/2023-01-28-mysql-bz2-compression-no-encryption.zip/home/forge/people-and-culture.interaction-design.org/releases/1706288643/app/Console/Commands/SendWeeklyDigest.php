<?php declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\Team;
use App\Notifications\WeeklyDigest;
use App\Services\Slack\IxDFSlackApiWorkspace;
use App\ValueObjects\DatetimeRange;
use Illuminate\Console\Command;

final class SendWeeklyDigest extends Command
{
    /** @var string */
    protected $signature = 'weekly-digest:send';

    /** @var string */
    protected $description = 'Send a weekly digest notification about daily updates and registered leaves.';

    public function handle(IxDFSlackApiWorkspace $slackWorkspace): int
    {
        /** @var \Illuminate\Database\Eloquent\Collection<int, \App\Models\Team> $teams */
        $teams = Team::query()
            ->whereHas('members')
            ->with(['members'])
            ->get();

        $weekDateRange = new DatetimeRange(today()->subWeek()->startOfWeek(), today()->subWeek()->endOfWeek());

        $slackWorkspace->setDefaultChannel((string) config('ixdf_slack.channel_for_all_updates'))
            ->notify(new WeeklyDigest($weekDateRange, $teams));

        $slackWorkspace->setDefaultChannel((string) config('ixdf_slack.channel_for_team_leads'))
            ->notify(new WeeklyDigest($weekDateRange, $teams));

        return self::SUCCESS;
    }
}
