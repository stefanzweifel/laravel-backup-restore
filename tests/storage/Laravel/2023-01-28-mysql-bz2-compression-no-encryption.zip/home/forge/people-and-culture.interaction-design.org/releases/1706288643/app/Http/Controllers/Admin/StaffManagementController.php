<?php declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Models\Staff;
use App\Models\Team;
use App\Services\Spock\SlackToSpockIdTranslator;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

final class StaffManagementController
{
    public function index(Request $request): Response
    {
        $staff = Staff::query()
            ->with('team')
            ->select(['id', 'name', 'email', 'team_id', 'slack_user_id'])
            ->orderBy('name')
            ->get();

        return Inertia::render('Admin/Staff/Index', [
            'staff' => $staff
                ->toBase()
                ->map(static fn (Staff $staff) => [
                    'id' => $staff->id,
                    'name' => $staff->name,
                    'email' => $staff->email,
                    'team_id' => $staff->team_id,
                    'team_name' => $staff->team->name,
                    'slack_user_id' => $staff->slack_user_id,
                    'can' => [
                        'edit' => $request->user()->can('update', $staff),
                        'delete' => $request->user()->can('delete', $staff),
                    ],
                ]),
        ]);
    }

    public function create(): Response
    {
        $teams = Team::query()->get()->pluck('name', 'id');

        return Inertia::render('Admin/Staff/Create', [
            'teams' => $teams,
        ]);
    }

    public function store(Request $request, SlackToSpockIdTranslator $slackToSpockId): RedirectResponse
    {
        if ($request->user()->cannot('create', Staff::class)) {
            return redirect()->back()->with('error', 'Unauthorized!');
        }

        $request->validate([
            'name' => ['required'],
            'email' => ['required', 'email', Rule::unique(Staff::class, 'email')],
            'team' => ['required', Rule::exists(Team::class, 'id')],
            'slack_user_id' => ['bail', 'required', 'alpha_num', 'regex:/^U[A-Z0-9]+$/'],
        ]);

        $slackUserId = $request->string('slack_user_id')->toString();

        $staff = new Staff();
        $staff->name = $request->string('name')->toString();
        $staff->email = $request->string('email')->toString();
        $staff->team_id = $request->integer('team');
        $staff->slack_user_id = $slackUserId;
        $staff->spock_user_id = $slackToSpockId->translate($slackUserId);

        $staff->save();

        return redirect()->route('admin.staff.index')->with('success', "User account for $staff->name created successfully");
    }

    public function edit(Staff $staff): Response
    {
        $teams = Team::query()->orderBy('name')->pluck('name', 'id');

        return Inertia::render('Admin/Staff/Edit', [
            'staff' => [
                'id' => $staff->id,
                'name' => $staff->name,
                'email' => $staff->email,
                'team_id' => $staff->team_id,
                'team_name' => $staff->team->name,
                'slack_user_id' => $staff->slack_user_id,
                'spock_user_id' => $staff->spock_user_id,
            ],
            'teams' => $teams,
        ]);
    }

    public function update(Staff $staff, Request $request, SlackToSpockIdTranslator $slackToSpockId): RedirectResponse
    {
        if ($request->user()->cannot('update', $staff)) {
            return redirect()->back()->with('error', 'Unauthorized!');
        }

        $input = $request->validate([
            'name' => ['required'],
            'email' => ['required', 'email', Rule::unique(Staff::class, 'email')->ignore($staff->id)],
            'team' => ['required', Rule::exists(Team::class, 'id')],
            'slack_user_id' => ['bail', 'required', 'alpha_num', 'regex:/^U[A-Z0-9]+$/'],
        ]);

        $staff->name = $input['name'];
        $staff->email = $input['email'];
        $staff->team_id = $input['team'];

        if ($staff->slack_user_id !== $input['slack_user_id']) {
            $staff->slack_user_id = $input['slack_user_id'];
            $staff->spock_user_id = $slackToSpockId->translate((string) $input['slack_user_id']);
        }

        $staff->save();

        return redirect()->route('admin.staff.index')->with('success', "User account for $staff->name updated successfully");
    }

    public function destroy(Staff $staff, Request $request): RedirectResponse
    {
        if ($request->user()->cannot('delete', $staff)) {
            return redirect()->back()->with('error', 'Unauthorized!');
        }

        $staff->delete();

        return redirect()->route('admin.staff.index', [], 303)->with('success', "User account for $staff->name deleted successfully.");
    }
}
