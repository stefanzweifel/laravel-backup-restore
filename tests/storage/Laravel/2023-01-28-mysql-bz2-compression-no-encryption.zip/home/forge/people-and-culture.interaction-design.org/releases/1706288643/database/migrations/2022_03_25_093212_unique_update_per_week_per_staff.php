<?php declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('peopleAndCulture__weekly_updates', static function (Blueprint $table) {
            $table->unique(['team_lead_id', 'reporting_week_end_date'], 'unique_weekly_update_per_staff_per_week');
        });
    }
};
