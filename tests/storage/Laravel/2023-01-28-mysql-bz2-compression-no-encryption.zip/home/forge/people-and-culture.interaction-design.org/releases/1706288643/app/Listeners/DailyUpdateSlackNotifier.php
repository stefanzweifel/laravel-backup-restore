<?php declare(strict_types=1);

namespace App\Listeners;

use App\Events\DailyUpdateSubmitted;
use App\Models\DailyUpdates\DailyUpdate;
use App\Notifications\DailyUpdateSubmittedNotification;
use App\Services\Slack\IxDFSlackWebhookWorkspace;
use App\Services\Slack\UserLinker;

final readonly class DailyUpdateSlackNotifier
{
    public function __construct(private IxDFSlackWebhookWorkspace $slackWorkspace, private UserLinker $userLinker)
    {
    }

    public function handle(DailyUpdateSubmitted $event): void
    {
        $dailyUpdate = $event->dailyUpdate;

        if ($this->shouldPostUpdateOnTeamChannel($dailyUpdate)) {
            $this->slackWorkspace->setDefaultChannel($this->getTeamNotificationChannel($dailyUpdate))
                ->notify(new DailyUpdateSubmittedNotification($dailyUpdate, $this->userLinker));
        }

        $this->slackWorkspace->setDefaultChannel((string) config('ixdf_slack.channel_for_all_updates'))
            ->notify(new DailyUpdateSubmittedNotification($dailyUpdate, $this->userLinker));
    }

    private function getTeamNotificationChannel(DailyUpdate $dailyUpdate): string
    {
        $channel = $dailyUpdate->staff->team->channel_for_updates;
        assert(is_string($channel));

        return $channel;
    }

    private function shouldPostUpdateOnTeamChannel(DailyUpdate $dailyUpdate): bool
    {
        return $dailyUpdate->staff->team->channel_for_updates !== null;
    }
}
