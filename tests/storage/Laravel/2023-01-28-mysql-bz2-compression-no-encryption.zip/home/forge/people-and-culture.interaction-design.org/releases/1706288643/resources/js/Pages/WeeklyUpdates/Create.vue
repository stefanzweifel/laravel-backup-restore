<script setup lang="ts">
import {Head} from '@inertiajs/inertia-vue3';
import {getWeekNumberFromDate} from '@/vanilla/date';
import {trans} from 'laravel-vue-i18n';

import Layout from '@/Shared/Layout.vue';
import WeeklyUpdateForm from '@/Components/WeeklyUpdateForm.vue';
</script>

<template>
  <Layout>
    <Head :title="trans('weeklyUpdates.form.createTitle')" />
    <section class="md:w-3/4 mx-auto py-12">
      <h1 class="text-4xl font-bold mb-3">
        {{
          trans('weeklyUpdates.form.createTitle', {
            year: new Date().getFullYear().toString(),
            week: getWeekNumberFromDate(new Date()).toString(),
          })
        }}
      </h1>
      <WeeklyUpdateForm />
    </section>
  </Layout>
</template>
