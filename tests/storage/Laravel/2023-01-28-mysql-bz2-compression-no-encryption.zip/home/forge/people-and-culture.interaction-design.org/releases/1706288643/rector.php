<?php declare(strict_types=1);

use Rector\CodeQuality\Rector\Array_\CallableThisArrayToAnonymousFunctionRector;
use Rector\CodeQuality\Rector\Assign\CombinedAssignRector;
use Rector\CodeQuality\Rector\Class_\CompleteDynamicPropertiesRector;
use Rector\CodeQuality\Rector\ClassMethod\DateTimeToDateTimeInterfaceRector;
use Rector\CodeQuality\Rector\For_\ForRepeatedCountToOwnVariableRector;
use Rector\CodeQuality\Rector\For_\ForToForeachRector;
use Rector\CodeQuality\Rector\FuncCall\CompactToVariablesRector;
use Rector\CodeQuality\Rector\Identical\FlipTypeControlToUseExclusiveTypeRector;
use Rector\CodeQuality\Rector\If_\CombineIfRector;
use Rector\CodeQuality\Rector\If_\ConsecutiveNullCompareReturnsToNullCoalesceQueueRector;
use Rector\CodeQuality\Rector\If_\ExplicitBoolCompareRector;
use Rector\CodeQuality\Rector\PropertyFetch\ExplicitMethodCallOverMagicGetSetRector;
use Rector\CodeQuality\Rector\Ternary\ArrayKeyExistsTernaryThenValueToCoalescingRector;
use Rector\CodingStyle\Rector\Assign\SplitDoubleAssignRector;
use Rector\CodingStyle\Rector\ClassMethod\MakeInheritedMethodVisibilitySameAsParentRector;
use Rector\CodingStyle\Rector\FuncCall\CallUserFuncArrayToVariadicRector;
use Rector\CodingStyle\Rector\FuncCall\ConsistentImplodeRector;
use Rector\CodingStyle\Rector\FuncCall\StrictArraySearchRector;
use Rector\CodingStyle\Rector\If_\NullableCompareToNullRector;
use Rector\CodingStyle\Rector\String_\UseClassKeywordForClassNameResolutionRector;
use Rector\CodingStyle\Rector\Switch_\BinarySwitchToIfElseRector;
use Rector\Core\Configuration\Option;
use Rector\Core\ValueObject\PhpVersion;
use Rector\PHPUnit\Set\PHPUnitSetList;
use Rector\Privatization\Rector\Class_\FinalizeClassesWithoutChildrenRector;
use Rector\Set\ValueObject\LevelSetList;
use Rector\Set\ValueObject\SetList;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;

return static function (ContainerConfigurator $containerConfigurator): void {
    // get parameters
    $parameters = $containerConfigurator->parameters();

    $parameters->set(Option::PHP_VERSION_FEATURES, PhpVersion::PHP_81);

    $parameters->set(Option::IMPORT_DOC_BLOCKS, false);

    $parameters->set(Option::PARALLEL, true);
    $parameters->set(Option::PARALLEL_MAX_NUMBER_OF_PROCESSES, 4);

    $parameters->set(Option::AUTOLOAD_PATHS, [
        __DIR__.'/database/migrations',
    ]);

    $parameters->set(Option::PATHS, [
        __DIR__.'/app',
        __DIR__.'/config',
        __DIR__.'/database',
        __DIR__.'/resources/views',
        __DIR__.'/routes',
        __DIR__.'/tests',
    ]);

    // Define what rule sets will be applied
    $containerConfigurator->import(LevelSetList::UP_TO_PHP_81);
    $containerConfigurator->import(SetList::CODE_QUALITY);
    $containerConfigurator->import(SetList::TYPE_DECLARATION);
    $containerConfigurator->import(SetList::TYPE_DECLARATION_STRICT);

    // PHPUnit
    $containerConfigurator->import(PHPUnitSetList::PHPUNIT_CODE_QUALITY);
    $containerConfigurator->import(PHPUnitSetList::PHPUNIT_EXCEPTION);
    $containerConfigurator->import(PHPUnitSetList::PHPUNIT_MOCK);
    $containerConfigurator->import(PHPUnitSetList::PHPUNIT_SPECIFIC_METHOD);
    $containerConfigurator->import(PHPUnitSetList::PHPUNIT_YIELD_DATA_PROVIDER);

    $parameters->set(Option::SKIP, [
        CallableThisArrayToAnonymousFunctionRector::class, // Changes Laravel routes
        DateTimeToDateTimeInterfaceRector::class, // converts Carbon to \DateTimeInterface
        ExplicitMethodCallOverMagicGetSetRector::class, // it changes property access to getters (that are deprecated). We can enable this rector back after removing all deprecated setters and getters.
        FlipTypeControlToUseExclusiveTypeRector::class, // it decreases readability in some cases by adding negative check ($member === null vs !$member instanceof Member)
    ]);

    // get services (needed for register a single rule)
    $services = $containerConfigurator->services();

    $services->set(ArrayKeyExistsTernaryThenValueToCoalescingRector::class);
    $services->set(CombineIfRector::class);
    $services->set(CombinedAssignRector::class);
    $services->set(CompactToVariablesRector::class);
    $services->set(CompleteDynamicPropertiesRector::class);
    $services->set(ConsecutiveNullCompareReturnsToNullCoalesceQueueRector::class);
    $services->set(ExplicitBoolCompareRector::class);
    $services->set(ForRepeatedCountToOwnVariableRector::class);
    $services->set(ForToForeachRector::class);
    $services->set(BinarySwitchToIfElseRector::class);
    $services->set(CallUserFuncArrayToVariadicRector::class);
    $services->set(ConsistentImplodeRector::class);
    $services->set(MakeInheritedMethodVisibilitySameAsParentRector::class);
    $services->set(NullableCompareToNullRector::class);
    $services->set(SplitDoubleAssignRector::class);
    $services->set(UseClassKeywordForClassNameResolutionRector::class);
    $services->set(StrictArraySearchRector::class);
    $services->set(FinalizeClassesWithoutChildrenRector::class);
};
