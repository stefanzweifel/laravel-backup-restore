<?php declare(strict_types=1);

namespace App\ValueObjects;

use Carbon\CarbonInterface;
use Illuminate\Support\Carbon;

/** Value object to store valid datetime range. */
final readonly class DatetimeRange
{
    public CarbonInterface $from;
    public CarbonInterface $to;

    /** @throws \InvalidArgumentException */
    public function __construct(\DateTimeInterface $from, \DateTimeInterface $to)
    {
        if ($from > $to) {
            throw new \InvalidArgumentException('Date From should be less than date To.');
        }

        $this->from = Carbon::instance($from); // @todo Use CarbonImmutable
        $this->to = Carbon::instance($to); // @todo Use CarbonImmutable
    }

    /** @param bool $absolute Get the absolute of the difference */
    public function diffInDays(bool $absolute = true): int
    {
        // why add a second: DatetimeRange is an internal mathematically, means uncludes edge cases
        return $this->to->addSecond()->diffInDays($this->from, $absolute);
    }
}
