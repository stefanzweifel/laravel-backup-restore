<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Presenters;

use App\Models\DailyUpdates\Report\Report;
use App\Models\DailyUpdates\Report\TeamReport;
use App\Utility\Chart\Chart;
use App\Utility\Chart\DataPoint;
use App\Utility\Chart\DataSet;
use App\Utility\Color;
use Inertia\Inertia;
use Inertia\Response;

/**
 * @psalm-import-type TeamReportStatistic from \App\Models\DailyUpdates\Report\TeamReport
 * @extends \App\Http\Controllers\DailyUpdates\Presenters\DailyUpdatePresenter<\App\Models\DailyUpdates\Report\TeamReport>
 */
final class TeamDailyUpdatePresenter extends DailyUpdatePresenter
{
    /** @inheritDoc */
    public function present(Report $report): Response
    {
        assert($report instanceof TeamReport);

        $viewModel = [
            // Presentation
            'lastUpdatedAgo' => $report->lastUpdatedAt?->diffForHumans() ?? 'never',
            'analytics' => [
                'teamChartData' => $this->formatChart($this->getTeamChartsFromAnalytics($report->dailyUpdateStats, $report->leaveStats)),
                'teamMembers' => $report->teamMembers,
                'numberOfReports' => $this->getTotalNumberOfUpdates($report),
                'teamMemberChartData' => [
                    'weekly' => [],
                    'monthly' => [],
                ],
            ],
            'reports' => $report->updates,
            'leaves' => $report->leaves,
            'showReports' => true,
            'filters' => $this->getFilters(),
            'date' => $this->date(),
            'teamName' => $report->teamName,
            'staffName' => '',
        ];

        return Inertia::render('DailyUpdates/Index', $viewModel);
    }

    /**
     * @param list<TeamReportStatistic> $updates
     * @param list<TeamReportStatistic> $leaves
     */
    private function getTeamChartsFromAnalytics(array $updates, array $leaves): Chart
    {
        $chart = new Chart();
        $updatesDataSet = new DataSet();
        $labels = [];
        foreach ($updates as $update) {
            $updatesDataSet->addDataPoint(new DataPoint($update['count']));
            $labels[] = $update['name'];
        }

        $updatesDataSet->setLegend('Number of daily updates');
        $updatesDataSet->setColor(Color::FULL->value);

        $leavesDataSet = new DataSet();
        foreach ($leaves as $leave) {
            $leavesDataSet->addDataPoint(new DataPoint($leave['count']));
        }

        $leavesDataSet->setLegend('Number of days with registered leave and no daily update');
        $leavesDataSet->setColor(Color::LEAVE->value);

        $chart->addDataSet($updatesDataSet);
        $chart->addDataSet($leavesDataSet);
        $chart->setDataPointsLabels($labels);
        return $chart;
    }

    /** @return array{members: int, fullDayUpdates: int, days: int, halfDayUpdates: int, numberOfFullDayHolidays: int, numberOfHalfDayHolidays: int} */
    private function getTotalNumberOfUpdates(TeamReport $report): array
    {
        return [
            'members' => count($report->dailyUpdateStats),
            'days' => $report->workingDays,
            'fullDayUpdates' => $report->numberOfFullDayReports,
            'halfDayUpdates' => $report->numberOfHalfDayReports,
            'numberOfFullDayHolidays' => $report->numberOfFullDayHolidays,
            'numberOfHalfDayHolidays' => $report->numberOfHalfDayHolidays,
        ];
    }
}
