<?php declare(strict_types=1);

namespace App\Models\DailyUpdates\Report;

use Carbon\CarbonInterface;

final class NullReport extends Report
{
    public function __construct(public readonly ?CarbonInterface $lastUpdatedAt)
    {
    }
}
