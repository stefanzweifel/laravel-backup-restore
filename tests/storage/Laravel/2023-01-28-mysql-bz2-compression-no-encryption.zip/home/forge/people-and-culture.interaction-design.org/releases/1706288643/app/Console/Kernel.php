<?php declare(strict_types=1);

namespace App\Console;

use App\Console\Commands\FetchLeaveDaysFromCalendar;
use App\Console\Commands\SendMissingDailyUpdateReminder;
use App\Console\Commands\SendWeeklyDigest;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

final class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        $schedule->command('model:prune')->daily();

        $schedule->command(FetchLeaveDaysFromCalendar::class)
            ->everyTwoHours()
            ->environments(['production']);
        $schedule->command(SendMissingDailyUpdateReminder::class)
            ->dailyAt('09:00')
            ->environments(['production']);
        $schedule->command(SendWeeklyDigest::class)
            ->mondays()
            ->at('13:50')
            ->environments(['production']);
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
