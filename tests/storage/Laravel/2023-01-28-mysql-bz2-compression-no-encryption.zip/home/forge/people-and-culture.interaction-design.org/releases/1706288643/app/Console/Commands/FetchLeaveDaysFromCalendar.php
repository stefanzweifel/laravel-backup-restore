<?php declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\Staff;
use App\Models\StaffLeave\Leave;
use App\Services\StaffLeave\StaffLeaveCalendar;
use App\Services\StaffLeave\StaffLeaveEvent;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

/**
 * Fetch leave days from the Spock team leave calendar.
 * @see https://spockoffice.com/spockapp/calendar/
 * @see https://github.com/u01jmg3/ics-parser
 * @psalm-type OptionAsArray = array{0: string, 1: string|list<string>|null, 2: int, 3?: string, 4?: string|bool|int|float|list<string>|null, 5?: (list<string>|\Closure():list<string>)}
 */
final class FetchLeaveDaysFromCalendar extends Command
{
    /** @var string */
    protected $signature = 'leaves:fetch
        {--days-in-the-past=365 : Sync all events that occurred roughly this many days in the past}
        {--days-in-the-future=0 : Sync all events that will occur roughly this many days in the future}
    ';

    /** @var string */
    protected $description = 'Fetch leave days from the Spock team leave calendar.';

    public function handle(StaffLeaveCalendar $staffLeaveCalendar): int
    {
        $daysInThePast = $this->daysInThePast();
        $daysInTheFuture = $this->daysInTheFuture();

        $calendarEvents = $staffLeaveCalendar->getEvents($daysInThePast, $daysInTheFuture);
        if ($calendarEvents->isEmpty()) {
            return self::SUCCESS;
        }

        /** @var \Carbon\CarbonImmutable $fromDate */
        $fromDate = $calendarEvents->min(static fn (StaffLeaveEvent $staffLeaveEvent) => $staffLeaveEvent->leaveDate);

        /** @var \Carbon\CarbonImmutable $toDate */
        $toDate = $calendarEvents->max(static fn (StaffLeaveEvent $staffLeaveEvent) => $staffLeaveEvent->leaveDate);

        $leaveQuery = Leave::query()
            ->where('leave_date', '>=', $fromDate)
            ->where('leave_date', '<=', $toDate);

        /** Delete leaves that are no longer present in the calendar. */
        $leaveQuery->clone()
            ->whereNotIn('calendar_event_uid', $calendarEvents->pluck('calendarEventUid'))
            ->delete();

        /** @var \Illuminate\Support\Collection<int, string> $existingCalendarEventUids */
        $existingCalendarEventUids = $leaveQuery->clone()->get()->pluck('calendar_event_uid');

        $allStaffKeyedBySpockId = Staff::query()->withoutGlobalScopes([SoftDeletingScope::class])->get()->keyBy('spock_user_id');

        $calendarEvents->chunk(100)->each(function (Collection $chunk) use ($existingCalendarEventUids, $allStaffKeyedBySpockId): void {
            $chunk->each(function (StaffLeaveEvent $staffLeaveEvent) use ($existingCalendarEventUids, $allStaffKeyedBySpockId): void {
                if ($existingCalendarEventUids->contains($staffLeaveEvent->calendarEventUid)) {
                    return;
                }

                $staff = $allStaffKeyedBySpockId->get($staffLeaveEvent->spockUserId);
                if (! $staff instanceof Staff) {
                    $this->unrecognizedSpockUserIdLogForDevTeam($staffLeaveEvent);
                    return;
                }

                Leave::register($staff, $staffLeaveEvent);
            });
        });

        return self::SUCCESS;
    }

    private function daysInThePast(): int
    {
        $daysInThePast = $this->option('days-in-the-past');
        if (! is_numeric($daysInThePast)) {
            throw new \InvalidArgumentException('The days-in-the-past option must have a numeric value.');
        }

        return (int) $daysInThePast;
    }

    private function daysInTheFuture(): int
    {
        $daysInTheFuture = $this->option('days-in-the-future');
        if (! is_numeric($daysInTheFuture)) {
            throw new \InvalidArgumentException('The days-in-the-future option must have a numeric value.');
        }

        return (int) $daysInTheFuture;
    }

    private function unrecognizedSpockUserIdLogForDevTeam(StaffLeaveEvent $staffLeaveEvent): void
    {
        $spockUserId = $staffLeaveEvent->spockUserId;
        $slackDisplayName = $staffLeaveEvent->slackDisplayName;

        Log::critical("Unrecognized Spock user ID: {$spockUserId} ({$slackDisplayName}). Please update the staff member record on the People and Culture app!", [
            'staffLeaveEvent' => $staffLeaveEvent,
        ]);
    }
}
