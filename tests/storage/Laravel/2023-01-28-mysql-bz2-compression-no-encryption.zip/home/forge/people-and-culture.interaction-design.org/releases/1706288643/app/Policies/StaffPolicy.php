<?php declare(strict_types=1);

namespace App\Policies;

use App\Models\Staff;

final class StaffPolicy
{
    public function create(Staff $loggedInUser): bool
    {
        return $loggedInUser->is_admin;
    }

    public function view(Staff $loggedInUser): bool
    {
        return $loggedInUser->is_admin;
    }

    public function update(Staff $loggedInUser): bool
    {
        return $loggedInUser->is_admin;
    }

    public function delete(Staff $loggedInUser): bool
    {
        return $loggedInUser->is_admin;
    }
}
