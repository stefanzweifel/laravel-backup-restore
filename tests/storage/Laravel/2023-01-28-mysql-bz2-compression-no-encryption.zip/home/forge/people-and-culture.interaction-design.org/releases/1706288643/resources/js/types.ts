export type Filters = {
  rangeOptions: {
      days: string[];
      weeks: string[];
      months: string[];
  };
  teams: Team[];
  date: string;
  range: string;
  by: string;
};

export type FilterDateRange = {year: number; month: number};

export type Analytics = {
  teamChartData: {
    labels: string[];
    datasets: ChartDataSet[];
  };
  teamMembers: TeamMember[];
  numberOfReports: {
    members: number;
    fullDayUpdates: number;
    days: number;
    halfDayUpdates: number;
    numberOfFullDayHolidays: number;
    numberOfHalfDayHolidays: number;
  };
  teamMemberChartData: {
    monthly: {
      labels: string[];
      datasets: ChartDataSet[];
    };
    weekly: {
      labels: string[];
      datasets: ChartDataSet[];
    };
  };
};

export type ChartDataSet = {
  backgroundColor: string;
  label: string;
};

export type TeamMember = {
  name: string;
  email: string;
};

export type Team = {
  slug: string;
  name: string;
  members: TeamMember[];
};

export type DailyUpdate = {
  submitted: boolean;
  staffName: string;
  staffEmail: string;
  teamName: string;
  reportingDate: string;
  updateId?: number;
  feelingToday?: number;
  doneToday?: string;
  plansTomorrow?: string;
  blockedProgress?: string;
  highlights: string;
  isFullDay?: boolean;
  hoursWorked?: number;
  hasLeave?: boolean;
  userCanUpdate: boolean;
};

export type DailyUpdateReport = {
  [date: string]: DailyUpdate;
};

export type WeeklyUpdate = {
  id: number;
  teamLeadId: number;
  teamLeadName: string;
  reportingWeekEndDate: Date;
  progressLastWeek: string;
  plansThisWeek: string;
  potentialProblems: string;
  notes: string;
};

export type WeeklyUpdateReport = {
  [date: string]: WeeklyUpdate;
};

export type Staff = {
  id: number;
  name: string;
  email: string;
  team_id: number;
  team_name: string;
  slack_user_id: string;
  spock_user_id: string;
  can?: {
    edit?: string;
    delete?: string;
  };
};

export type Leave = {
  staffEmail: string;
  leaveDate: string;
  leavePeriod: string;
};

export enum Feeling {
  '😱 (💔/5)' = 1,
  '🙁 (💚💚/5)' = 2,
  '😐 (💚💚💚/5)' = 3,
  '😊 (💚💚💚💚/5)' = 4,
  '😀 (💚💚💚💚💚/5)' = 5,
}
