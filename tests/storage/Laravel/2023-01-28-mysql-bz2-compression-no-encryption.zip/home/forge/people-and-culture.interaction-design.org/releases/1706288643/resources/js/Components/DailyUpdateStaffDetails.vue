<script setup lang="ts">
import {trans} from 'laravel-vue-i18n';

import {Analytics} from '@/types';

defineProps<{
  analytics: Analytics;
  teamName: string;
  staffName: string;
  currentRange: string;
}>();
</script>

<template>
  <h2 class="text-3xl font-bold my-3">
    {{ trans('dailyUpdates.individualUpdates', {staffName: staffName, date: currentRange}) }}
  </h2>

  <p
    class="font-serif mb-4"
    v-html="
      trans('dailyUpdates.individualTeam', {
        teamMemberName: staffName,
        teamName: teamName,
      })
    "
  ></p>

  <p
    class="font-serif mb-3"
    v-html="
      trans('dailyUpdates.individualUpdateReport', {
        staffName: staffName,
        fullDayUpdates: analytics.numberOfReports.fullDayUpdates.toString(),
        halfDayUpdates: analytics.numberOfReports.halfDayUpdates.toString(),
        days: analytics.numberOfReports.days.toString(),
        fullDayHolidays:
          analytics.numberOfReports.numberOfFullDayHolidays.toString(),
        halfDayHolidays:
          analytics.numberOfReports.numberOfHalfDayHolidays.toString(),
      })
    "
  ></p>

  <span
    class="font-serif"
    v-html="
        trans('dailyUpdates.individualUpdateSpockLink', {
          staffName: staffName,
          fullDayHolidays:
            analytics.numberOfReports.numberOfFullDayHolidays.toString(),
          halfDayHolidays:
            analytics.numberOfReports.numberOfHalfDayHolidays.toString(),
        })
      "
  ></span>
</template>
