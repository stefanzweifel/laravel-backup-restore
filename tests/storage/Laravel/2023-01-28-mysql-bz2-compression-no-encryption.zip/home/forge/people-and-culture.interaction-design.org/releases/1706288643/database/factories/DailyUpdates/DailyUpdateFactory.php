<?php declare(strict_types=1);

namespace Database\Factories\DailyUpdates;

use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Feeling;
use Carbon\CarbonInterface;
use Database\Factories\StaffFactory;

/** @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\DailyUpdates\DailyUpdate> */
final class DailyUpdateFactory extends \Illuminate\Database\Eloquent\Factories\Factory
{
    /** @var class-string<\App\Models\DailyUpdates\DailyUpdate> */
    protected $model = DailyUpdate::class;

    /** @inheritDoc */
    public function definition(): array
    {
        return [
            'reporting_date' => $this->faker->dateTimeThisMonth,
            'feeling' => $this->faker->randomElement(Feeling::cases()),
            'done_today' => $this->faker->paragraph,
            'plans_tomorrow' => $this->faker->paragraph,
            'blocked_progress' => $this->faker->paragraph,
            'highlights' => $this->faker->paragraph,
            'is_full_day' => $this->faker->boolean,
            'hours_worked' => 8,
            'has_leave' => $this->faker->boolean,
            'staff_id' => StaffFactory::new(),
        ];
    }

    public function fullDay(): self
    {
        return $this->state([
            'is_full_day' => true,
        ]);
    }

    public function reportedAt(CarbonInterface $date): self
    {
        return $this->state([
            'reporting_date' => $date,
        ]);
    }

    public function halfDay(): self
    {
        return $this->state([
            'is_full_day' => false,
            'hours_worked' => 3,
        ]);
    }
}
