<?php declare(strict_types=1);

namespace App\Models\DailyUpdates\Report;

use App\Models\Staff;
use Carbon\CarbonInterface;

final class NullUpdateDTO
{
    public readonly bool $submitted;

    private function __construct(
        public readonly string $staffName,
        public readonly string $staffEmail,
        public readonly string $teamName,
        public readonly string $reportingDate
    ) {
        $this->submitted = false;
    }

    public static function create(Staff $staff, CarbonInterface $date): self
    {
        return new self(
            $staff->name,
            $staff->email,
            $staff->team->name,
            $date->toFormattedDateString()
        );
    }
}
