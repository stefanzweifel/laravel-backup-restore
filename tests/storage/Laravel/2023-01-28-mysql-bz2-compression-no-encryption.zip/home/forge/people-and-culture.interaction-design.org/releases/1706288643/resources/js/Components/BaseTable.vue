<script setup lang="ts"></script>

<template>
  <div class="flex flex-col">
    <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
      <div class="inline-block py-2 min-w-full sm:px-6 lg:px-8">
        <div class="overflow-hidden shadow-md sm:rounded-lg">
          <table class="min-w-full">
            <thead class="bg-gray-100 dark:bg-gray-700">
              <tr>
                <slot name="headings" />
              </tr>
            </thead>
            <tbody>
              <slot />
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>
