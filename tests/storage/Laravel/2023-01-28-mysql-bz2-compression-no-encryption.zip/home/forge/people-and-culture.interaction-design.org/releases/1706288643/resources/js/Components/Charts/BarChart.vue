<script setup lang="ts">
import {ChartDataSet} from '@/types';
import {ChartItem} from 'chart.js';
import {ref} from 'vue';

const props = defineProps<{
  maxScaleValue: number;
  datasets: ChartDataSet[];
  labels: string[];
}>();

const canvas = ref<ChartItem | null>(null);

// The current config won't allow customization, we will add customization
// once we require more charts
const chartConfig = {
  indexAxis: 'y',
  responsive: true,
  elements: {
    rectangle: {},
  },
  plugins: {
    legend: {
      position: 'bottom',
    },
    tooltip: {
      mode: 'nearest',
    },
  },
  hover: {
    mode: 'label',
  },
  scales: {
    x: {
      scaleLabel: {
        display: false,
      },
      stacked: true,
      min: 0,
      max: props.maxScaleValue,
    },
    y: {
      grid: {
        display: false,
      },
      stacked: true,
    },
  },
};

const configuration = {
  type: 'bar',
  data: {
    datasets: props.datasets,
    labels: props.labels,
  },
  options: chartConfig,
};

import('chart.js').then(({Chart, registerables}) => {
  Chart.register(...registerables);
  /* @ts-ignore */
  new Chart(canvas.value, configuration);
});
</script>

<template>
  <canvas
    class="bg-neutral-50"
    role="figure"
    aria-label="Bar Chart"
    ref="canvas"
  ></canvas>
</template>
