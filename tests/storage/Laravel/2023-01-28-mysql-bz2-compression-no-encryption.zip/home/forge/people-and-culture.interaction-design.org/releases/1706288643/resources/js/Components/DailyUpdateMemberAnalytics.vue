<script setup lang="ts">
import {Link} from '@inertiajs/inertia-vue3';
import route from 'ziggy-js';

const props = defineProps<{
  name: string;
  email: string;
}>();

const currentUrl = new URL(window.location.href);
const currentRange = currentUrl.searchParams.get('range');

const filters = new URLSearchParams({
  range: `${currentRange}`,
  by: `staff:${props.email}`,
}).toString();

const url = `${route('peopleAndCulture.dailyUpdates.index')}?${filters}`;
</script>

<template>
  <Link class="link" :href="url">
    {{ name }}
  </Link>
</template>
