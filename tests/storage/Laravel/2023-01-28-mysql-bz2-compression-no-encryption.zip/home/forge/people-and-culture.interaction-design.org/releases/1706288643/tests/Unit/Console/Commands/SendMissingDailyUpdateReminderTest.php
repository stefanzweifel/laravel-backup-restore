<?php declare(strict_types=1);

namespace Tests\Unit\Console\Commands;

use App\Console\Commands\SendMissingDailyUpdateReminder;
use App\Notifications\MissingDailyUpdateReminder;
use Carbon\CarbonImmutable;
use Database\Factories\DailyUpdates\DailyUpdateFactory;
use Database\Factories\StaffFactory;
use Database\Factories\StaffLeave\StaffLeaveFactory;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Notification;

it('it should notify staff about missing daily update', function () {
    $now = CarbonImmutable::parse('2023-07-07 12:00:00');
    Carbon::setTestNow($now);
    Notification::fake();
    $staffWithoutDailyUpdate = StaffFactory::new()->createOne(['created_at' => $now->clone()->subWeek()]);
    $staffWithDailyUpdate = StaffFactory::new()->createOne(['created_at' => $now->clone()->subWeek()]);
    DailyUpdateFactory::new()->createOne([
        'staff_id' => $staffWithDailyUpdate->id,
        'reporting_date' => $now->clone()->subDays(SendMissingDailyUpdateReminder::UPDATE_VERIFICATION_DAYS_AGO),
    ]);

    /** Verifies if daily updates were posted 3 days ago: 2023-07-04 (Tuesday) */
    $this->artisan(SendMissingDailyUpdateReminder::class);

    Notification::assertSentTo($staffWithoutDailyUpdate, MissingDailyUpdateReminder::class);
    Notification::assertNotSentTo($staffWithDailyUpdate, MissingDailyUpdateReminder::class);
});

it('it should not notify staff with registered leave', function () {
    $now = CarbonImmutable::parse('2023-07-07 12:00:00');
    Carbon::setTestNow($now);
    Notification::fake();
    $staffWithRegisteredLeave = StaffFactory::new()->createOne(['created_at' => $now->clone()->subWeek()]);
    StaffLeaveFactory::new()->createOne([
        'staff_id' => $staffWithRegisteredLeave->id,
        'leave_date' => $now->clone()->subDays(SendMissingDailyUpdateReminder::UPDATE_VERIFICATION_DAYS_AGO),
    ]);

    /** Verifies if daily updates were posted 3 days ago: 2023-07-04 (Tuesday) */
    $this->artisan(SendMissingDailyUpdateReminder::class);

    Notification::assertNotSentTo($staffWithRegisteredLeave, MissingDailyUpdateReminder::class);
});

it('it should not notify staff if a daily update is missing on the weekend', function () {
    $now = CarbonImmutable::parse('2023-07-11 12:00:00');
    Carbon::setTestNow($now);
    Notification::fake();
    $staffWithoutDailyUpdate = StaffFactory::new()->createOne(['created_at' => $now->clone()->subWeek()]);

    /** Verifies if daily updates were posted 3 days ago: 2023-07-08 (Saturday) */
    $this->artisan(SendMissingDailyUpdateReminder::class);

    Notification::assertNotSentTo($staffWithoutDailyUpdate, MissingDailyUpdateReminder::class);
});

it('it should not notify newly added staff', function () {
    $now = CarbonImmutable::parse('2023-07-07 12:00:00');
    Carbon::setTestNow($now);
    Notification::fake();
    $newlyAddedStaff = StaffFactory::new()->createOne(['created_at' => $now->clone()->subDay()]);

    /** Verifies if daily updates were posted 3 days ago: 2023-07-04 (Tuesday) */
    $this->artisan(SendMissingDailyUpdateReminder::class);

    Notification::assertNotSentTo($newlyAddedStaff, MissingDailyUpdateReminder::class);
});
