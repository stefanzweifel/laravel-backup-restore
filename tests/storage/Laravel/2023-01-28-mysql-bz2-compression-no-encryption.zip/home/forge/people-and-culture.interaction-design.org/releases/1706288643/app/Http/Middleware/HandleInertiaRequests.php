<?php declare(strict_types=1);

namespace App\Http\Middleware;

use App\Models\Staff;
use App\Models\WeeklyUpdates\WeeklyUpdate;
use Illuminate\Http\Request;
use Inertia\Middleware;

final class HandleInertiaRequests extends Middleware
{
    /**
     * @see https://inertiajs.com/server-side-setup#root-template
     * @var string
     */
    protected $rootView = 'app';

    /** @see https://inertiajs.com/asset-versioning */
    public function version(Request $request): ?string //phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod
    {
        return parent::version($request);
    }

    /**
     * @see https://inertiajs.com/shared-data
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint
     * @return array<string, mixed>
     */
    public function share(Request $request): array
    {
        $user = $request->user();

        return array_merge(parent::share($request), [
            'user' => static fn (): ?array => $user instanceof Staff ? [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'avatar' => $user->avatar_url,
                'can' => [
                    'update_staff_info' => $user->can('update', Staff::class),
                    'read_weekly_updates' => $user->can('index', WeeklyUpdate::class),
                    'create_weekly_updates' => $user->can('create', WeeklyUpdate::class),
                ],
            ] : null,
            'flash' => static fn (): array => [
                'success' => $request->session()->get('success'),
                'error' => $request->session()->get('error'),
            ],
        ]);
    }
}
