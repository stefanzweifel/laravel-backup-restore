<?php declare(strict_types=1);

namespace App\Utility;

/** phpcs:disable */
enum Color: string
{
    case FULL = '#1565c0';
    case PART = '';
    case EXPECTED = '#c1baba';
    case ADDITIONAL = '#aa4ae2';
    case BOUNDARY = '#000000';

    case LEAVE = '#388ae7';
}
