<?php declare(strict_types=1);

namespace Database\Factories;

use App\Models\Team;

/** @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Team> */
final class TeamFactory extends \Illuminate\Database\Eloquent\Factories\Factory
{
    /** @var class-string<\App\Models\Team> */
    protected $model = Team::class;

    /** @inheritDoc */
    public function definition(): array
    {
        return [
            'name' => $this->faker->company,
            'slug' => $this->faker->slug,
            'symbol' => ':rooster:',
            'last_updated_by_id' => null,
        ];
    }
}
