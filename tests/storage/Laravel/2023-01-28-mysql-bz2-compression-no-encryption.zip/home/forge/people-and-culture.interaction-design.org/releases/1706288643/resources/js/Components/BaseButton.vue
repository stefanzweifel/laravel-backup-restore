<script setup lang="ts">
import {computed} from 'vue';

const props = withDefaults(
  defineProps<{
    variation?: 'primary' | 'secondary';
    type?: 'submit' | 'button' | 'reset';
  }>(),
  {
    type: 'button',
    variation: 'primary',
  }
);

const variationClass = computed(() => ({
  'text-white bg-brand-01 hover:bg-brand-02 focus:ring-4 focus:ring-blue-300 dark:bg-brand-01 dark:hover:bg-brand-02 dark:focus:ring-blue-800':
    props.variation === 'primary',
  'bg-white focus:ring-4 border-2 border-gray-700':
    props.variation === 'secondary',
}));
</script>

<template>
  <button
    class="font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2"
    :class="variationClass"
  >
    <slot></slot>
  </button>
</template>
