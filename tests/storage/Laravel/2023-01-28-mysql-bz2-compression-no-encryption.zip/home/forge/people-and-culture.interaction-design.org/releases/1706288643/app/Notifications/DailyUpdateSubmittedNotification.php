<?php declare(strict_types=1);

namespace App\Notifications;

use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Feeling;
use App\Models\Staff;
use App\Services\Slack\IxDFSlackWebhookWorkspace;
use App\Services\Slack\UserLinker;
use App\ValueObjects\DatetimeRange;
use Illuminate\Notifications\Messages\SlackAttachment;
use Illuminate\Notifications\Messages\SlackMessage;
use Illuminate\Notifications\Notification;

final class DailyUpdateSubmittedNotification extends Notification
{
    public function __construct(public readonly DailyUpdate $dailyUpdate, private readonly UserLinker $slackUserLinker)
    {
    }

    /**
     * Get the notification's delivery channels.
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint.DisallowedMixedTypeHint
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.ParameterTypeHint.MissingAnyTypeHint
     * @phpcsSuppress SlevomatCodingStandard.Functions.UnusedParameter.UnusedParameter
     * @return list<string>
     */
    public function via($notifiable)
    {
        return ['slack'];
    }

    /** Get the Slack representation of the notification. */
    public function toSlack(IxDFSlackWebhookWorkspace $notifiable): SlackMessage // phpcs:ignore SlevomatCodingStandard.Functions.FunctionLength.FunctionLength, SlevomatCodingStandard.Files.FunctionLength.FunctionLength
    {
        $slackUserId = $this->dailyUpdate->staff->slack_user_id;
        $teamName = $this->dailyUpdate->staff->team->name;
        $formattedDate = $this->dailyUpdate->reporting_date->format('l, Y-m-d');

        /** @var array<string, string> $staffSlackIdToNameMap */
        $staffSlackIdToNameMap = Staff::query()->pluck('slack_user_id', 'name')->all();

        $message = today($this->dailyUpdate->staff->timezone)->isSameDay($this->dailyUpdate->reporting_date)
            ? "<@$slackUserId> ($teamName team) has just finished their working day ($formattedDate).\n\nHere is the update:"
            : "<@$slackUserId> ($teamName team) has just submitted an update for {$formattedDate}:";

        $slackMessage = (new SlackMessage())
            ->from((string) config('ixdf_slack.webhook.daily.username'), $this->dailyUpdate->staff->team->symbol)
            ->to($notifiable->getDefaultChannel())
            ->content($message)
            ->linkNames()
            ->attachment(function (SlackAttachment $slackAttachment) {
                $slackAttachment->title = 'Feeling';
                $slackAttachment->content = $this->dailyUpdate->feeling->toEmoji();
                $slackAttachment->footer($this->generateAvgFeelingText($this->dailyUpdate, 7));
            })
            ->attachment(function (SlackAttachment $slackAttachment) use ($staffSlackIdToNameMap) {
                $slackAttachment->title = 'Done';
                $slackAttachment->content = $this->slackUserLinker->linkNames($this->dailyUpdate->done_today, $staffSlackIdToNameMap);
            })
            ->attachment(function (SlackAttachment $slackAttachment) use ($staffSlackIdToNameMap) {
                $slackAttachment->title = 'Plans';
                $slackAttachment->content = $this->slackUserLinker->linkNames($this->dailyUpdate->plans_tomorrow, $staffSlackIdToNameMap);
            });

        if (strlen(trim($this->dailyUpdate->blocked_progress)) > 3) {
            $slackMessage->attachment(function (SlackAttachment $slackAttachment) use ($staffSlackIdToNameMap) {
                $slackAttachment->title = 'Blockers';
                $slackAttachment->content = $this->slackUserLinker->linkNames($this->dailyUpdate->blocked_progress, $staffSlackIdToNameMap);
            });
        }

        if (strlen(trim($this->dailyUpdate->highlights)) > 3) {
            $slackMessage->attachment(function (SlackAttachment $slackAttachment) use ($staffSlackIdToNameMap) {
                $slackAttachment->title = 'Highlights';
                $slackAttachment->content = $this->slackUserLinker->linkNames($this->dailyUpdate->highlights, $staffSlackIdToNameMap);
            });
        }

        $slackMessage->attachment(function (SlackAttachment $slackAttachment) {
            $slackAttachment->footer($this->generateSeeMoreUpdatesText($this->dailyUpdate));
        });

        $slackMessage->level = $this->getSlackMessageLevel($this->dailyUpdate->feeling);

        return $slackMessage;
    }

    private function generateSeeMoreUpdatesText(DailyUpdate $dailyUpdate): string
    {
        return sprintf(
            '<%s|See more %s’%s daily updates>.',
            route('peopleAndCulture.dailyUpdates.index', ['by' => "staff:{$dailyUpdate->staff->email}", 'range' => '30-days']),
            $dailyUpdate->staff->name,
            str_ends_with($dailyUpdate->staff->name, 's') ? '' : 's'
        );
    }

    private function getSlackMessageLevel(Feeling $feeling): string
    {
        return match ($feeling) {
            Feeling::Awful => 'error',
            Feeling::Bad => 'error',
            Feeling::NotWell => 'warning',
            Feeling::Good => 'success',
            Feeling::Awesome => 'success',
        };
    }

    private function generateAvgFeelingText(DailyUpdate $dailyUpdate, int $days): string
    {
        $range = new DatetimeRange($dailyUpdate->reporting_date->clone()->subDays($days), $dailyUpdate->reporting_date);
        $avgFeeling = round($dailyUpdate->staff->avgFeelingFor($range), 1);

        return "Avg. feeling for $days days: *$avgFeeling* of 5";
    }
}
