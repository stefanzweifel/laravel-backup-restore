<?php declare(strict_types=1);

return [
    'add' => 'Add new staff',
    'delete' => 'Delete the staff member?',
    'form' => [
        'createTitle' => 'Add new staff',
        'editTitle' => 'Edit info for :name',
        'email' => [
            'label' => '<b>Staff Email</b>',
            'placeholder' => 'name@team.interaction-design.org',
            'helpText' => 'Please provide the email address associated with the IxDF Member profile.',
        ],
        'name' => [
            'label' => '<b>Staff Name</b>',
            'placeholder' => 'Name',
            'helpText' => 'Enter the name you would like to display on this application.',
        ],
        'team' => [
            'label' => '<b>Team</b>',
            'placeholder' => 'Team',
            'helpText' => 'Select a team.',
        ],
        'slack_user_id' => [
            'label' => '<b>Member ID on Slack</b>',
            'placeholder' => 'Example: U04U6E1J5S5',
            'helpText' => 'See <a href="https://www.workast.com/help/article/how-to-find-a-slack-user-id/" target="_blank" class="underline text-blue-600">how to find it</a>. Used for Slack integration.',
        ],
        'spock_user_id' => [
            'label' => '<b>User ID on Spock</b>',
            'placeholder' => 'Example: U3444555666XXXXXXXXXXXXXXXXXXXXXX',
            'helpText' => 'Filled in automatically by the system.',
        ],
    ],
];
