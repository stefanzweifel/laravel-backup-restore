<?php declare(strict_types=1);

namespace App\Models\DailyUpdates\Report;

use Carbon\CarbonInterface;

final class IndividualReport extends Report
{
    /**
     * @param array<string, array<string, \App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO>> $updates
     * @param list<\App\Models\StaffLeave\Report\LeaveDTO> $leaves
     * @param array<string, array{updates: int, leaves: int, days: int}> $weeklyStats
     * @param array<string, array{updates: int, leaves: int, days: int}> $monthlyStats
     */
    public function __construct(
        public readonly string $staffName,
        public readonly string $teamName,
        public readonly int $workingDays,
        public readonly ?CarbonInterface $lastUpdatedAt,
        public readonly array $updates,
        public readonly array $leaves,
        public readonly array $weeklyStats,
        public readonly array $monthlyStats,
        public readonly int $numberOfFullDayReports,
        public readonly int $numberOfHalfDayReports,
        public readonly int $numberOfFullDayHolidays,
        public readonly int $numberOfHalfDayHolidays
    ) {
    }
}
