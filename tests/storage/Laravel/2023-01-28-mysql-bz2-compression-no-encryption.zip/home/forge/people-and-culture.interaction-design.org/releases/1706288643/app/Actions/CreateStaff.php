<?php declare(strict_types=1);

namespace App\Actions;

use App\Models\Staff;

final class CreateStaff
{
    /** @param array{avatar: string, email: string, first_name: string, team_id: int, slack_user_id: string, spock_user_id: string} $staffData */
    public function execute(array $staffData): void
    {
        $staff = new Staff();
        $staff->avatar_url = $staffData['avatar'];
        $staff->email = $staffData['email'];
        $staff->name = $staffData['first_name'];
        $staff->team_id = $staffData['team_id'];
        $staff->slack_user_id = $staffData['slack_user_id'];
        $staff->spock_user_id = $staffData['spock_user_id'];
        $staff->is_admin = false;

        $staff->save();
    }
}
