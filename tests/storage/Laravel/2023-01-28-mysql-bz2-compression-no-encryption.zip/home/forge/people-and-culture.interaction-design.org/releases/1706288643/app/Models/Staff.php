<?php declare(strict_types=1);

namespace App\Models;

use App\Events\DailyUpdateSubmitted;
use App\Events\WeeklyUpdateSubmitted;
use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Feeling;
use App\Models\Logging\InteractsWithLogging;
use App\Models\StaffLeave\Leave;
use App\Models\WeeklyUpdates\WeeklyUpdate;
use App\ValueObjects\DatetimeRange;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;

/**
 * @property int $id
 * @property string $name
 * @property string $email
 * @property string|null $avatar_url
 * @property int $team_id
 * @property bool $is_admin
 * @property string|null $timezone Null when it's unknown.
 * @property list<int> $working_days
 * @property bool $should_post_daily_updates Whether a Staff should post updates. In some special cases, colleagues don't post update. Possible reasons: part-time workers, CEO.
 * @property string $slack_user_id Slack's User ID. Used for Slack integrations. How to find it: https://www.workast.com/help/article/how-to-find-a-slack-user-id/
 * @property string|null $spock_user_id Spock's User ID. Used for Spock calendar integration. If one is missing for a Staff, a Slack notification will notify the dev team. Use {@see \App\Services\Spock\SlackToSpockIdTranslator} to fetch this value for new Staff.
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property-read \App\Models\Team $team
 * @property-read \Illuminate\Support\Collection<int, \App\Models\DailyUpdates\DailyUpdate> $dailyUpdates
 * @property-read \Illuminate\Support\Collection<int, \App\Models\StaffLeave\Leave> $leaves
 */
final class Staff extends Authenticatable
{
    use InteractsWithLogging;
    use Notifiable;
    use SoftDeletes;

    /** @var string */
    protected $table = 'peopleAndCulture__staff';

    /** @var array<string, scalar|null> */
    protected $attributes = [
        'should_post_daily_updates' => true,
        'working_days' => '[1,2,3,4,5]',
    ];

    /** @var array<string, string> */
    protected $casts = [
        'is_admin' => 'bool',
        'should_post_daily_updates' => 'bool',
        'slack_user_id' => 'string',
        'working_days' => 'array',
    ];

    public function team(): BelongsTo
    {
        return $this->belongsTo(Team::class)->withoutGlobalScopes();
    }

    public function dailyUpdates(): HasMany
    {
        return $this->hasMany(DailyUpdates\DailyUpdate::class);
    }

    public function weeklyUpdates(): HasMany
    {
        return $this->hasMany(WeeklyUpdate::class, 'team_lead_id');
    }

    public function leaves(): HasMany
    {
        return $this->hasMany(Leave::class);
    }

    /** @param array<string, string> $updateData */
    public function createDailyUpdate(array $updateData): void
    {
        $dailyUpdate = new DailyUpdate();
        $dailyUpdate->reporting_date = Carbon::parse($updateData['submission_date']);
        $dailyUpdate->done_today = $updateData['update'];
        $dailyUpdate->plans_tomorrow = $updateData['plans'];
        $dailyUpdate->blocked_progress = $updateData['blockers'];
        $dailyUpdate->highlights = $updateData['highlights'];
        $dailyUpdate->is_full_day = $updateData['workday'] === 'full';
        $dailyUpdate->hours_worked = (int) $updateData['hours_worked'];
        $dailyUpdate->has_leave = (bool) $updateData['holiday'];
        $dailyUpdate->feeling = Feeling::from((int) $updateData['feeling']);

        $this->dailyUpdates()->save($dailyUpdate);

        event(new DailyUpdateSubmitted($dailyUpdate));
    }

    /** @param array<string, string> $updateData */
    public function updateDailyUpdate(int $dailyUpdateId, array $updateData): void
    {
        $dailyUpdate = DailyUpdate::findOrFail($dailyUpdateId);
        $dailyUpdate->reporting_date = Carbon::parse($updateData['submission_date']);
        $dailyUpdate->done_today = $updateData['update'];
        $dailyUpdate->plans_tomorrow = $updateData['plans'];
        $dailyUpdate->blocked_progress = $updateData['blockers'];
        $dailyUpdate->highlights = $updateData['highlights'];
        $dailyUpdate->is_full_day = $updateData['workday'] === 'full';
        $dailyUpdate->hours_worked = (int) $updateData['hours_worked'];
        $dailyUpdate->has_leave = (bool) $updateData['holiday'];
        $dailyUpdate->feeling = Feeling::from((int) $updateData['feeling']);

        $dailyUpdate->save();
    }

    /** @param array<string, string> $updateData */
    public function createWeeklyUpdate(array $updateData): void
    {
        $update = new WeeklyUpdate();
        $update->reporting_week_end_date = Carbon::parse($updateData['reporting_week_end_date']);
        $update->progress_last_week = (string) $updateData['update'];
        $update->plans_this_week = (string) $updateData['plans'];
        $update->potential_problems = (string) $updateData['blockers'];
        $update->notes = (string) $updateData['notes'];

        $this->weeklyUpdates()->save($update);

        event(new WeeklyUpdateSubmitted($update));
    }

    public function avgFeelingFor(DatetimeRange $datetimeRange): float
    {
        return (float) $this->dailyUpdates()
            ->whereBetween('reporting_date', [$datetimeRange->from, $datetimeRange->to])
            ->avg('feeling');
    }

    public function routeNotificationForSlack(): string
    {
        return $this->slack_user_id;
    }
}
