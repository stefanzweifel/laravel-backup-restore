<script setup lang="ts">
import {Head} from '@inertiajs/inertia-vue3';
import {trans} from 'laravel-vue-i18n';
import {Team} from '@/types';

import Layout from '@/Shared/Layout.vue';
import StaffForm from '@/Components/StaffForm.vue';

defineProps<{
  teams: Team[];
}>();
</script>

<template>
  <Layout>
    <Head :title="trans('staff.form.createTitle')" />
    <section class="md:w-3/4 mx-auto py-12">
      <StaffForm :teams="teams" />
    </section>
  </Layout>
</template>
