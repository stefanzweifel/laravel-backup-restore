<?php declare(strict_types=1);

namespace App\Http\Controllers\DailyUpdates\Presenters;

use App\Http\Requests\DailyUpdate\DailyUpdateAnalyticsRequest;
use App\Models\DailyUpdates\Report\Report;
use App\Models\Team;
use App\Utility\Chart\Chart;
use App\Utility\Chart\DataPoint;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Inertia\Response;

/** @template T of \App\Models\DailyUpdates\Report\Report */
abstract class DailyUpdatePresenter
{
    public const REPORT_DATETIME_FORMAT = 'l (Y-m-d)';

    private const NUM_DAYS_TO_DISPLAY = 7;
    private const NUM_WEEKS_TO_DISPLAY = 12;
    private const NUM_MONTHS_TO_DISPLAY = 12;

    public function __construct(private readonly DailyUpdateAnalyticsRequest $request)
    {
    }

    /** @param T $report */
    abstract public function present(Report $report): Response;

    /**
     * @phpcsSuppress SlevomatCodingStandard.TypeHints.DisallowMixedTypeHint.DisallowedMixedTypeHint
     * @return array<string, array<mixed>>
     * @psalm-return array{
     *     by: string,
     *     range: string,
     *     rangeOptions: array{days: array<string, string>, months: array<string, string>, weeks: array<string, string>},
     *     teams: list<array{members: array<string, string>, name: string, slug: string}>,
     *  }
     */
    protected function getFilters(): array
    {
        $datetimeRange = $this->request->dateFilterOptions();

        return [
            'rangeOptions' => [
                'days' => $this->dayFilterOptions(),
                'weeks' => $this->weekFilterOptions(),
                'months' => $this->monthFilterOptions(),
            ],
            'teams' => $this->teamFilter(),
            'by' => (string) $this->request->query('by', "staff:{$this->request->user()->email}"),
            'range' => $this->request::convertDateRangeForUrl([$datetimeRange->from, $datetimeRange->to]),
        ];
    }

    protected function date(): string
    {
        $datetimeRange = $this->request->dateFilterOptions();
        $start = $datetimeRange->from;
        $end = $datetimeRange->to;

        return $start->diffInDays($end) > 7 ? $this->formatMonth($start) : $this->formatWeek($start);
    }

    /** @return array<string, string> */
    private function weekFilterOptions(): array
    {
        return collect(range(0, -self::NUM_WEEKS_TO_DISPLAY, -1))
            ->map(static fn (int $relativeWeekNumber): Carbon => Carbon::parse("this week {$relativeWeekNumber} week midnight"))
            ->keyBy(fn (Carbon $weekStartDay): string => $this->formatWeek($weekStartDay))
            ->map(static fn (Carbon $weekStartDay): string => DailyUpdateAnalyticsRequest::convertDateRangeForUrl([
                $weekStartDay,
                $weekStartDay->clone()->endOfWeek(),
            ]))
            ->all();
    }

    /** @return array<string, string> */
    private function dayFilterOptions(): array
    {
        return collect(range(0, self::NUM_DAYS_TO_DISPLAY))
            ->map(static fn (int $daysAgo): Carbon => Carbon::parse("{$daysAgo} days ago midnight"))
            ->keyBy(fn (Carbon $day): string => $this->formatDay($day))
            ->map(static fn (Carbon $day): string => DailyUpdateAnalyticsRequest::convertDateRangeForUrl([
                $day,
                $day->clone()->endOfDay(),
            ]))
            ->all();
    }

    /** @return array<string, string> */
    private function monthFilterOptions(): array
    {
        return collect(range(0, -self::NUM_MONTHS_TO_DISPLAY, -1))
            ->map(static fn (int $relativeMonthNumber): Carbon => Carbon::parse("first day of this month {$relativeMonthNumber} month midnight"))
            ->keyBy(fn (Carbon $monthStartDay): string => $this->formatMonth($monthStartDay))
            ->map(static fn (Carbon $monthStartDay): string => DailyUpdateAnalyticsRequest::convertDateRangeForUrl([
                $monthStartDay,
                $monthStartDay->clone()->endOfMonth(),
            ]))
            ->all();
    }

    /** @return list<array{name: string, slug: string, members: array<string, string>}> */
    private function teamFilter(): array
    {
        return Team::query()->with(['members'])->orderBy('name')->get()
            ->toBase()
            ->map(static function (Team $team) {
                return [
                    'name' => $team->name,
                    'slug' => $team->slug,
                    'members' => $team->members()->pluck('name', 'email')->all(),
                ];
            })
            ->all();
    }

    private function formatDay(\Carbon\CarbonInterface $day): string
    {
        $daysAgo = today()->diffInDays($day);
        if ($daysAgo === 0) {
            return "today ({$day->format('D')})";
        }

        return sprintf('%s %s ago (%s)', $daysAgo, Str::plural('day', $daysAgo), $day->format('D'));
    }

    private function formatWeek(\Carbon\CarbonInterface $weekStartDay): string
    {
        $diffInWeeks = $weekStartDay->diffInWeeks(now());

        return $diffInWeeks > 0
            ? sprintf('%s (%d %s ago)', $weekStartDay->format('\W\e\e\k W \o\f Y'), $diffInWeeks, Str::plural('week', $diffInWeeks))
            : sprintf('%s (this week)', $weekStartDay->format('\W\e\e\k W \o\f Y'));
    }

    private function formatMonth(\Carbon\CarbonInterface $monthStartDay): string
    {
        $diffInMonths = $monthStartDay->diffInMonths(now());

        return $diffInMonths > 0
            ? sprintf('%s (%d %s ago)', $monthStartDay->format('M Y'), $diffInMonths, Str::plural('month', $diffInMonths))
            : sprintf('%s (this month)', $monthStartDay->format('M Y'));
    }

    /** @return array{labels: array<string>, datasets: array<array{label: string, backgroundColor: string, data: array<int>}>} */
    protected function formatChart(Chart $chart): array
    {
        return [
            'labels' => $chart->getDataPointsLabels(),
            'datasets' => $this->getDatasetFromChart($chart),
        ];
    }

    /** @return array<int, array{label: string, backgroundColor: string, data: array<float|int|null>}> */
    protected function getDatasetFromChart(Chart $chart): array
    {
        $barChartDataSets = [];
        for ($i = 0; $i < $chart->getDataSetsCount(); $i++) {
            $barChartDataSets[] = [
                'label' => $chart->getDataSet($i)->getLegend(),
                'backgroundColor' => $chart->getDataSet($i)->getColor(),
                'data' => collect($chart->getDataSet($i)->getDataPoints())
                    ->map(static fn (DataPoint $dataPoint) => $dataPoint->getValue())
                    ->all(),
            ];
        }

        return $barChartDataSets;
    }
}
