/* eslint-disable */

module.exports = {
  content: [
    './resources/**/*.{blade.php,js,css,vue,pcss}',
    './lang/**/*.{php,json}',
    './node_modules/flowbite/**/*.js',
  ],
  darkMode: 'media',
  theme: {
    fontFamily: {
      sans: ['Source Sans Pro', 'arial', 'sans-serif'],
      serif: ['Merriweather', 'georgia', 'serif'],
    },
    screens: {
      sm: '640px',
      md: '768px',
      lg: '1024px',
    },
    colors: {
      transparent: 'transparent',
      current: 'currentColor',
      white: '#eeeeee',
      black: '#333333',
      neutral: {
        50: '#fafafa',
        100: '#f5f5f5',
        300: '#d4d4d4',
        400: '#a3a3a3',
        600: '#525252',
      },

      /* Brand colors */
      'brand-01': '#009cde',
      'brand-02': '#0d6fb4',
      'accent-01': '#457205',
      'accent-02': '#f5851e',
      'accent-03': '#d21f18',
      'accent-04': '#800080',
      'accent-05': '#cf6dc8',
    },
  },
  plugins: [require('flowbite/plugin')],
};
