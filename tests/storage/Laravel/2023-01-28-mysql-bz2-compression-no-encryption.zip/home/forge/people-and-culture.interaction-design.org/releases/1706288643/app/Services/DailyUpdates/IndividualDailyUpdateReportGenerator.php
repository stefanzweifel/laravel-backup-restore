<?php declare(strict_types=1);

namespace App\Services\DailyUpdates;

use App\Http\Controllers\DailyUpdates\Presenters\IndividualDailyUpdatePresenter;
use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Report\DailyUpdateDTO;
use App\Models\DailyUpdates\Report\IndividualReport;
use App\Models\DailyUpdates\Report\NullUpdateDTO;
use App\Models\Staff;
use App\Models\StaffLeave\Leave;
use App\Models\StaffLeave\Report\LeaveDTO;
use App\ValueObjects\DatetimeRange;
use Carbon\CarbonInterface;
use Carbon\CarbonPeriod;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;

/** @extends \App\Services\DailyUpdates\DailyUpdateReportGenerator<\App\Models\DailyUpdates\Report\IndividualReport> */
final class IndividualDailyUpdateReportGenerator extends DailyUpdateReportGenerator
{
    public function __construct(private readonly Staff $staff, DatetimeRange $datetimeRange)
    {
        parent::__construct($datetimeRange);
    }

    /** @inheritDoc */
    public function generate(): IndividualReport
    {
        $reports = $this->getReports();
        $numberOfWorkingDays = $this->numberOfWorkingDays();
        $numberOfHalfDayReports = $this->getNumberOfHalfDayReports($reports);
        $numberOfFullDayReports = $this->getNumberOfFullDayReports($reports);

        return new IndividualReport(
            $this->staff->name,
            $this->staff->team->name,
            $numberOfWorkingDays,
            $this->calculateLastUpdatedDate(),
            $reports,
            $this->getLeaves(),
            $this->getTeamMemberWeeklyAnalytics(),
            $this->getTeamMemberMonthlyAnalytics(),
            $numberOfFullDayReports,
            $numberOfHalfDayReports,
            max($numberOfWorkingDays - $numberOfFullDayReports - $numberOfHalfDayReports, 0),
            $numberOfHalfDayReports
        );
    }

    /** @return array<string, array<string, \App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO>> */
    private function getReports(): array
    {
        $dailyUpdates = DailyUpdate::query()
            ->with('staff.team')
            ->scopes(['reportedWithin' => [$this->datetimeRange->from, $this->datetimeRange->to]])
            ->scopes(['forMember' => [$this->staff->email]])
            ->orderByDesc('reporting_date')
            ->get()
            ->groupBy(static fn (DailyUpdate $dailyUpdate): int => $dailyUpdate->reporting_date->dayOfYear)
            ->map(static fn (Collection $updates): Collection => $updates
                ->mapWithKeys(static fn (DailyUpdate $dailyUpdate): array => [$dailyUpdate->staff->id => DailyUpdateDTO::fromDailyUpdate($dailyUpdate)]));

        $period = collect(CarbonPeriod::create($this->datetimeRange->from, $this->datetimeRange->to->min(now()))->toArray())->reverse();

        $default = $period->mapWithKeys(fn (CarbonInterface $date): array => [
            $date->format(IndividualDailyUpdatePresenter::REPORT_DATETIME_FORMAT) => Collection::wrap(
                Arr::has($dailyUpdates, $date->dayOfYear().'.'.$this->staff->id)
                    ? Arr::get($dailyUpdates, $date->dayOfYear().'.'.$this->staff->id)
                    : NullUpdateDTO::create($this->staff, $date)
            )->keyBy('staff_email'),
        ]);

        return $default->all();
    }

    /** @return list<\App\Models\StaffLeave\Report\LeaveDTO> */
    private function getLeaves(): array
    {
        /** @var list<\App\Models\StaffLeave\Report\LeaveDTO> $leaves */
        $leaves = Leave::query()
            ->join('peopleAndCulture__staff', 'peopleAndCulture__leaves.staff_id', '=', 'peopleAndCulture__staff.id')
            ->join('peopleAndCulture__team', 'peopleAndCulture__staff.team_id', '=', 'peopleAndCulture__team.id')
            ->selectRaw('peopleAndCulture__leaves.*, peopleAndCulture__staff.email')
            ->whereBetween('leave_date', [$this->datetimeRange->from, $this->datetimeRange->to])
            ->where('peopleAndCulture__staff.email', $this->staff->email)
            ->orderByDesc('leave_date')
            ->get()
            ->toBase()
            ->map(static function (Leave $leave): LeaveDTO {
                $email = $leave->getAttribute('email');
                assert(is_string($email));
                return LeaveDTO::createFromModel($leave, $email);
            })
            ->toArray();

        return $leaves;
    }

    /** @return array<string, array{updates: int, leaves: int, days: int}> */
    private function getTeamMemberWeeklyAnalytics(): array
    {
        $startDate = $this->datetimeRange->from->clone();
        $endDate = $this->datetimeRange->to->clone();

        $isMonthly = $startDate->diffInDays($endDate) > 7;
        if (! $isMonthly) {
            $startDate->subWeeks(3)->startOf('week');
        } else {
            $startDate->startOf('week');
            $endDate->endOf('week');
        }

        $stats = [];
        for ($weekNumber = 0; $weekNumber <= $endDate->diffInWeeks($startDate); $weekNumber++) {
            $startOfWeek = $startDate->clone()->addRealWeeks($weekNumber)->toImmutable();
            $key = sprintf('Week %d of %d', $startOfWeek->weekOfYear, $startOfWeek->year);
            $stats[$key] = [
                'updates' => 0,
                'leaves' => 0,
                'days' => $startOfWeek->startOf('week')->diffInWeekdays($startOfWeek->endOf('week')),
            ];
        }

        $this->getDailyUpdatesForWeeklyReport($startDate, $endDate)
            ->keyBy(static fn (object $update): string => sprintf('Week %d of %d', $update->week_number, $update->year))
            ->each(static function (object $update, string $week) use (&$stats): void {
                $weekOfTheUpdate = now()->startOfYear()->setYear((int) $update->year)->addRealWeeks((int) $update->week_number)->toImmutable();
                $startOfWeekTheUpdateWasPosted = $weekOfTheUpdate->startOf('week');
                $lastDayOfWeekTheUpdateWasPosted = $weekOfTheUpdate->endOf('week');

                Arr::set($stats, "{$week}.updates", $update->count);
                Arr::set($stats, "{$week}.leaves", Arr::get($stats, "{$week}.leaves", 0));
                Arr::set($stats, "{$week}.days", $startOfWeekTheUpdateWasPosted->diffInWeekdays($lastDayOfWeekTheUpdateWasPosted));
            });

        $this->getLeavesForWeeklyReport($startDate, $endDate)
            ->keyBy(static fn (object $leave): string => sprintf('Week %d of %d', $leave->week_number, $leave->year))
            ->each(static function (object $leave, string $week) use (&$stats): void {
                $weekOfTheLeave = now()->startOfYear()->setYear((int) $leave->year)->addRealWeeks((int) $leave->week_number)->toImmutable();
                $startOfWeekTheLeaveWasRegistered = $weekOfTheLeave->startOf('week');
                $lastDayOfWeekTheLeaveWasRegistered = $weekOfTheLeave->endOf('week');

                Arr::set($stats, "{$week}.updates", Arr::get($stats, "{$week}.updates", 0));
                Arr::set($stats, "{$week}.leaves", $leave->count);
                Arr::set($stats, "{$week}.days", $startOfWeekTheLeaveWasRegistered->diffInWeekdays($lastDayOfWeekTheLeaveWasRegistered));
            });

        return $stats;
    }

    /** @return \Illuminate\Support\Collection<int, \App\Models\DailyUpdates\DailyUpdate> */
    private function getDailyUpdatesForWeeklyReport(CarbonInterface $startDate, CarbonInterface $endDate): Collection
    {
        return DailyUpdate::query()
            ->selectRaw('COUNT(*) AS count, WEEK(reporting_date, 1) AS week_number, YEAR(reporting_date) AS year')
            ->groupByRaw('week_number, year')
            ->scopes(['reportedWithin' => [$startDate, $endDate]])
            ->scopes(['forMember' => [$this->staff->email]])
            ->get();
    }

    /** @return \Illuminate\Support\Collection<int, \App\Models\StaffLeave\Leave> */
    private function getLeavesForWeeklyReport(CarbonInterface $startDate, CarbonInterface $endDate): Collection
    {
        return Leave::query()
            ->selectRaw('COUNT(DISTINCT leave_date) AS count, WEEK(leave_date, 1) AS week_number, YEAR(leave_date) AS year')
            ->groupByRaw('week_number, year')
            ->whereBetween('leave_date', [$startDate, $endDate])
            ->whereHas('staff', function (\Illuminate\Contracts\Database\Query\Builder $query): void {
                $query->where('email', $this->staff->email);
            })
            ->whereNotExists(static function (\Illuminate\Contracts\Database\Query\Builder $query) {
                $query->select('id')
                    ->from('peopleAndCulture__daily_updates')
                    ->whereNull('peopleAndCulture__daily_updates.deleted_at')
                    ->whereRaw('peopleAndCulture__daily_updates.reporting_date = peopleAndCulture__leaves.leave_date')
                    ->whereRaw('peopleAndCulture__daily_updates.staff_id = peopleAndCulture__leaves.staff_id');
            })
            ->get();
    }

    /** @return array<string, array{updates: int, leaves: int, days: int}> */
    private function getTeamMemberMonthlyAnalytics(): array
    {
        $startDate = $this->datetimeRange->from->clone();
        $endDate = $this->datetimeRange->to->clone();

        $isMonthly = $startDate->diffInDays($endDate) > 7;
        if (! $isMonthly) {
            $startDate->startOfMonth();
            $endDate->endOfMonth();
        }

        $stats = [];
        $stats[$startDate->format('M Y')] = [
            'updates' => 0,
            'leaves' => 0,
            'days' => $startDate->diffInWeekdays($startDate->clone()->endOfMonth()->min(now())),
        ];

        if (!$startDate->isSameMonth($endDate)) {
            $stats[$startDate->format('M Y')] = [
                'updates' => 0,
                'leaves' => 0,
                'days' => $endDate->clone()->startOfMonth()->diffInWeekdays($startDate->min(now())),
            ];
        }

        $this->getDailyUpdatesForMonthlyReport($startDate, $endDate)
            ->keyBy(static fn (object $update): string => now()->setYear((int) $update->year)->setMonth((int) $update->month_number)->format('M Y'))
            ->each(static function (object $update, string $month) use (&$stats): void {
                $startOfMonthTheUpdateWasPosted = now()->setYear((int) $update->year)->setMonth((int) $update->month_number)->startOfMonth();
                $endOfMonthTheUpdateWasPosted = now()->setYear((int) $update->year)->setMonth((int) $update->month_number)->endOfMonth();

                Arr::set($stats, "{$month}.updates", $update->count);
                Arr::set($stats, "{$month}.leaves", Arr::get($stats, "{$month}.leaves", 0));
                Arr::set($stats, "{$month}.days", $startOfMonthTheUpdateWasPosted->diffInWeekdays($endOfMonthTheUpdateWasPosted));
            });

        $this->getLeavesForMonthyReport($startDate, $endDate)
            ->keyBy(static fn (object $update): string => now()->setYear((int) $update->year)->setMonth((int) $update->month_number)->format('M Y'))
            ->each(static function (object $leave, string $month) use (&$stats): void {
                $startOfMonthTheLeaveWasRegistered = now()->setYear((int) $leave->year)->setMonth((int) $leave->month_number)->startOfMonth();
                $endOfMonthTheLeaveWasRegistered = now()->setYear((int) $leave->year)->setMonth((int) $leave->month_number)->endOfMonth();

                Arr::set($stats, "{$month}.updates", Arr::get($stats, "{$month}.updates", 0));
                Arr::set($stats, "{$month}.leaves", $leave->count);
                Arr::set($stats, "{$month}.days", $startOfMonthTheLeaveWasRegistered->diffInWeekdays($endOfMonthTheLeaveWasRegistered));
            });

        return $stats;
    }

    /** @return \Illuminate\Support\Collection<int, \App\Models\DailyUpdates\DailyUpdate> */
    private function getDailyUpdatesForMonthlyReport(CarbonInterface $startDate, CarbonInterface $endDate): Collection
    {
        return DailyUpdate::query()
            ->selectRaw('COUNT(*) as count, MONTH(reporting_date) as month_number, YEAR(reporting_date) as year')
            ->groupByRaw('month_number, year')
            ->scopes(['reportedWithin' => [$startDate, $endDate]])
            ->scopes(['forMember' => [$this->staff->email]])
            ->get();
    }

    /** @return \Illuminate\Support\Collection<int, \App\Models\StaffLeave\Leave> */
    private function getLeavesForMonthyReport(CarbonInterface $startDate, CarbonInterface $endDate): Collection
    {
        return Leave::query()
            ->selectRaw('COUNT(DISTINCT leave_date) AS count, MONTH(leave_date) AS month_number, YEAR(leave_date) AS year')
            ->groupByRaw('month_number, year')
            ->whereBetween('leave_date', [$startDate, $endDate])
            ->whereHas('staff', function (\Illuminate\Contracts\Database\Query\Builder $query): void {
                $query->where('email', $this->staff->email);
            })
            ->whereNotExists(static function (\Illuminate\Contracts\Database\Query\Builder $query) {
                $query->select('id')
                    ->from('peopleAndCulture__daily_updates')
                    ->whereNull('peopleAndCulture__daily_updates.deleted_at')
                    ->whereRaw('peopleAndCulture__daily_updates.reporting_date = peopleAndCulture__leaves.leave_date')
                    ->whereRaw('peopleAndCulture__daily_updates.staff_id = peopleAndCulture__leaves.staff_id');
            })
            ->get();
    }
}
