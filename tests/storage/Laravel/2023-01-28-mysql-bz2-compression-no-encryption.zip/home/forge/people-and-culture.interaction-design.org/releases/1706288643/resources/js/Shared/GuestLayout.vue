<template>
  <div class="bg-neutral-50 min-h-screen">
    <main class="container mx-auto px-6">
      <FlashMessage :flash="$page.props.flash" />
      <slot></slot>
    </main>
  </div>
</template>

<script setup>
import FlashMessage from '@/Components/FlashMessage.vue';
</script>
