<?php declare(strict_types=1);

namespace App\Utility;

final class GitHubUrl
{
    public function __construct(private readonly string $repository)
    {
    }

    public function tag(string $tag): string
    {
        return "https://github.com/{$this->repository}/releases/tag/{$tag}";
    }
}
