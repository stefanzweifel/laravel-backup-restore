<script setup lang="ts">
import {Link, Head} from '@inertiajs/inertia-vue3';
import route from 'ziggy-js';
import {trans} from 'laravel-vue-i18n';

import {Analytics, Filters, DailyUpdateReport, Leave} from '@/types';

import Layout from '@/Shared/Layout.vue';
import DailyUpdateFilter from '@/Components/DailyUpdateFilter.vue';
import DailyUpdateStaffDetails from '@/Components/DailyUpdateStaffDetails.vue';
import DailyUpdateTeamDetails from '@/Components/DailyUpdateTeamDetails.vue';
import DailyUpdateCharts from '@/Components/DailyUpdateCharts.vue';
import DailyUpdateTable from '@/Components/DailyUpdateTable.vue';

defineProps<{
  lastUpdatedAgo: string;
  showReports: boolean;
  filters: Filters;
  analytics: Analytics;
  date: string;
  teamName: string;
  staffName: string;
  reports: {
    string: DailyUpdateReport[]; // where key is a human-readable date
  };
  leaves: Leave[];
}>();
</script>

<template>
  <Layout>
    <Head :title="trans('dailyUpdates.pageTitle')" />
    <section class="py-12">
      <h1 class="text-4xl font-bold mb-3">
        {{ trans('dailyUpdates.pageTitle') }}
      </h1>
      <a
        href="https://www.interaction-design.org/courses/ixdf-handbook/lessons/daily-updates"
        target="_blank"
        class="link mb-4"
      >
        {{ trans('dailyUpdates.info') }}
      </a>
      <div class="my-4">
        <Link
          :href="route('peopleAndCulture.dailyUpdates.create')"
          class="text-white bg-brand-01 hover:bg-brand-02 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 dark:bg-brand-01 dark:hover:bg-brand-02 dark:focus:ring-blue-800"
        >
          ➕ {{ trans('dailyUpdates.postUpdate') }}
        </Link>
      </div>
      <div class="text-sm mb-6">
        {{ trans('dailyUpdates.lastUpdated', {date: lastUpdatedAgo}) }}
      </div>

      <p v-if="!showReports">{{ trans('dailyUpdates.filter') }}</p>

      <section class="mb-6">
        <DailyUpdateFilter :filters="filters" />
      </section>

      <DailyUpdateCharts
        v-if="showReports"
        :analytics="analytics"
        :date="date"
        :filters="filters"
      />

      <DailyUpdateTeamDetails
        v-if="filters.by.startsWith('team:')"
        :analytics="analytics"
        :team-name="teamName"
        :current-range="date"
      />

      <DailyUpdateStaffDetails
        v-if="filters.by.startsWith('staff:')"
        :analytics="analytics"
        :staff-name="staffName"
        :team-name="teamName"
        :current-range="date"
      />

      <DailyUpdateTable v-if="showReports" :reports="reports" :leaves="leaves" />
    </section>
  </Layout>
</template>
