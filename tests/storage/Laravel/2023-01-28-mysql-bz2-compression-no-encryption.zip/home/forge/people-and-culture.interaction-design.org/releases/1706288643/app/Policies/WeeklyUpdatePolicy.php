<?php declare(strict_types=1);

namespace App\Policies;

use App\Models\Staff;

final class WeeklyUpdatePolicy
{
    public function create(Staff $staff): bool
    {
        return $staff->is_admin;
    }

    public function index(Staff $staff): bool
    {
        return $staff->is_admin;
    }
}
