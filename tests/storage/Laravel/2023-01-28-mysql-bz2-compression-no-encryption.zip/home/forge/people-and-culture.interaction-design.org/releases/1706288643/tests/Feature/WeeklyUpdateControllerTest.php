<?php declare(strict_types=1);

use App\Models\WeeklyUpdates\WeeklyUpdate;
use Database\Factories\StaffFactory;
use Illuminate\Support\Carbon;
use Inertia\Testing\AssertableInertia as Assert;
use function Pest\Faker\fake;

it('should render the weekly update index page', function () {
    $staff = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('peopleAndCulture.weeklyUpdates.index'))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('WeeklyUpdates/Index')
            ->has('reports'));
});

it('should  render the weekly update create page', function () {
    $staff = StaffFactory::new()->createOne();

    $this
        ->actingAs($staff)
        ->get(route('peopleAndCulture.weeklyUpdates.create'))
        ->assertOk()
        ->assertInertia(static fn (Assert $page) => $page
            ->component('WeeklyUpdates/Create'));
});

it('should create weekly update', function () {
    $fakeEvent = \Illuminate\Support\Facades\Event::fake(); // do not send Slack notification from an Event Listener
    $staff = StaffFactory::new()->admin()->createOne();
    $date = now()->toDateString();

    $updateData = [
        'reporting_week_end_date' => $date,
        'update' => fake()->text,
        'plans' => fake()->text,
        'blockers' => fake()->text,
        'notes' => fake()->text,
    ];

    $response = $this
        ->withoutExceptionHandling()
        ->actingAs($staff)
        ->post(route('peopleAndCulture.weeklyUpdates.store'), $updateData);

    $response->assertSessionDoesntHaveErrors();
    $response->assertStatus(302);
    $this->assertDatabaseHas(WeeklyUpdate::class, [
        'team_lead_id' => $staff->id,
        'reporting_week_end_date' => Carbon::parse($date)->endOfWeek(Carbon::FRIDAY)->toDateString(),
        'progress_last_week' => $updateData['update'],
        'plans_this_week' => $updateData['plans'],
        'potential_problems' => $updateData['blockers'],
        'notes' => $updateData['notes'],
    ]);
    $fakeEvent->assertDispatchedTimes(\App\Events\WeeklyUpdateSubmitted::class, 1);
});
