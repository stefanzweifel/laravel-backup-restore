<?php declare(strict_types=1);

namespace Database\Factories\WeeklyUpdates;

use App\Models\WeeklyUpdates\WeeklyUpdate;
use Database\Factories\StaffFactory;
use Illuminate\Database\Eloquent\Factories\Factory;

/** @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\WeeklyUpdates\WeeklyUpdate> */
final class WeeklyUpdateFactory extends Factory
{
    /** @var class-string */
    protected $model = WeeklyUpdate::class;

    /** @inheritDoc */
    public function definition(): array
    {
        return [
            'team_lead_id' => StaffFactory::new(),
            'reporting_week_end_date' => $this->faker->dateTimeThisYear,
            'progress_last_week' => $this->faker->paragraph,
            'plans_this_week' => $this->faker->paragraph,
            'potential_problems' => $this->faker->paragraph,
            'notes' => $this->faker->boolean
                ? $this->faker->paragraph
                : '',
        ];
    }
}
