<?php declare(strict_types=1);

namespace App\Services\DailyUpdates;

use App\Http\Controllers\DailyUpdates\Presenters\TeamDailyUpdatePresenter;
use App\Models\DailyUpdates\DailyUpdate;
use App\Models\DailyUpdates\Report\DailyUpdateDTO;
use App\Models\DailyUpdates\Report\NullUpdateDTO;
use App\Models\DailyUpdates\Report\TeamReport;
use App\Models\Staff;
use App\Models\StaffLeave\Leave;
use App\Models\StaffLeave\Report\LeaveDTO;
use App\Models\Team;
use App\ValueObjects\DatetimeRange;
use Carbon\CarbonInterface;
use Carbon\CarbonPeriod;
use Illuminate\Database\Query\JoinClause;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;

/**
 * @psalm-import-type TeamReportStatistic from \App\Models\DailyUpdates\Report\TeamReport
 * @extends \App\Services\DailyUpdates\DailyUpdateReportGenerator<\App\Models\DailyUpdates\Report\TeamReport>
 */
final class TeamDailyUpdateReportGenerator extends DailyUpdateReportGenerator
{
    public function __construct(private readonly Team $team, DatetimeRange $datetimeRange)
    {
        parent::__construct($datetimeRange);
    }

    /** @inheritDoc */
    public function generate(): TeamReport
    {
        $dailyUpdateStats = $this->dailyUpdateStats();
        $leaveStats = $this->leaveStats();

        $reports = $this->getReports();
        $numberOfHalfDayReports = $this->getNumberOfHalfDayReports($reports);
        $numberOfFullDayReports = $this->getNumberOfFullDayReports($reports);
        $numberOfWorkingDays = $this->numberOfWorkingDays();
        $numberOfTeamMembers = count($dailyUpdateStats);

        return new TeamReport(
            $this->team->name,
            $this->getTeamMembers(),
            $numberOfWorkingDays,
            $this->calculateLastUpdatedDate(),
            $reports,
            $this->getLeaves(),
            $dailyUpdateStats,
            $leaveStats,
            $numberOfFullDayReports,
            $numberOfHalfDayReports,
            max($numberOfWorkingDays * $numberOfTeamMembers - $numberOfFullDayReports - $numberOfHalfDayReports, 0),
            $numberOfHalfDayReports
        );
    }

    /** @return array<string, array<string, (\App\Models\DailyUpdates\Report\DailyUpdateDTO|\App\Models\DailyUpdates\Report\NullUpdateDTO)>> */
    private function getReports(): array
    {
        $from = $this->datetimeRange->from;
        $to = $this->datetimeRange->to;
        $team = $this->team;

        $dailyUpdates = DailyUpdate::query()
            ->join('peopleAndCulture__staff', 'peopleAndCulture__daily_updates.staff_id', '=', 'peopleAndCulture__staff.id')
            ->join('peopleAndCulture__team', 'peopleAndCulture__staff.team_id', '=', 'peopleAndCulture__team.id')
            ->selectRaw('peopleAndCulture__daily_updates.*')
            ->whereBetween('reporting_date', [$from, $to])
            ->where('peopleAndCulture__team.slug', $this->team->slug)
            ->orderByDesc('reporting_date')
            ->get()
            ->toBase()
            ->groupBy(static fn (DailyUpdate $dailyUpdate): int => $dailyUpdate->reporting_date->dayOfYear)
            ->map(static function (Collection $updates): Collection {
                return $updates->mapWithKeys(static function (DailyUpdate $dailyUpdate): array {
                    return [$dailyUpdate->staff->id => DailyUpdateDTO::fromDailyUpdate($dailyUpdate)];
                });
            });

        $period = collect(CarbonPeriod::create($from, $to->min(now()))->toArray())
            ->reverse();

        $default = $period
            ->mapWithKeys(static function (CarbonInterface $date) use ($team, $dailyUpdates): array {
                return [$date->format(TeamDailyUpdatePresenter::REPORT_DATETIME_FORMAT) => $team->members->toBase()->mapWithKeys(
                    static fn (Staff $teamMember): array => [$teamMember->email => Arr::has($dailyUpdates, "{$date->dayOfYear()}.{$teamMember->id}")
                        ? Arr::get($dailyUpdates, "{$date->dayOfYear()}.{$teamMember->id}")
                        : NullUpdateDTO::create($teamMember, $date)]
                )];
            });

        return $default->all();
    }

    /** @return list<\App\Models\StaffLeave\Report\LeaveDTO> */
    private function getLeaves(): array
    {
        /** @var list<\App\Models\StaffLeave\Report\LeaveDTO> $leaves */
        $leaves = Leave::query()
            ->join('peopleAndCulture__staff', 'peopleAndCulture__leaves.staff_id', '=', 'peopleAndCulture__staff.id')
            ->join('peopleAndCulture__team', 'peopleAndCulture__staff.team_id', '=', 'peopleAndCulture__team.id')
            ->selectRaw('peopleAndCulture__leaves.*, peopleAndCulture__staff.email')
            ->whereBetween('leave_date', [$this->datetimeRange->from, $this->datetimeRange->to])
            ->where('peopleAndCulture__team.slug', $this->team->slug)
            ->orderByDesc('leave_date')
            ->get()
            ->map(static function (Leave $leave): LeaveDTO {
                $email = $leave->getAttribute('email');
                assert(is_string($email));
                return LeaveDTO::createFromModel($leave, $email);
            })
            ->toArray();

        return $leaves;
    }

    /** @return list<array{name: string, email: string}> */
    private function getTeamMembers(): array
    {
        return $this->team->members()
            ->select(['name', 'email'])
            ->get()
            ->toArray();
    }

    /** @return list<TeamReportStatistic> */
    private function dailyUpdateStats(): array
    {
        /** @var list<TeamReportStatistic> $dailyUpdateStats */
        $dailyUpdateStats = Staff::query()
            ->leftJoin('peopleAndCulture__daily_updates', function (JoinClause $leftJoin) {
                $leftJoin->on('peopleAndCulture__daily_updates.staff_id', '=', 'peopleAndCulture__staff.id');
                $leftJoin->whereNull('peopleAndCulture__daily_updates.deleted_at');
                $leftJoin->whereBetween('peopleAndCulture__daily_updates.reporting_date', [$this->datetimeRange->from, $this->datetimeRange->to]);
            })
            ->join('peopleAndCulture__team', 'peopleAndCulture__staff.team_id', '=', 'peopleAndCulture__team.id')
            ->selectRaw('COUNT(peopleAndCulture__daily_updates.id) as count, peopleAndCulture__staff.name, peopleAndCulture__staff.email')
            ->groupBy(['peopleAndCulture__staff.name', 'peopleAndCulture__staff.email'])
            ->where('peopleAndCulture__team.slug', $this->team->slug)
            ->orderByRaw('peopleAndCulture__staff.id')
            ->get()
            ->toArray();

        return $dailyUpdateStats;
    }

    /** @return list<TeamReportStatistic> */
    private function leaveStats(): array
    {
        /** @var list<TeamReportStatistic> $leaveStats */
        $leaveStats = Staff::query()
            ->leftJoin('peopleAndCulture__leaves', function (JoinClause $leftJoin) {
                $leftJoin->on('peopleAndCulture__leaves.staff_id', '=', 'peopleAndCulture__staff.id');
                $leftJoin->whereNull('peopleAndCulture__leaves.deleted_at');
                $leftJoin->whereBetween('peopleAndCulture__leaves.leave_date', [$this->datetimeRange->from, $this->datetimeRange->to]);
                $leftJoin->whereNotExists(static function (\Illuminate\Contracts\Database\Query\Builder $query) {
                    $query->select('id')
                        ->from('peopleAndCulture__daily_updates')
                        ->whereNull('peopleAndCulture__daily_updates.deleted_at')
                        ->whereRaw('peopleAndCulture__daily_updates.reporting_date = peopleAndCulture__leaves.leave_date')
                        ->whereRaw('peopleAndCulture__daily_updates.staff_id = peopleAndCulture__leaves.staff_id');
                });
            })
            ->join('peopleAndCulture__team', 'peopleAndCulture__staff.team_id', '=', 'peopleAndCulture__team.id')
            ->selectRaw('COUNT(DISTINCT peopleAndCulture__leaves.leave_date) as count, peopleAndCulture__staff.name, peopleAndCulture__staff.email')
            ->groupBy(['peopleAndCulture__staff.name', 'peopleAndCulture__staff.email'])
            ->where('peopleAndCulture__team.slug', $this->team->slug)
            ->orderByRaw('peopleAndCulture__staff.id')
            ->get()
            ->toArray();

        return $leaveStats;
    }
}
