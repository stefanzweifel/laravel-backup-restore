<?php declare(strict_types=1);

return [
    'logout' => 'Logout',
    'main_menu_open' => 'Open main menu',
    'user_menu_open' => 'Open user menu',
    'user_photo' => 'User photo',
];
